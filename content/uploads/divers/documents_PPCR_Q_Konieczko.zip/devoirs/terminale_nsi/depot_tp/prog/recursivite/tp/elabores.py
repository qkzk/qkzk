def maximum_iteratif(liste):
    '''
    >>> maximum_iteratif([1, 2, 3])
    3
    >>> maximum_iteratif([3, 2, 1])
    3
    >>> maximum_iteratif([1, 3, 1])
    3
    '''
    m = liste[0]
    for k in liste:
        if k > m:
            m = k
    return m


def maximum_recursif(liste, courant_max=None):
    '''
    >>> maximum_recursif([1])
    1
    >>> maximum_recursif([])
    >>> maximum_recursif([1, 2, 3])
    3
    >>> maximum_recursif([3, 2, 1])
    3
    >>> maximum_recursif([1, 3, 1])
    3
    '''
    pass


def combinaison(n, p):
    '''
    >>> combinaison(6, 0)
    1
    >>> combinaison(6, 6)
    1
    >>> combinaison(6, 6)
    1
    >>> [combinaison(5, k) for k in range(6)]
    [1, 5, 10, 10, 5, 1]
    '''
    pass


def map_comprehension(fonction, liste):
    '''
    >>> map_comprehension(abs, [-1, -2, 3])
    [1, 2, 3]
    '''
    return [fonction(k) for k in liste]


def map_recursion(fonction, liste, acc=None):
    '''
    >>> map_recursion(abs, [-1, -2, 3])
    [1, 2, 3]
    '''
    pass


def plus_grand_que_deux(x):
    '''Retourne True si et seulement si x > 2'''
    return x > 2


def filter_comprehension(fonction, liste):
    '''
    >>> filter_comprehension(plus_grand_que_deux, [1, 3, 5, 0])
    [3, 5]
    '''
    return [item for item in liste if fonction(item)]


def filter_recursion(fonction, liste, acc=None):
    '''
    >>> filter_recursion(plus_grand_que_deux, [1, 3, 5, 0])
    [3, 5]
    '''
    pass


def reduce_recursion(fonction, liste, acc=None):
    '''
    >>> reduce_recursion(lambda a,b: a+b, [1, 2, 3, 4])
    10
    '''
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

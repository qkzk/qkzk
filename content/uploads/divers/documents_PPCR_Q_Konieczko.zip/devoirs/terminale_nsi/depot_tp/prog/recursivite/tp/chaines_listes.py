# chaines


def palindrome(mot):
    '''
    >>> palindrome('')
    True
    >>> palindrome('a')
    True
    >>> palindrome('aba')
    True
    >>> palindrome('abba')
    True
    >>> palindrome('abcdedcba')
    True
    >>> palindrome('abcdefdcba')
    False
    '''
    pass


def somme(liste):
    '''
    >>> somme([3])
    3
    >>> somme([3, 4, 5])
    12
    '''
    pass


def retourner(chaine):
    '''
    >>> retourner("")
    ''
    >>> retourner("a")
    'a'
    >>> retourner("robert")
    'trebor'
    '''
    pass


def concatener(liste1, liste2):
    '''
    >>> concatener([1, 2, 3], [])
    [1, 2, 3]
    >>> concatener([1, 2, 3], [4, 5, 6])
    [1, 2, 3, 4, 5, 6]
    '''
    pass


def occurences(lettre, mot):
    '''
    >>> occurences('a', 'aaa')
    3
    >>> occurences('a', '')
    0
    >>> occurences('a', 'abcdabcda')
    3
    '''
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

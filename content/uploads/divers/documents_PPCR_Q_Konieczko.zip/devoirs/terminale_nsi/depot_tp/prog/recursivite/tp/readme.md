---
title: Récursivité : exercices de programmation
author: qkzk
date: 2020/05/12
---

# Principe

Pour chaque partie, un module est prêt.

Il contient, pour chaque exercice de cette partie, une fonction avec sa signature et des exemples.

Votre travail consiste à compléter le code de la fonction.
Elle doit, bien-sûr valider les exemples.

D'autres exemples seront utilisés pour tester, afin que vous ne puissiez
contourner le problème.

Vous avez terminé une partie lorsque vous n'obtenez plus d'erreurs
en exécutant le module.

# Objectif :

1. Toutes vos fonctions doivent-être **récursives**.
2. Si elles utilisent une récursivité **terminale**, c'est mieux.
3. Toutes les fonctions doivent-être documentées. Pour l'instant, elles
   ne contiennent que les exemples.

# 1. Exercices simples.

1.  Créer une fonction `somme_entiers` qui calcule la somme des entiers
    de `0` à `n` : `0 + 1 + 2 + ... + (n-1) + n`

    ```python
    >>> somme_entiers(0)
    0
    >>> somme_entiers(1)
    1
    >>> somme_entiers(10)
    55
    ```

2.  Factorielle. Créer une fonction factorielle récursive.

3.  Algorithme d'Euclide

    Programmez l'algorithme d'Euclide qui calcule le plus grand
    commun diviseur de deux entiers.

4.  Suite de Fibonacci

    Programmez une fonction qui calcule le terme d'indice `n` de la suite de
    Fibonacci.

    Les premiers termes sont `1, 1, 2, 3, 5, 8, 13, 21...`

    Le termes suivant est calculé en ajoutant les deux derniers termes.

    _Attention :_ sans optimisation particulière cette fonction sera très
    lente. Il ne faut pas la tester pour de grands nombres, sans quoi
    cela prendra un temps très long. Pour être précis, sa complexité
    est _exponentielle_.

5.  Puissance d'un nombre

    Programmez une fonction récursive puissance qui prend deux entiers
    `x` et `n` en paramètre et retourne `x` élevé à la puissance `n`.

    On suppose `n` positif pour faire simple.

    Bien sûr, vous n'utilisez pas l'opérateur "puissance" déjà implémenté en
    Python.


# 2. Chaînes et listes


1.  Palindromes

    Un _palindrome_ est un mot dont les lettres, lues de droites à
    gauche sont les mêmes que celles lues de gauche à droite. Les mots `radar`,
    `elle`, `été`, `ici` sont des palindromes. `DraD` n'est pas un palindrome.

    Implémentez un prédicat récursif qui teste si un mot est un palindrome.

2.  Somme d'une liste

    Implémentez une fonction récursive `somme` qui calcule la somme des
    éléments d'une liste d'entiers passée en paramètre.

    On supposera que la somme d'une liste vide est 0.

3.  Retourner une chaîne de caractères.

    Implémentez une fonction `retourner` paramétrée par une chaîne de
    caractère et qui retourne la même chaîne écrite de droite à gauche.

    ```python
    >>> retourner('robert')
    'trebor'
    ```

4.  Concaténer

    Implémentez une fonction qui concatène deux listes passées en paramètres.

    *   Votre fonction doit être récursive,
    *   Les seules méthodes sur les listes auxquelles vous avez droit sont :
        *  `liste.append(x)` qui ajoute `x` à la fin de `liste`,
        *  `liste.pop(0)` qui retourne le premier élément de `liste` et supprime
            cet élément de la liste.


5.  Occurrences

    Implémentez une fonction récursive qui compte les occurences
    d'une lettre dans un mot.
    Elle prend deux paramètres, la lettre et le mot.

    Elle retourne le nombre de fois où cette lettre apparaît dans
    le mot.


# 3. Recursions élaborées

Dans cette partie nous allons implémenter des récursions plus difficiles.
Certaines utilisent plusieurs appels, d'autres nécessitent d'utiliser un
accumulateur.

Une version "directe", sans récursion est toujours implémentée.


1.  Maximum d'une liste.
    Cette fonction récursive doit renvoyer le plus grand élément d'une liste.

2.  Calculer les combinaisons avec le triangle de Pascal.

3.  `map`, `filter` et `reduce` sont d'importantes fonctions qu'on rencontre en
    _programmation fonctionnelle_.
    Ces trois fonctions sont implémentées nativement dans Python.

    *   `map` prend deux paramètres `fonction` et `list` (en fait un itérable)
        Elle retourne une copie de la liste avec l'image de la fonction
        pour chacun des itérables.

        ```python
        def carre(x):
            return x ** 2

        map(carre, [1, 2, 3])
        ```
        va retourner les carrés des nombres donc `[1, 4, 9]`

    *   `filter` applique un _filtre_ à chaque élément de la liste.
        Elle retoure les éléments de la listes pour lesques `fonction(element)`
        est vrai.

        ```python
        def plus_grand_que_deux(x):
          return x > 2

        filter(plus_grand_que_deux, [1, 4, 0, 6])
        ```

        Va retourner tous les éléments supérieurs à 2 donc `[4, 6]`


    *   `reduce` accumule le résultat d'une opération sur une liste.
        Par exemple pour calculer les produit des éléments d'une liste :

        Attention, la version native de `reduce` doit être importée :

        ```python
        >>> from functools import reduce
        >>> reduce(lambda a, b: a * b, [1, 2, 3, 4])
        24 # produit des nombres de la liste
        ```

    Implémentez les en récursif.


# 4. Autres algorithmes du TD

Si rien ne vous résiste, vous pouvez implémenter les autres exercices vus
en TD.

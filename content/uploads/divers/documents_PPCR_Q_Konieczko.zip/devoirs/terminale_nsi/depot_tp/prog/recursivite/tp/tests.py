import unittest
import simples_corrige as sr
import chaines_listes_corrige as cl
import elabores as ff


class TestSimple(unittest.TestCase):

    def test_somme(self):
        for k in range(15):
            self.assertEqual(sr.somme_entiers(k), sum(list(range(k + 1))))

    def test_factorielle(self):
        from math import factorial
        for k in range(15):
            self.assertEqual(factorial(k), sr.factorielle(k))

    def test_euclide(self):
        from math import gcd
        for a in range(30):
            for b in range(a, 50):
                self.assertEqual(gcd(a, b), sr.euclide(a, b))

    def test_fibonacci(self):
        fibs = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
        for i in range(len(fibs)):
            self.assertEqual(sr.fibonacci(i), fibs[i])

    def test_puissance(self):
        from random import randint
        x = randint(3, 10)
        for n in range(10):
            self.assertEqual(x ** n, sr.puissance(x, n))


class TestChaineListe(unittest.TestCase):

    def test_palindrome(self):
        self.assertTrue(cl.palindrome('cdc'))
        self.assertTrue(cl.palindrome('cdccdc'))
        self.assertTrue(cl.palindrome('cdefedc'))
        self.assertTrue(cl.palindrome('cdeffedc'))
        self.assertFalse(cl.palindrome('cdec'))
        self.assertFalse(cl.palindrome('cdfec'))
        self.assertFalse(cl.palindrome('cdegfedc'))

    def test_somme(self):
        for k in range(20):
            self.assertEqual(sum(list(range(k))), cl.somme(list(range(k))))

    def test_retourner(self):
        lettres = 'abcdefghijlkmnopqrstuvwxyz'
        for k in range(len(lettres)):
            chaine = lettres[:k]
            self.assertEqual(cl.retourner(chaine), chaine[::-1])

    def test_concatener(self):
        liste = list(range(20))
        for k in range(20):
            liste1 = liste[:k]
            liste2 = liste[k:]
            self.assertEqual(cl.concatener(liste1, liste2), liste)

    def test_occurences(self):
        test_case = [
            ["a", "aaa", 3],
            ["z", "zzz", 3],
            ["y", "xyxyxy", 3],
            ["t", "xyxyxy", 0],
        ]
        for lettre, mot, reponse in test_case:
            self.assertEqual(cl.occurences(lettre, mot), reponse)


class TestRectifier(unittest.TestCase):

    def test_maximum(self):
        self.assertEqual(ff.maximum_recursif([2]), 2)
        self.assertEqual(ff.maximum_recursif([]), None)
        self.assertEqual(ff.maximum_recursif([1, 2, 4]), 4)
        self.assertEqual(ff.maximum_recursif([1, 5, 4]), 5)
        self.assertEqual(ff.maximum_recursif([5, 2, 4]), 5)
        from random import shuffle
        l = list(range(10))
        shuffle(l)
        self.assertEqual(ff.maximum_recursif(l), 9)

    def test_combinaison(self):
        from math import comb
        from random import randint
        n = randint(1, 20)
        for k in range(n + 1):
            self.assertEqual(ff.combinaison(n, k), comb(n, k))

    def test_map(self):
        liste = list(range(10))
        for k in range(10):
            self.assertEqual(ff.map_recursion(lambda x: x**2, liste[:k]),
                             list(map(lambda x: x**2, liste[:k])))

    def test_filter(self):
        liste = list(range(10))
        for k in range(10):
            self.assertEqual(ff.filter_recursion(lambda x: x > 3, liste[:k]),
                             list(filter(lambda x: x > 3, liste[:k])))

    def test_reduce(self):
        from functools import reduce
        liste = list(range(1, 10))
        for k in range(2,  9):
            self.assertEqual(ff.reduce_recursion(lambda a, b: a*b, liste[:k]),
                             reduce(lambda a, b: a*b, liste[:k]))

    # def test_isupper(self):
    #     self.assertTrue('FOO'.isupper())
    #     self.assertFalse('Foo'.isupper())
    #
    # def test_split(self):
    #     s = 'hello world'
    #     self.assertEqual(s.split(), ['hello', 'world'])
    #     # check that s.split fails when the separator is not a string
    #     with self.assertRaises(TypeError):
    #         s.split(2)


if __name__ == '__main__':
    unittest.main()

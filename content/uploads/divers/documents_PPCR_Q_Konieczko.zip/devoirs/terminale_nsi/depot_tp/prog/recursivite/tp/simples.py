# 1. Simples


def somme_entiers(n):
    '''
    >>> somme_entiers(0)
    0
    >>> somme_entiers(1)
    1
    >>> somme_entiers(10)
    55
    '''
    pass


def factorielle(n):
    '''
    >>> factorielle(0)
    1
    >>> factorielle(1)
    1
    >>> factorielle(6)
    720
    >>> [factorielle(n) for n in range(7)]
    [1, 1, 2, 6, 24, 120, 720]
    '''
    pass


def euclide(a, b):
    '''
    >>> euclide(10, 20)
    10
    >>> euclide(119, 544)
    17
    '''
    pass


def fibonacci(n):
    '''
    >>> fibonacci(0)
    1
    >>> fibonacci(1)
    1
    >>> fibonacci(2)
    2
    >>> fibonacci(5)
    8
    >>> fibonacci(8)
    34
    '''
    pass


def puissance(x, n):
    '''
    >>> puissance(13, 0)
    1
    >>> puissance(13, 1)
    13
    >>> puissance(5, 2)
    25
    >>> puissance(5, 3)
    125
    >>> puissance(2, 10)
    1024
    '''
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

import threading

total = 10000000
etapes = total // 5


def gros_calcul():
    '''un premier travail'''
    a = 0
    while a < total:
        if a % etapes == 0:
            print("gros calcul :", a)
        a += 1
    print("gros calcul a fini !")


def autre_calcul():
    '''un second travail'''
    b = 0
    while b < total:
        if b % etapes == 0:
            print("autre calcul :", b)
        b += 1
    print("autre calcul a fini !")


# On crée deux fils d'exécution...
t1 = threading.Thread(target=gros_calcul)
t2 = threading.Thread(target=autre_calcul)

# On les lance
t1.start()
t2.start()

# On les termine proprement
t1.join()
t2.join()

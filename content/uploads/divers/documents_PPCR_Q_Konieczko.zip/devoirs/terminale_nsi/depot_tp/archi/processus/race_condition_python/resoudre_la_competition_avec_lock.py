import threading

x = 0


def increment_global():

    global x
    x += 1


def travail_du_fil_d_execution(lock):

    for _ in range(1000000):
        # essaye d'ouvrir le verrou...
        lock.acquire()
        # on arrive ici s'il a ouvert le verrou
        increment_global()
        # on a fini le travail, on libère le verrou
        lock.release()


def resoudre_avec_lock():
    global x
    x = 0

    # crée un verrou. Il ne peut être ouvert que par UN fil d'execution
    # à la fois
    lock = threading.Lock()
    t1 = threading.Thread(target=travail_du_fil_d_execution, args=(lock,))
    t2 = threading.Thread(target=travail_du_fil_d_execution, args=(lock,))

    t1.start()
    t2.start()

    t1.join()
    t2.join()


def main():
    for i in range(5):
        resoudre_avec_lock()
        print("x = {1} apres le tour numéro {0}".format(i, x))


if __name__ == "__main__":
    main()

#!/bin/sh

nice --5 /bin/sh ./runner_1.sh & /bin/sh ./runner_2.sh

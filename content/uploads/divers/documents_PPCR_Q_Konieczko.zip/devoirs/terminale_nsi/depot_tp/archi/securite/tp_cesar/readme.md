---
title: chiffre de César
author: qkzk
date: 2020/04/28
---

# Le chiffre de César

En cryptographie, le **chiffrement par décalage**, aussi connu comme le chiffre
de César, est une méthode de chiffrement très simple utilisée par Jules César
dans ses correspondances secrètes.

Le texte chiffré s'obtient en remplaçant chaque lettre du texte clair original
par une lettre à distance fixe, toujours du même côté, dans l'ordre de
l'alphabet. Pour les dernières lettres (dans le cas d'un décalage à droite),
on reprend au début. Par exemple avec un décalage de 3 vers la droite, A est
remplacé par D, B devient E, et ainsi jusqu'à W qui devient Z, puis X devient
A etc. Il s'agit d'une permutation circulaire de l'alphabet. La longueur du
décalage, 3 dans l'exemple évoqué, constitue la clé du chiffrement qu'il suffit
de transmettre au destinataire — s'il sait déjà qu'il s'agit d'un chiffrement
de César — pour que celui-ci puisse déchiffrer le message. Dans le cas de
l'alphabet latin, le chiffre de César n'a que 26 clés possibles (y compris
la clé nulle, qui ne modifie pas le texte).

![cesar](img/cesar_buste.png)

Il s'agit d'un cas particulier de chiffrement par substitution
monoalphabétique : ces substitutions reposent sur un principe analogue, mais
sont obtenues par des permutations quelconques des lettres de l'alphabet. Dans
le cas général, la clé est donnée par la permutation, et le nombre de clés
possibles est alors sans commune mesure avec celui des chiffrements de César.

Le chiffrement de César a pu être utilisé comme élément d'une méthode plus
complexe, comme le chiffre de Vigenère. Seul, il n'offre aucune sécurité de
communication, à cause du très faible nombre de clés, ce qui permet d'essayer
systématiquement celles-ci quand la méthode de chiffrement est connue, mais
aussi parce que, comme tout encodage par substitution monoalphabétique, il
peut être très rapidement « cassé » par analyse de fréquences (certaines lettres
apparaissent beaucoup plus souvent que les autres dans une langue naturelle).


## Exemple

![cesar](img/cesar.png)

Le chiffrement peut être représenté par la superposition de deux alphabets,
l'alphabet clair présenté dans l'ordre normal et l'alphabet chiffré décalé, à
gauche ou à droite, du nombre de lettres voulu. Nous avons ci-dessous l'exemple
d'un encodage de 3 lettres vers la droite. Le paramètre de décalage (ici 3) est
la clé de chiffrement :


```
clair   : ABCDEFGHIJKLMNOPQRSTUVWXYZ
chiffré : DEFGHIJKLMNOPQRSTUVWXYZABC
```

Pour encoder un message, il suffit de regarder chaque lettre du message clair,
et d'écrire la lettre encodée correspondante. Pour déchiffrer, on fait tout
simplement l'inverse.


```
original : WIKIPEDIA L'ENCYCLOPEDIE LIBRE
encodé   : ZLNLSHGLD O'HQFBFORSHGLH OLEUH
```

Le chiffrement peut aussi être représenté en utilisant les congruences sur les
entiers. En commençant par transformer chaque lettre en un nombre
(A = 0, B = 1,..., Z = 25), pour encoder une lettre `x` avec une clé `n` il
suffit d'appliquer la formule :

```
E_n(x) = x + n  mod 26
```

Le déchiffrement consiste à utiliser la clé opposée `-n` à la place de `n` :

```
D_n(x) = x - n mod 26
```

On peut s'arranger pour que le résultat soit toujours représenté par un entier
de 0 à 25 :

Le décalage demeurant toujours le même pour un même message, cette méthode est
une substitution monoalphabétique, contrairement au chiffre de Vigenère qui
constitue une substitution polyalphabétique.

# Programmer le code César

Plusieurs approches sont possibles :

1. Créer une table d'association comme dans l'exemple,
2. Utiliser les congruences sur les entiers,
3. Combiner les deux.

Nous allons gentillement nous limiter à la seconde.

### Contraintes :

On supposera que les textes à encoder sont tous constitués
de lettres seulement et qu'ils sont tous en minuscule.

À la fin du TP on créera une fonction qui formate un texte pour respecter ces
conditions.

Ainsi on est limité aux 26 lettres de l'alphabet.

Qui plus est, tous les espaces sont supprimés, tous les caractères accentués
sont remplacés par leur lettre minuscule.

```
Robert, ça le gène de défaire sa valise à l'hôpital.
```

Devient :

```
robertcalegenededefairesavalisealhopital
```


## Encoder un entier

### A faire 1

Documentez-vous sur les fonctions `ord` et `chr`

Proposez un exemple d'utilisation de chacune d'entre elles.

### A faire 2

Décaler un entier

Créer une fonction `decaler` qui prend deux entiers, `c` et `n`
et retourne le décalage de `c` par `n` positions modulo 26.

### A faire 3

Fonction `encode`

Cette fonction prend deux paramètres : `lettre` (str) et `cle` (int).

Elle retourne la lettre décalée.

```python
>>> encode('a', 3)
>>> 'd'
>>> encode('x', 3)
>>> 'a'
```

Elle doit aussi fonctionner avec les nombres négatifs :

```python
>>> encode('a', -3)
>>> 'x'
>>> encode('d', -3)
>>> 'a'
```

### A faire 4

La fonction `encoder` (noter le **r**) prend en paramètre
un texte qui respecte les contraintes et un entier et retourne le texte encoder
par le chiffre de César pour ce décalage.

```python
>>> encoder("robertcalegenededefairesavalisealhopital", 3)
'urehuwfdohjhqhghghidluhvdydolvhdokrslwdo'
```

Proposer des exemples d'encodage et de décodage.

On pourra créer une fonction `decoder` qui prend un texte à décoder et la clé
d'origine et appelle `encoder`.

## Formater un texte.

Nous allons transformer un texte en français "normal" avec accent, ponctuation,
majuscule en une chaîne acceptée par la fonction `encoder`.

Plusieurs étapes :

1. Mettre en minuscule,
1. Transformer tous les caractères accentués,
2. Ne conserver que les lettres.

### A faire 5

Documentez vous sur la méthode `lower` des chaînes de caractères.

### A faire 6

Caractères accentués :


```python
accents = { 'a': ['à', 'ã', 'á', 'â'],
            'e': ['é', 'è', 'ê', 'ë'],
            'i': ['î', 'ï'],
            'u': ['ù', 'ü', 'û'],
            'o': ['ô', 'ö'] }
```


A l'aide du dictionnaire `accents` et de deux boucles imbriquées,
débarassez-vous des accents dans le texte source.

On pourra utiliser la fonction `replace` de la méthode des chaînes
de caractères.

### A faire 7

Le module `string` contient une variable `ascii_lowercase` qui est
simplement la chaîne `'abcdefghijklmnopqrstuvwxyz'`

Importez la et affectez la à une variable `lettres`

A l'aide d'un parcourt de votre texte source, débarassez-vous de tout
ce qui n'est pas une lettre.

### A faire 8

La fonction `formater` prend un texte source en français et retourne
un texte constitué des minuscules accentuées.

* Les lettres accentuées sont remplacées
* Les autres symboles disparaissent.

Vous avez maintenant tous les éléments pour la construire proprement.


```python
>>> formater("Robert, ça le gène de défaire sa valise à l'hôpital.")
'robertalegenededefairesavalisealhopital'
```

## Décrypter le code César

Le principe du code César est très simple, une est toujours envoyée
sur une même lettre.

Ainsi, la lettre la plus fréquente de l'alphabet, le `e` est toujours envoyé
sur le même symbole.

Imaginons qu'on ait intercepté le texte :

```
'vsfivxepikirihihijemviwezepmwieplstmxep'
```

et qu'on sache qu'il ait été encodé par le chiffre de César.

Quelle est la clé ?

Facile !

1.  On repère la lettre la plus fréquente dans le texte... c'est le `i`
2.  On calcule le décalage nécessaire pour revenir à `e` :
    De `i` à `e` il faut reculer de 4 positions.

    On décode avec cette clé et ça devrait marcher !


    ```
    vsfivxepikirihihijemviwezepmwieplstmxep
    ```

    Décalé de -4 ça donne :

    ```
    robertalegenededefairesavalisealhopital
    ```

    Qui était le message secret.

Une autre approche serait d'afficher les 26 combinaisons possibles
à et de choisir la seule qui veuille dire quelque chose...

### A faire 9

Première étape, créer une table des effectifs.

La fonction `calculer_effectifs` prend un texte en entrée et retourne
la table des effectifs de ce texte.

Elle se code en 4 lignes !

```python
>>> calculer_effectifs('vsfivxepikirihihijemviwezepmwieplstmxep')
{'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 6, 'f': 1, 'g': 0, 'h': 2, 'i': 8, 'j': 1,
 'k': 1, 'l': 1, 'm': 3, 'n': 0, 'o': 0, 'p': 4, 'q': 0, 'r': 1, 's': 2, 't': 1,
 'u': 0, 'v': 3, 'w': 2, 'x': 2, 'y': 0, 'z': 1}
```

### A faire 10

Repérer la lettre la plus fréquente dans la table des effectifs...

Ce n'est pas si simple.

On peut parcourir le tableau des effectifs et repérer la valeur la plus élevée,
On peut ruser et faire autrement.

Débrouillez vous :)

### A faire 11

La fonction `dechiffrer` prend un texte chiffré par le code César
et retourne sa version déchiffrée.

* Elle commence par déterminer la lettre la plus fréquente,
* Ensuite on calcule la clé correspondante,
* enfin on décode grâce à cette clé.

## Conclusion

En quelques fonctions nous avons illustré le code César.

Non seulement on l'encode proprement mais on peut s'assurer
qu'un texte source sera accepté grâce à la fonction `formater`

---

D'autres chiffres sont "faciles" à mettre en oeuvre.
Nous allons maintenant étudier un procédé très différent qui
change l'ordre des lettres dans une phrase.

'''
Utilise threading pour illustrer.

Les deux fils d'exécution sont lancés en série

Le résultat (la valeur de la variable globale x à l'issue de l'exécution)
est prévisible

'''

import threading

x = 0


def increment_global():

    global x
    x += 1


def travail_du_fil_d_execution():

    for _ in range(1000000):
        increment_global()


def serie():

    global x
    x = 0

    # Exécution en série de deux "threads"
    t1 = threading.Thread(target=travail_du_fil_d_execution)
    t1.start()
    t1.join()

    # on arrive ici quand le premier a terminé...

    t2 = threading.Thread(target=travail_du_fil_d_execution)
    t2.start()
    t2.join()

    # on arrive là quand le second a terminé


def main():
    for i in range(5):
        serie()
        print("x = {1} after Iteration {0}".format(i, x))


if __name__ == '__main__':
    main()

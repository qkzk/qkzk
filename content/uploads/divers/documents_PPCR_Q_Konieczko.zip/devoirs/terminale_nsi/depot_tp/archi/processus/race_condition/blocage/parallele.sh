#!/bin/sh

rmdir /tmp/myscript.lock 2>/dev/null;

/bin/sh ./lockfile.sh 1 & /bin/sh ./lockfile.sh 2

sleep 4

rmdir /tmp/myscript.lock

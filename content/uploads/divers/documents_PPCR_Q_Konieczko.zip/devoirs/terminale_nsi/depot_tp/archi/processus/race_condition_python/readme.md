---
title: NSI Terminale
subtitle: "processus : interblocage, condition de compétition, calculabitié"
author: |
    | qkzk
    | Lycée des Flandres
date: mai 2020
theme: metropolis
geometry: margin=1.5cm
---

# Condition de compétition, Interblocage, Calculabitié

Voilà trois problèmes  majeurs et différents qu'on rencontre lorsqu'on essaye
de faire du calcul en parallèle.

**Condition de compétition :**

> Situation crée quand plusieurs processus essayent d'accéder en même temps à
> une même ressource.
>
>
> Une situation caractérisée par un résultat différent selon l'ordre dans lequel agissent les acteurs du système.
>
>
> Une situation de compétition peut survenir dès que plusieurs acteurs tentent d'accéder au même moment à une ressource partagée et que l'un d'entre eux est susceptible de modifier son état.
>
>
> Les situations de compétition sont des problèmes particulièrement difficiles à identifier et à corriger puisqu'ils ne surviennent que suite à l'ordonnancement particulier et difficilement reproductible d'une séquence d'événements.


**Interblocage :**

> Situation qui se créent quand deux processus essayent d'accéder à plusieurs
> ressources **dont l'usage est exclusif**.
> Si l'un des processus acquiert la ressource A et l'autre la B, et qu'ils doivent
> tous les deux disposer de A et de B en même temps pour avancer, les processus
> sont bloqués.


> _Exemple_ : du riz, deux philosophes et seulement deux baguettes.
>
> Robert et Marcel, deux philosophes, essayent de manger du riz avec leurs baguettes.
> Problème : Ils n'ont que deux baguettes...
>
> Robert en prend une, Marcel prend l'autre... et ils sont bloqués.
> Tant que l'un n'a pas libéré la baguette, l'autre ne peut rien faire.

**Problème de l'arrêt :**

> Peut-on toujours prédire, à l'avance, qu'une fonction va se terminer ?
> La réponse est non mais les arguments, souvent abstraits peuvent surprendre.
> Nous allons rencontrer un programme très concret qui a une chance sur six de
> se terminer.
> Cinq fois sur six il se bloque et plus rien ne se passe.

## Illustrer ces phénomènes en Python

Pour d'évidentes raisons, le multi-threading n'est pas au programme.
Donc c'est difficile d'attendre de vous un exercice de programmation très avancé.

Je vais néanmoins en expliquer les concepts clés afin que vous puissiez comprendre.

## Un tout petit peut de multithreading

multithreading : plusieurs fils d'exécution.

Le principe du multithreading permet d'utiliser deux concepts a priori
incompatibles dans un même programme.

Lancer un calcul... et écouter des événements dans un même programme.

Mon programme est un serveur web. Il passe son temps à attendre que
quelqu'un se connecte pour lui servir des pages web.

```
Serveur : lancement. Mon ip est 1.2.3.4
Serveur : écoute sur le port 80 ...

                                        Navigateur web 1 : je me connecte sur 1.2.3.4:80
Serveur : le client 1 s'est connecté !
Serveur : voici ta page web     ---->
                                        Navigateur web 1 : j'ai reçu une page, je l'affiche

Serveur : écoute sur le port 80 ...

                                        Navigateur web 2 : je me connecte sur 1.2.3.4:80

Serveur : le client 2 s'est connecté !
Serveur : voici ta page web     ---->
                                          Navigateur web 2 : j'ai reçu une page, je l'affiche
```

C'est de la programmation événementielle. On réagit à un événement qui
s'est produit.

Problème : en plus de servir des pages, le serveur web doit aussi réaliser
des calculs ! Par exemple générer une scène 3D très compliquée.

(bon en pratique personne ne ferait ça, on crée deux programmes et voilà !)

Mais supposons...

Comment réaliser à la fois l'attente d'un client web et le calcul ?

On lance deux fils d'exécution. Dans le premier on réalise l'attente,
dans le second on fait le calcul.

## Très bien, super !

Un exemple ?

[exemple_threading.py](exemple_threading.py)

```python
import threading

total = 10000000
etapes = total // 5

def gros_calcul():
  '''un premier travail'''
  a = 0
  while a < total:
    if a % etapes == 0:
      print("  gros calcul :", a)
    a += 1
  print("  gros calcul a fini !")

def autre_calcul():
  '''un second travail'''
  b = 0
  while b < total:
    if b % etapes == 0:
      print("autre calcul :", b)
    b += 1
  print("autre calcul a fini !")

# On crée deux fils d'exécution...
t1 = threading.Thread(target=gros_calcul)
t2 = threading.Thread(target=autre_calcul)

# On les lance
t1.start()
t2.start()

# On les termine proprement
t1.join()
t2.join()
```

Et voici ce qui se passe lorsqu'on exécute ce programme :


```bash
$ python exemple_threading.py

  gros calcul : 0
autre calcul : 0
autre calcul : 2000000
  gros calcul : 2000000
autre calcul : 4000000
  gros calcul : 4000000
autre calcul : 6000000
  gros calcul : 6000000
autre calcul : 8000000
  gros calcul : 8000000
autre calcul a fini !
  gros calcul a fini !



$ python exemple_threading.py

autre calcul : 0
  gros calcul : 0
autre calcul : 2000000
  gros calcul : 2000000
autre calcul : 4000000
  gros calcul : 4000000
autre calcul : 6000000
  gros calcul : 6000000
  gros calcul : 8000000
autre calcul : 8000000
  gros calcul a fini !
autre calcul a fini !
```


Super !

Les deux fils d'exécution se sont lancés en même temps
et ont été exécutés chacun leur tour.

Remarquons qu'ils ont progressé régulièrement.
C'est Python qui décide de l'orchestration.

Remarquons aussi qu'ils ne terminent pas toujours dans le même
ordre.

Pourquoi ?

Parce que d'autres phénomènes interviennent, ce qui se passe
dans la machine en dehors de l'exécution du programme.

Le développeur n'a aucune prise là dessus.

C'est un **énorme** problème.


Revenons un instant sur l'orchestration.

En pratique il se passe ça :

Python :
```
fait tourner t1 pendant quelques ms
fait tourner t2 pendant quelques ms
fait tourner t1 pendant quelques ms
fait tourner t2 pendant quelques ms
fait tourner t1 pendant quelques ms
fait tourner t2 pendant quelques ms
fait tourner t2 pendant quelques ms
etc.
```

A aucun moment les fils n'ont tourné EN MÊME TEMPS.

C'est absolument impossible en python avec du multithreading.

Même si vous disposez de 64 coeurs de processeurs sur votre machines,
un programme Python n'en utilisera qu'un.

Pour utiliser plusieurs coeurs, il faut utiliser un autre module,
appelé `subprocess`. C'est quasi pareil et ça ne résout pas
les problèmes que nous allons présenter.

C'est parfois mieux, parfois inutilement compliqué.

---

Revenons à nos moutons !

## Condition de compétition

Le programme précédent ne se termine pas toujours dans le même ordre...


Est-ce génant ?

Oui parfois.

Imaginons qu'on réalise un calcul utilisant une même donnée **globale**,
selon l'ordre d'exécution, on peut obtenir des résultats différents...

[race_condition.py](race_condition.py)

```python
import threading
x = 0

def incremente_global():
    global x
    x += 1

def travail_du_fil_d_execution():
    for _ in range(1000000):
        incremente_global()

def parallele():
    global x
    x = 0
    t1 = threading.Thread(target=travail_du_fil_d_execution)
    t2 = threading.Thread(target=travail_du_fil_d_execution)

    # on les lance tous les deux
    t1.start()
    t2.start()
    # il s'exécutent tous les deux en même temps et changent la valeur de x

    t1.join()
    t2.join()
    # on arrive ici quand ils ont terminé tous les deux... MAIS...
    # le résultat est imprévisible

def main():
    for i in range(5):
        parallele()
        print("x = {1} apres le tour numéro {0}".format(i, x))

if __name__ == '__main__':
    main()
```


Que fait ce programme ?

1. On donne à `x` la valeur 0. `x` est une variable **globale**.
2. On utilise deux fils qui augmentent `x` de 1 million de fois chacun.
3. Un fois qu'ils ont terminé, on affiche `x`.

Et on recommence ça cinq fois, pour illustrer.

On devrait, toujours, obtenir `x = 2 millions` à la fin.

N'est-ce-pas ?

???

Non ?

```bash
$ python race_condition.py
x = 1688663 apres le tour numéro 0
x = 1527275 apres le tour numéro 1
x = 1553485 apres le tour numéro 2
x = 1630084 apres le tour numéro 3
x = 1481939 apres le tour numéro 4
```

En pratique, jamais.

### Pourquoi est ce qu'on n'arrive jamais à 2 millions ?

Les deux processus travaillent chacun leur tour et Python décide de les arrêter
et de les reprendre quand il le souhaite.

L'opération `x += 1` est en fait une succession d'étapes (souvenez-vous de l'assembleur !) :

* lire la valeur de x,
* calculer la valeur de x + 1,
* écrire le résultat en mémoire.

Il arrive qu'ils lisent la valeur `x` chacun leur tour, calculent
`x+1` chacun de leur côté et écrivent en mémoire le résultat.

```
fil 1 lit x : 123456
                                        fil 2 lit x : 123456
fil 1 calcule x + 1 : 123457
                                        fil 2 calcule x + 1 : 123457
fil 1 écrit la valeur : x = 123457
                                        fil 2 écrit la valeur : x = 123457
```

Combien de fois est-ce que ça arrive ?

On peut l'estimer ! On obtient 1.6 millions et pas 2 millions (en moyenne),
ça s'est donc produit 40% du temps.

**Conclusion :**

1. Les variables globales c'est le mal (souvenez-vous, je le disais à chaque utilisation dans pygame zero !)
2. Le multithreading c'est compliqué.

### pas utiliser globales des multithreading de variables Il ne faut en

what ?

### Il ne faut pas utiliser de variables globales en multithreading !

Parce qu'on ne sait pas dans quel ordre elles seront manipulées.


## Comment résoudre les conditions de compétition ?

Plusieurs approches :

1. Lancer en série : attendre que l'un ait terminé avant de lancer l'autre !
2. Empêcher l'emploi de variables globales.
3. Utiliser des vérrous.

Les solutions 1 et 2 ne sont pas toujours possibles.

* il arrive qu'on doive vraiment faire du calcul en parallèle !
* la "variables globale" n'est qu'un exemple de ressources commune. Si la ressource est une base
  de donnée on est bien embêté.

Néanmoins illustrons

[deux_fils_serie.py](deux_fils_serie.py)
```python
...

def parallele():
    global x
    x = 0
    t1 = threading.Thread(target=travail_du_fil_d_execution)
    t2 = threading.Thread(target=travail_du_fil_d_execution)

    # On lance t1 et on attend qu'il ait terminé...
    t1.start()
    t1.join()

    # on lance t2 et on attend qu'il ait terminé
    t2.start()
    t2.join()
    # on arrive ici quand ils ont terminé tous les deux...
...
```

```bash
$ python
x = 2000000 apres le tour numéro 0
x = 2000000 apres le tour numéro 1
x = 2000000 apres le tour numéro 2
x = 2000000 apres le tour numéro 3
x = 2000000 apres le tour numéro 4
```

Dans ce cas le multithreading ne sert à rien du tout...

Comment refaire du multithreading et empêcher les condtions de compétitions ?

### Vérrous ?

Qu'est-ce ?

Imaginez le verrou plutôt comme un drapeau. Seul celui qui a le drapeau
peut faire le travail.

Comme il n'y a qu'un drapeau, on est sauvé !

On peut utiliser la ressource globale sans problème, une seule personne
travaillant dessus.

[resoudre_la_competition_avec_lock.py](resoudre_la_competition_avec_lock.py)

```python
import threading
x = 0

def increment_global():
    global x
    x += 1


def travail_du_fil_d_execution(lock):
    for _ in range(1000000):
        # essaye d'ouvrir le verrou...
        lock.acquire()
        # on arrive ici s'il a ouvert le verrou
        increment_global()
        # on a fini le travail, on libère le verrou
        lock.release()


def resoudre_avec_lock():
    global x
    x = 0
    # crée un verrou. Il ne peut être ouvert que par UN fil d'execution
    # à la fois
    lock = threading.Lock()

    # on crée les fils
    t1 = threading.Thread(target=travail_du_fil_d_execution, args=(lock,))
    t2 = threading.Thread(target=travail_du_fil_d_execution, args=(lock,))

    t1.start()
    t2.start()

    t1.join()
    t2.join()

def main():
    for i in range(5):
        resoudre_avec_lock()
        print("x = {1} after Iteration {0}".format(i, x))

if __name__ == "__main__":
    main()
```

Dont l'exécution donne :

```bash
% python resoudre_la_competition_avec_lock.py
x = 2000000 apres le tour numéro 0
x = 2000000 apres le tour numéro 1
x = 2000000 apres le tour numéro 2
x = 2000000 apres le tour numéro 3
x = 2000000 apres le tour numéro 4
```

**Problèmes**

1. C'est nettement plus lent qu'une exécution en série (ou en parallèle "classique")
2. Les verrous c'est piégeux

Pourquoi est-ce plus lent ? Parce que le fil doit examiner l'état du vérrou,
prendre le verrou, libérer le vérrou... toutes ces opérations finissent par peser.

Pourquoi est-ce piégeux ? Parce qu'avec plusieurs verrous on peut créer
de l'interblocage.

# Interblocage


**Interblocage :**

> Situation qui se créent quand deux processus essayent d'accéder à plusieurs
> ressources **dont l'usage est exclusif**.
> Si l'un des processus acquiert la ressource A et l'autre la B, et qu'ils doivent
> tous les deux disposer de A et de B en même temps pour avancer, les processus
> sont bloqués.


Exemple : du riz, des baguettes et deux philosophes.

Robert et Marcel, deux philosophes, essayent de manger du riz avec leurs baguettes.
Problème : Ils n'ont que deux baguettes...

Robert en prend une, Marcel prend l'autre... et ils sont bloqués.
Tant que l'un n'a pas libéré la baguette, l'autre ne peut rien faire.

[interblocage_diner_philosophes.py](interblocage_diner_philosophes.py)

```python

import threading
from time import sleep
from random import random

a_lock = threading.Lock()
b_lock = threading.Lock()


def robert():
    sleep(random())
    with a_lock:
        print("robert", "j'ai la baguette a !")
        sleep(random())
        print("robert", "j'essaye de prendre la baguette b")
        with b_lock:
            print("robert", "j'ai la baguette b !")
            c = 0
            while c < 1000000:
                c += 1
            print("moi robert, j'ai mangé ", c, "grains de riz")
        print("robert", "j'ai libéré la baguette b")
    print("robert", "j'ai libéré la baguette a")


def marcel():
    sleep(random())
    with b_lock:
        print("marcel", "j'ai la baguette b !")
        sleep(random())
        print("marcel", "j'essaye de prendre la baguette a")
        with a_lock:
            print("marcel", "j'ai la baguette a !")
            c = 0
            while c < 1000000:
                c += 1
            print("moi marcel, j'ai mangé ", c, "grains de riz")
        print("marcel", "j'ai libéré la baguette a")
    print("marcel", "j'ai libéré la baguette b")


t1 = threading.Thread(target=robert)
t2 = threading.Thread(target=marcel)

t1.start()
t2.start()

t1.join()
t2.join()
```

Et voici ce qui arrive quand on l'exécute :


```
$ python interblocage_diner_philosophes.py

robert j'ai la baguette a !
marcel j'ai la baguette b !
robert j'essaye de prendre la baguette b
marcel j'essaye de prendre la baguette a

^CTraceback (most recent call last):
  File "interblocage_diner_philosophes.py", line 72, in <module>
    t1.join()
  File "/usr/lib/python3.8/threading.py", line 1011, in join
    self._wait_for_tstate_lock()
  File "/usr/lib/python3.8/threading.py", line 1027, in _wait_for_tstate_lock
    elif lock.acquire(block, timeout):
KeyboardInterrupt

^CException ignored in: <module 'threading' from '/usr/lib/python3.8/threading.py'>
Traceback (most recent call last):
  File "/usr/lib/python3.8/threading.py", line 1388, in _shutdown
    lock.acquire()
KeyboardInterrupt:
```

Ils ont pris chacun une baguette et ont attendu indéfiniment que l'autre
la lâche... Ce qui n'allait jamais arriver.

Remarquez les deux `KeyboardInterrupt` j'ai dû faire `CTRL + C` deux fois
pour arrêter chacun des fils.

ou bien

```
$ python interblocage_diner_philosophes.py

marcel j'ai la baguette b !
marcel j'essaye de prendre la baguette a
marcel j'ai la baguette a !
moi marcel, j'ai mangé  1000000 grains de riz
marcel j'ai libéré la baguette a
marcel j'ai libéré la baguette b
robert j'ai la baguette a !
robert j'essaye de prendre la baguette b
robert j'ai la baguette b !
moi robert, j'ai mangé  1000000 grains de riz
robert j'ai libéré la baguette b
robert j'ai libéré la baguette a
```

Marcel a été plus véloce et a pris les deux baguettes en premier.

Il mangé tout son riz et libéré les baguettes, Robert a pu s'en saisir.

Le programme s'est correctement terminé.


---

Peut-on prédire à l'avance si les philosophes vont réussir à manger ?

Non, c'est "aléatoire". En fait, pas vraiment "aléatoire" mais totalement
imprévisible. Ça dépend de phénomènes extérieurs, en particulier l'état
complet de la machine au moment du lancement. Dur.

Combien de fois ça arrive ?

Et bien j'ai simulé (et fait un peu de maths pour vérifier), 5 fois sur 6
les deux philosophes s'emparent d'une baguette et on est cuits.

### Peut-on résoudre le problème ?

Oui, très simplement, il suffit, par exemple, d'imposer un ordre dans la
prise des baguettes.

La baguette `a` doit être prise avant la baguette `b`.

Dans ce cas il sera impossible que chaque philosophe ait pris l'une des
baguette.

[resolution_diner_philosophes.py](resolution_diner_philosophes.py)

```python
...
def robert():
    sleep(random())
    with a_lock:
        print("robert", "j'ai la baguette a !")
        sleep(random())
        print("robert", "j'essaye de prendre la baguette b")
        with b_lock:
            print("robert", "j'ai la baguette b !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi robert, j'ai mangé ", c, "grains de riz")
        print("robert", "j'ai libéré la baguette b")
    print("robert", "j'ai libéré la baguette a")


def marcel():
    sleep(random())
    with a_lock:
        print("marcel", "j'ai la baguette a !")
        sleep(random())
        print("marcel", "j'essaye de prendre la baguette b")
        with b_lock:
            print("marcel", "j'ai la baguette b !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi marcel, j'ai mangé ", c, "grains de riz")
        print("marcel", "j'ai libéré la baguette b")
    print("marcel", "j'ai libéré la baguette a")
...
```

Remarquez bien l'ordre : `with a_lock` puis `with b_lock` pour chacun
des deux.

```
$ python resolution_diner_philosophes.py

robert j'ai la baguette a !
robert j'essaye de prendre la baguette b
robert j'ai la baguette b !
moi robert, j'ai mangé  1000000 grains de riz
robert j'ai libéré la baguette b
robert j'ai libéré la baguette a
marcel j'ai la baguette a !
marcel j'essaye de prendre la baguette b
marcel j'ai la baguette b !
moi marcel, j'ai mangé  1000000 grains de riz
marcel j'ai libéré la baguette b
marcel j'ai libéré la baguette a
```

Cette fois le "vainqueur" reste aléatoire, cela dépend du `random()`
dans chaque fonction... C'est normal.

Bon ?! C'est fini ?!

Presque !

# Problème de l'arrêt



**Problème de l'arrêt :**

> Peut-on toujours prédire, à l'avance, qu'une fonction va se terminer ?
> La réponse est non mais les arguments, souvent abstraits peuvent surprendre.

Revenons sur la version précédente !

Le code de la fonction ne change pas mais selon son exécution,
on ne peut savoir à l'avance s'il va se terminer...

C'est un exemple concret du problème de l'arrêt : le code d'un programme,
seul, ne suffit pas à répondre à la question : le programme va-t-il s'arrêter ?

**Attention** cet exemple _n'est pas_ ce qu'on attendra de vous si on vous
pose la question dans un contexte d'examen.

Ce n'est qu'une illustration triviale.

Je doute qu'on vous interroge sur la démonstration formelle du problème
de l'arrêt mais nous l'étudierons en détail plus tard dans l'année.

# Conclusion

Condition de compétition et interblocage sont des problèmes qu'il n'est pas
toujours possible de résoudre. C'est généralement le travail du système
d'exploitation mais un programme mal implémenté qui utilise une ressource
commune risque toujours de les créer.

Ces problèmes apparaissent naturellement dès qu'on doit travailler avec
plusieurs fils d'exécution.

N'imaginez pas que je vous dissuade de le faire, simplement, gardez en tête
ces soucis et documentez-vous avant de programmer.

---

from random import random


def simuler():
    eff = 0
    total = 1_000_000
    for _ in range(total):
        if random() + random() < random():
            eff += 1
    return eff / total  # 0.16667... approx 1/6


if __name__ == '__main__':
    print(simuler())
    print(1/6)

---
title: "NSI - Terminale"
subtitle: "Architecture - Ordonnancement des processus"
author: "qkzk"
date: "2020/11/21"

---

# Ordonnancement

En Cours & TD vous avez vus quelques algorithmes d'ordonnancement.

Ci-joint un squelette pour les illustrer.

Les deux algorithmes sont documentés et illustrés dans le code.

À vous d'en écrire le code.



---
title: Chiffrement par transposition
author: qkzk
date: 2020/04/28
---



Extrait de [Petite taxinomie du chiffrement symétrique classique](https://fr.wikipedia.org/wiki/Cryptographie_sym%C3%A9trique) sur Wikipédia :

# Transposition

Pour les transpositions on modifie l'ordre des symboles du texte clair. Une
technique consiste à se donner un mot clé, à écrire le message sous ce mot clé
et à lire le texte en colonne, par ordre alphabétique.


```
Message           : wikipediaestuneencyclopedielibre
Mot clé           : crypto
on écrit sous       wikipe
le mot clé          diaest
                    uneenc
                    yclope
                    dielib
                    re****


lettre du mot clé
(ordre alphabétique) coprty
on ordonne les       weiipk
colonnes             dteisa
                     ucenne
                     yeocpl
                     dbliie
                     r**e**
```

Message chiffré   : `wduydr etceb* ieeol* iincie psnpi* kaele*`
Les astérisques sont ajoutés pour le déchiffrement et les espaces dans le
message chiffré uniquement pour la lisibilité. Le message, s'il était par
exemple envoyé à un destinataire qui connaît le mot clé, serait le suivant :

Message chiffré   : `wduydretceb*ieeol*iinciepsnpi*kaele*`


---

A faire :

Programmez ça.

Débrouillez vous.

---

Non je plaisante, je vais vous aider.

Déjà, si vous voulez voir la méthode en action, bibm@th propose un [exemple](http://www.bibmath.net/crypto/index.php?action=affiche&quoi=ancienne/transposition)

Voici les étapes que vous pouvez envisager :

1.  Transformer une chaîne de caractères en une matrice de lettres.
    Chaque ligne de la matrice est une liste de même taille que la clé.

    Commencez par déterminer le nombre de blocs.

    Parcourez votre texte en remplissez la matrice au fur et à mesure.

2.  Remarquons que le texte est "rempli" de symboles `*` à la fin, afin d'avoir
    des blocs comportant tous la même taille.

    Déterminez soigneusement le nombre d'étoiles à ajouter à la fin.

    Ajoutez assez d'étoiles à la fin de la matrice.
3.  Afin de réaliser les échanges il faut transposer la matrice :

    ```
    matrice de départ

    1 2 3
    4 5 6

    matrice transposée

    1 4
    2 5
    3 6
    ```

    Il existe des astuces et des fonctions en une ligne, nous allons faire
    simplement.

    1.  Créer une matrice remplie de zéros `transposee` dans la taille voulue

        Si `matrice` a 2 lignes et 3 colonnes, `transposee` a 3 lignes et 2
        colonnes

    2.  Parcourir `matrice` avec deux boucles imbriquée. Réfléchir un moment
        et remplir `transposee` avec la bonne valeur.

4.  Déterminer l'ordre de lecture de la clé. La clé est rangée par ordre
    alphabétique, cette fonction `ordre_lecture` prend la clé en paramètre
    et retourne simplement la position finale de chaque lettre de départ.

    `crypto` devient `coprty` une fois rangé donc :

    ```python
    >>> ordre_lecture('crypto')
      [0, 5, 3, 1, 4, 2]
    ```

    C'est un peu plus difficile, je vous conseille d'écrire au brouillon vos
    approches.

5.  Ordonner les colonnes. Chaque colonne est ordonnée selon le résultat
    d'ordre lecture, cela revient simplement à faire des échanges sur la
    transposée de la matrice de lettres.

    A cette étape, vous avez une matrice de lettres dans l'ordre de sortie.

    Par exemple si les échanges sont notés ainsi `[2, 1, 0]` qui signifie que :

    *   la colonne 0 doit aller en 2,
    *   la colonne 1 doit rester à sa place,
    *   la colonne 2 doit aller en 0,

    notre fonction doit faire ceci :

    ```python
    >>> ordonner_colonnes(['a', 'b', 'c'], [2, 1, 0])
    ['c', 'b', 'a']
    ```

6.  Lire la matrice. Mettre tout ça à plat et retourner une chaîne.

7.  Piloter le tout dans une fonction `encoder`. Elle prend un texte et une clé
    et retourne le texte encodé.

### Fin de l'encodage

## Décodage

Décoder un texte revient à faire les étapes dans un ordre différent :

1. créer la matrice de lettres,
2. **réordonner les colonnes,**
3. transposer,
4. lire le texte,
5. retirer les étoiles éventuelles ajoutées par l'encodage.

Attention, l'_ordre_ des lequel les colonnes doivent être rangées n'est plus
le même. Cette fois on part de la clé "triée par ordre alphabétique" vers
la "clé de départ" !

Il n'y a donc que deux étapes :

1.  Créer une fonction `ordre_inverse` (elle peut simplement travailler avec
    l'ordre obtenu plus tôt)
2.  Créer une fonction qui décode. Elle prend un texte encodé et une clé.

    Elle se contente d'appeler les fonctions précédentes dans l'ordre souhaité.

## Conclusion

Cette méthode de chiffrement est intéressante. Elle commence à ressembler à
des méthodes plus élaborées.

Les lettres d'un texte ne sont pas encodées de la même manière.


Pour une clé très longue, cela peut être intéressant. Mais pour une clé assez
courte, disons 10 caractères on n'a que 3628800 ordres possibles...

Une solution sauvage connaissant la taille de la clé serait de les construire
toutes et de repérer parmi toutes les propositions celle qui contient
le plus de mots de la langue française.

C'est bourrin, mais ça fonctionne.

Il existe des méthodes un peu plus astucieuses pour la briser assez vite.

Elles ne sont pas lourdes en calcul et reposent sur la tendance qu'ont les
messages à débuter par des "meta" données du style : "De Robert à Nadine".

[Si vous êtes curieux](http://www.bibmath.net/crypto/index.php?action=affiche&quoi=ancienne/vaincretransposition)

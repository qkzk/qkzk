#!/bin/bash

if ! mkdir /tmp/myscript.lock 2>/dev/null; then

    echo "Le processus tourne déjà !" >&2
    exit 1
fi

c=0
while ((c<3)); do
  echo $1
  sleep 1
  c=$c+1
done

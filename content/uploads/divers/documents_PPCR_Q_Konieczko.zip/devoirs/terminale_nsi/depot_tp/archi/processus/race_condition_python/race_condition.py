'''
Utilise threading pour montrer une condition de compétition.

Le résultat (la valeur de la variable globale x à l'issue de l'exécution)
est imprévisible
'''

import threading
x = 0


def increment_global():
    global x
    x += 1


def travail_du_fil_d_execution():
    for _ in range(1000000):
        increment_global()


def parallele():
    global x
    x = 0
    t1 = threading.Thread(target=travail_du_fil_d_execution)
    t2 = threading.Thread(target=travail_du_fil_d_execution)

    # on les lance tous les deux
    t1.start()
    t2.start()
    # il s'exécutent tous les deux en même temps et changent la valeur de x

    t1.join()
    t2.join()
    # on arrive ici quand ils ont terminé tous les deux... MAIS...
    # le résultat est imprévisible


def main():
    for i in range(5):
        parallele()
        print("x = {1} apres le tour numéro {0}".format(i, x))


if __name__ == '__main__':
    main()

#!/bin/sh

c=0
while ((c<5)); do
  # sleep $((RANDOM % 5 + 1))
  echo "1" #>> vainqueur.txt
  c=$c+1
done

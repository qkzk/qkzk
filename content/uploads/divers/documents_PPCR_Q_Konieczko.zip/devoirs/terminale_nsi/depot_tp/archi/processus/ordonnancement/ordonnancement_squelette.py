'''
Algorithmes d'ordonnancement

Le processeur reçoit une série d'instructions à effectuer
venant de différents processus.

Elle prend la forme d'un tuple constitués de paires (nom: str, nombre: int)

Deux algorithmes sont présentés :

* le plus court d'abord : le processus ayant le moins d'instructions à
    effectuer sera traité intégralement en premier. Jusqu'à épuisement.
* tourniquet : le processeur traite une instruction de chaque processus
    jusqu'à épuisement de l'ensemble.
'''


def plus_court_dabord(proc: tuple) -> list:
    '''
    renvoie l'ordre des instructions effectuées dans le mode
    "plus court d'abord"
    @param proc: (tuple) de la forme (("p1": 2), ("p2": 1))
    @return: (list) ["p2", "p1", "p1"]
    '''
    pass


def tourniquet(proc: tuple) -> list:
    '''
    renvoie l'ordre des instructions effectuées dans le mode "tourniquet"
    @param proc: (tuple) de la forme (("p1": 2), ("p2": 1))
    @return: (list) ["p1", "p2", "p1"]
    '''
    pass


def exemple():
    '''presente les deux ordonnancements'''
    tuple_processus = (("p1", 10), ("p2", 4), ("p3", 5))
    print(plus_court_dabord(tuple_processus))
    print(tourniquet(tuple_processus))


if __name__ == "__main__":
    exemple()

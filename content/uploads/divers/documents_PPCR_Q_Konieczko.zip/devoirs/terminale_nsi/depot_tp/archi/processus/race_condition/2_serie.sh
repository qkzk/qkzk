#!/bin/sh

/bin/sh ./runner_1.sh ; /bin/sh ./runner_2.sh

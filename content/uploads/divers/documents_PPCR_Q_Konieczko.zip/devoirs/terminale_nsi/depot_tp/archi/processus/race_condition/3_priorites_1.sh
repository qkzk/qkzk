#!/bin/sh

nice -10 /bin/sh ./runner_1.sh & /bin/sh ./runner_2.sh

'''
Exemple de programme qui illustre :

* condition de compétition : deux fils d'exécution essayent d'acquerir des ressources
* l'interblocage :
        * si un fil parvient à prendre les 2 ressources, ils terminent.
        * s'ils prennent chacun une des ressources, le programme ne termine pas.
* la calculabilité : le programme se termine parfois, parfois non, de manière aléatoire

---

Robert et Marcel essayent de manger du riz.

Problème : ils n'ont que deux baguettes...

* Si l'un des deux parvient à prendre les deux baguettes avant l'autre,
    il mange et les lâche.

* S'ils prennent chacun une baguette, ils attendent que l'autre soit libérée ...
    ce qui n'arrive jamais : c'est l'interblocage.

* Autre problème sous-jacent, s'ils terminent leur riz, qui aura fini le premier ?
'''


import threading
from time import sleep
from random import random

a_lock = threading.Lock()
b_lock = threading.Lock()


def robert():
    sleep(random())
    with a_lock:
        print("robert", "j'ai la baguette a !")
        sleep(random())
        print("robert", "j'essaye de prendre la baguette b")
        with b_lock:
            print("robert", "j'ai la baguette b !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi robert, j'ai mangé ", c, "grains de riz")
        print("robert", "j'ai libéré la baguette b")
    print("robert", "j'ai libéré la baguette a")


def marcel():
    sleep(random())
    with b_lock:
        print("marcel", "j'ai la baguette b !")
        sleep(random())
        print("marcel", "j'essaye de prendre la baguette a")
        with a_lock:
            print("marcel", "j'ai la baguette a !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi marcel, j'ai mangé ", c, "grains de riz")
        print("marcel", "j'ai libéré la baguette a")
    print("marcel", "j'ai libéré la baguette b")


t1 = threading.Thread(target=robert)
t2 = threading.Thread(target=marcel)

t1.start()
t2.start()

t1.join()
t2.join()

'''
Exemple de programme qui illustre :

Résout le problème du diner des philosophes comment ?
Il suffit d'identifier les verrous et d'imposer un ordre.


On doit prendre a avant de prendre b.


Attention il y a toujours une condtion de compétition, on ne sait pas à
l'avance qui va terminer en premier.

Par contre le programme termine toujours.

'''


import threading
from time import sleep
from random import random

x = 0
a_lock = threading.Lock()
b_lock = threading.Lock()


def robert():
    sleep(random())
    with a_lock:
        print("robert", "j'ai la baguette a !")
        sleep(random())
        print("robert", "j'essaye de prendre la baguette b")
        with b_lock:
            print("robert", "j'ai la baguette b !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi robert, j'ai mangé ", c, "grains de riz")
        print("robert", "j'ai libéré la baguette b")
    print("robert", "j'ai libéré la baguette a")


def marcel():
    sleep(random())
    with a_lock:
        print("marcel", "j'ai la baguette a !")
        sleep(random())
        print("marcel", "j'essaye de prendre la baguette b")
        with b_lock:
            print("marcel", "j'ai la baguette b !")
            c = 0
            while c < 1_000_000:
                c += 1
            print("moi marcel, j'ai mangé ", c, "grains de riz")
        print("marcel", "j'ai libéré la baguette b")
    print("marcel", "j'ai libéré la baguette a")


t1 = threading.Thread(target=robert)
t2 = threading.Thread(target=marcel)

t1.start()
t2.start()

t1.join()
t2.join()

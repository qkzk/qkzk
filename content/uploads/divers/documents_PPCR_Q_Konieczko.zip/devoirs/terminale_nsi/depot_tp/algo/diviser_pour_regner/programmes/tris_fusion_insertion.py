import doctest
import pylab
from random import shuffle
from time import time


def tri_insertion(tableau):
    '''
    Réalise un tri par insertion sur un tableau

    Vu en première. Rien à faire.
    @param tableau: (list)
    @SE: modifie le tableau en place

    >>> tableau = list(range(10))
    >>> shuffle(tableau)
    >>> tri_insertion(tableau)
    >>> assert sorted(tableau) == tableau
    '''
    index = 0
    longueur = len(tableau)
    while index < longueur:
        k = index
        while k > 0 and tableau[k] < tableau[k-1]:
            tableau[k], tableau[k-1] = tableau[k-1], tableau[k]
            k -= 1
        index += 1


def tri_fusion(tableau):
    '''
    Réalise un tri fusion sur un tableau
    @param tableau: (list)
    @SE: modifie le tableau en place

    >>> tableau = list(range(10))
    >>> shuffle(tableau)
    >>> tri_fusion(tableau)
    >>> assert sorted(tableau) == tableau
    '''
    pass


def fusion(tableau, gauche, droite):
    '''
    Fusionne deux tableaux (gauche, droite) dans un seul.
    @param tableau, gauche, droite: (list) les tailles doivent
        s'ajouter
    @SE modifie le tableau en place
    '''
    pass


def tri_timsort(tableau):
    '''
    Réalise le tri natif Python.
    Même signature que les autres.
    '''
    tableau.sort()


def exemple():
    tableau = [3, 2, 1]
    tri_insertion(tableau)
    print(tableau)
    tableau = [3, 2, 1]
    tri_fusion(tableau)
    print(tableau)


def generer_tableaux(abscisses):
    tableaux = []
    for k in abscisses:
        nombres = list(range(k))
        shuffle(nombres)
        tableaux.append(nombres)
    return tableaux


def comparer_vitesse():
    '''
    Compare les vitesses de calcul de trois méthodes sur les mêmes tableaux

    * max (natif),
    * max_iteratif,
    * max_diviser_pour_regner

    @return None:
    @SE: display the graph with pylab
    '''

    # enlever le commentaire quand ça marche
    funcs = [tri_fusion, tri_timsort, tri_insertion]

    # suite à compléter
    pass


if __name__ == '__main__':
    exemple()
    comparer_vitesse()

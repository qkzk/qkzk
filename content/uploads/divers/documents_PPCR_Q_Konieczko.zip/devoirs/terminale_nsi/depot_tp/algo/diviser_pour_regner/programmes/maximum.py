import pylab
from random import shuffle
from time import time


def max_iteratif(tableau):
    '''
    Retourne le maximum d'un tableau de nombres
    Méthode itérative

    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> max_iteratif(tableau)
    89
    '''
    elt_max = tableau[0]

    for elt in tableau:
        if elt > elt_max:
            elt_max = elt
    return elt_max


def max_diviser_pour_regner(tableau):
    '''
    Retourne le maximum d'un tableau de nombres
    Méthode diviser pour régner

    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> max_diviser_pour_regner(tableau)
    89
    '''
    # à vous de le programmer
    pass


def exemple():
    tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    print(tableau)
    print("max_iteratif", max_iteratif(tableau))

    # enlever le commentaire quand ça marche !
    # print("max_diviser_pour_regner", max_diviser_pour_regner(tableau))


def generer_tableaux(abscisses):
    tableaux = []
    for k in abscisses:
        nombres = list(range(k))
        shuffle(nombres)
        tableaux.append(nombres)
    return tableaux


def comparer_vitesse():
    '''
    Compare les vitesses de calcul de trois méthodes sur les mêmes tableaux

    * max (natif),
    * max_iteratif,
    * max_diviser_pour_regner

    @return None:
    @SE: display the graph with pylab
    '''
    # prendre la première version quand ça marche.
    # funcs = [max, max_iteratif, max_diviser_pour_regner]
    funcs = [max, max_iteratif]

    # génère une liste de tailles
    abscisses = list(range(100, 5000, 100))
    # génère des tableaux de cette taille
    tableaux = generer_tableaux(abscisses)

    for func in funcs:
        durees = []
        for tableau in tableaux:
            # on mesure la durée de la recherche du max sur ce tableau
            start = time()
            func(tableau)
            end = time()
            # qu'on enregistre
            durees.append(end - start)
        pylab.plot(abscisses, durees, label=func.__name__)
        pylab.legend(loc='upper right')
    pylab.show()


if __name__ == '__main__':
    exemple()
    comparer_vitesse()

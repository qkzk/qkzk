import doctest
import pylab
from time import time

__title__ = "Exponentiation : impérative, récursive et rapide"
__author__ = "qkzk"
__date__ = "2020/03/05"
__doc__ = '''
titre :  {0}
author : {1}
date :   {2}

Implémentation des algorithmes d'exponentiation :

* impérative : avec une boucle
* récursive simple : en calculant étape par etape
* rapide : en divisant par deux

Comparaison des vitesses pour des valeurs régulières
'''.format(__title__, __author__, __date__)


def expo_iteratif(x, n):
    '''
    calcule x**n de manière itérative (avec une boucle)
    @param x: (float)
    @param n: (int) n>= 0
    @return: (float)
    >>> expo_iteratif(3, 0)
    1
    >>> expo_iteratif(3, 4)
    81
    '''
    pass


def expo_recursif(x, n):
    '''
    calcule x**n de manière recursive
    @param x: (float)
    @param n: (int) n>= 0
    @return: (float)
    >>> expo_recursif(3, 0)
    1
    >>> expo_recursif(3, 4)
    81
    '''
    pass


def expo_rapide(x, n):
    '''
    calcule x**n avec l'algorithme d'exponentiation rapide
    @param x: (float)
    @param n: (int) n>= 0
    @return: (float)
    >>> expo_rapide(3, 0)
    1
    >>> expo_rapide(3, 4)
    81
    >>> expo_rapide(3, 5)
    243
    >>> expo_rapide(3, 7)
    2187
    '''
    pass


def expo_natif(x, n):
    '''
    Utilise la puissance implémentée dans Python
    '''
    return x ** n


def exemple():
    '''
    Teste les fonctions implémentées
    '''
    # à faire entièrement
    pass


def comparer_vitesse():
    '''
    Compare les vitesses de calcul de plusieurs fonctions et affiche
    les résultats dans un graphe

    @param funcs: (list of functions) must have signature (float, int) -> any
    @param z: (any) first parameter for func
    @return None:
    @SE: display the graph with pylab
    '''
    # à faire entièrement
    pass


if __name__ == '__main__':
    exemple()
    # comparer_vitesse()

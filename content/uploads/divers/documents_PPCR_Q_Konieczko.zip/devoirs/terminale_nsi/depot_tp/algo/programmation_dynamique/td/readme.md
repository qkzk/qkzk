---
title: Programmation Dynamique
subtitle: Travaux dirigés
author: qkzk
date: 2020/04/30
theme:
- Metropolis
header-includes:
    - \usepackage[margin=1.5cm]{geometry}
---

_Nous allons implémenter certains algorithmes vus en cours et en TD._



# Les nombres de Fibonacci : une comparaison des méthodes

Dans cette première partie nous allons faire une mesure empirique de l'efficacité
de différents algorithmes calculant les nombres de Fibonacci.

Pour mémoire, ils sont donnés par la relation suivante :

```
F(0) = 0, F(1) = 1
F(n+2) = F(n+1) + F(n), pour tout n naturel
```

## Méthode récursive simple

**A faire 1**

1.  Calculer les 10 premiers nombres de Fibonacci à la main.
2.  Créer une fonction récursive naïve `fib_recursif` qui prend un
    entier `n` en paramètre et retourne `F(n)`.`

    Vérifiez votre fonction avec vos valeurs.
3.  À l'aide du module `time` mesurer le temps d'exécution pour `fib_recursif(38)`

    ```python
    from time import time

    debut = time.time() # on lance un chrono
    calcul_complique()  # on mesure la durée d'exécution de ça
    fin = time.time()   # on arrête le chrono

    print(fin - debut)  # on affiche la durée
    ```

    Bilan ? C'est naze.

## Méthode itérative

**A faire 2**

1. Créer une fonction `fib_iteratif` (avec une boucle) qui retourne `F(n)`
2. Mesurer à nouveau le temps d'exécution pour `F(38)`


## Amélioration de la méthode récursive

**A faire 3**

1.  Créer une fonction récursive **avec mémoïsation** qui retourne le n-ième
    nombre de Fibonacci.
2.  Reprendre la comparaison des vitesses. La méthode récursive est-elle
    toujours inefficace ?

**Conclusion :** Le paradigme (itératif / recursif) importe moins que l'algorithme.

Python est optimisé pour les boucles, pas la récursion. Néanmoins, on peut s'en
servir à condition d'avoir un bon algorithme.


# Rendu de monnaie : combien de manières

Vous avez un système de pièces à votre diposition. Chaque pièce  pouvant
être utilisée autant de fois que vous le souhaitez.

Chaque valeur est donnée dans le tableau ` systeme = [s0, s1, ..., sm-1]`

Pouvez-vous déterminer le nombre de manière de rendre le montant avec
ce système ?


1.  Reprendre l'algorithme vu en TD et l'implémenter.

    Créer une fonction `nb_maniere_rendre` qui prend deux paramètres :
    une liste `systeme` comportant les valeurs des pièces et un `montant` (int)
    et qui retourne le _nombre_ de sommes possibles.

**Exemples :**

```python
>>> nb_maniere_rendre([1, 2, 5], 5)
4
>>> nb_maniere_rendre([1, 2, 3], 4)
4
>>> nb_maniere_rendre([1, 2, 3], 7)
8
>>> nb_maniere_rendre([2, 5, 3, 6], 10)
5
>>> nb_maniere_rendre([10], 99)
0
>>> nb_maniere_rendre([4, 5, 6], 0)
1
```

# Rendu de monnaie : nombre minimal de pièces

_C'est le problème déjà abordé en première mais... pour tous les systèmes de_
_pièces_

Avec un système de pièces noté `systeme` et une somme appelée `montant`
combien faut-il de pièces au minimum pour rendre la somme ?

Souvenons nous des flottants. `float(inf)` permet de définir un infini.

1.  Créer une fonction auxiliaire `creer_matrice` qui prend le système et le
    montant et retourne une matrice de taille
    `(nb de pieces + 1) * (montant + 1)`

    * Presque tous ses termes sont nuls,
    * Ceux de la première ligne sont : `[0, inf, inf, ..., inf]`

    ```python
    >>> _creer_matrice_systeme([1, 2], 5)
    [[0, inf, inf, inf, inf, inf],
     [0, 0, 0, 0, 0, 0],
     [0, 0, 0, 0, 0, 0]]
    ```

Cette matrice contiendra nos solutions optimales des sous problèmes.

2.  Implémenter une fonction `nb_minimal_pieces(systeme, montant)` qui retourne
    le nombre minimal de pièces à rendre. Votre fonction utilise la matrice
    crée à la fonction et un algorithme de programmation dynamique.

    ```python
    >>> nb_maniere_rendre([1, 2, 5], 5)
    4
    >>> nb_maniere_rendre([1, 2, 3], 4)
    4
    >>> nb_maniere_rendre([1, 2, 3], 7)
    8
    >>> nb_maniere_rendre([2, 5, 3, 6], 10)
    5
    >>> nb_maniere_rendre([10], 99)
    0
    >>> nb_maniere_rendre([4, 5, 6], 0)
    1
    ```

# Scierie

_On rappelle le problème de la scierie vu en TD._

### Découpe de planches

Lorsqu'elle reçoit en entrée une planche de longueur n, elle
peut

* soit en tirer directement le profit/prix p_n,
* soit chercher à la découper en k morceaux pour en tirer plusieurs (sous)
  planches de longueur `i_1, i_2, ... , i_k` (avec `i_1 + i_2 + ... + i_k = n`)
  et obtenir comme profit la somme `p_i1 + p_i2 + ... + p_ik` des prix de vente des sous-planches.
* Le problème de la scierie est alors de déterminer la solution qui lui garantit un profit maximal.


**Exemple**

| longueur i 	| 1 	| 2 	| 3 	| 4 	| 5  	| 6  	| 7  	| 8  	| 9  	| 10 	|
|-----------	|---	|---	|---	|---	|----	|----	|----	|----	|----	|----	|
| prix p_i   	| 1 	| 5 	| 8 	| 9 	| 10 	| 17 	| 17 	| 20 	| 24 	| 30 	|



 Rappel des questions 7 et 9

**Question 7 du TD :** proposer une fonction récursive `coupe` qui calcule r_n en fonction des
paramètres p (le tableau des prix) et n (la longueur de la planche).

Solution

```
fonction coupe(p, n):
 si n=0 alors retourner 0
 sinon
   q = - infini
   pour i allant de 1 à n
     q = max(q, p[i] + coupe(p, n-i))
   retourner q
```

**Question 9 du TD :** Modifier votre fonction précédente pour qu'elle utilise une solution
mémoizée.

Solution

1. On considère un tableau r[0..n] dont tous les éléments sont initialement tels que
    `r[i] = -infini`
2. de haut en bas

    ```
    Coupe_memoize(p,n,r):
      si r[n] >= 0 alors retourner r[n]
      sinon,
        si n = 0 alors q = 0
        sinon
          q = - infini
          pour i allant de 1 à n
            q = max(q, p[i] + Coupe_memoize(p, n-i, r))
          r[n] = q
        retourner q
    ```

---


**A faire :**
Programmer ces deux fonctions dans un nouveau script

_On pourra noter les prix dans un dictionnaire._



## Pyramides de nombres


Une pyramide de nombre est un graphe donc les sommets sont des nombres
Chaque sommet d'un même niveau a deux arrêtes vers le bas
Deux sommets voisin d'un même niveau sont reliés à un même sommet du niveau
suivant.

```
0      1
1     2 8
2    3 1 2
3   6 4 5 2

0      0
1     1 2
2    3 4 5
3   6 7 8 9
```

**Objectif :** Déterminer la valeur maximale de la somme des chemins traversant une pyramide
de nombre.

Dans le premier exemple, le chemin `[1, 8, 2, 5]` à pour somme 16, qui est maximale.

**A faire 4**

1.  Déterminer le chemin optimal de la seconde pyramide de nombres.

Le fichier [pyramide_eleve](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/algo/programmation_dynamique/td/pyramid_eleve.py) comporte déjà une bonne partie
du travail :

*   La fonction `afficher_pyramide` dessine une pyramide dans la console.

    Attention, il faut se limiter aux entiers entre 0 et 9 sinon il y a des
    décalages.

*   La fonction `calculer_somme_max` est déjà documentée, commentée mais
    j'ai effacé le code.

    Elle suit trait pour trait l'algorithme vu en TD.

2.  Implémentez l'algorithme vu en TD dans la fonction.




## Combinaisons

Programmer les exemples du TD permettant le calcul des _combinaisons_.

## L'escalier


Vous gravissez un escalier. Il faut `n` pas pour atteindre le sommet.\
À chaque étape, vous pouvez gravir une ou deux marches.\

Combien de manières existe-t-il d'atteindre le sommet ?

*   **Exemple 1:**

    Entrée: 2\
    Sortie: 2

    Il y a deux manières d'atteindre le haut.

    1. 1 marche et 1 marche
    2. 2 marches.

*   **Exemple 2:**

    Entrée : 3\
    Sortie : 3

    Il y a trois manières d'atteindre le haut.

    1. 1 marche + 1 marche + 1 marche
    2. 1 marche + 2 marches
    3. 2 marches + 1 marche

1.  Proposer un algorithme de programmation dynamique pour résoudre le problème
2.  Implémenter une fonction qui prend en paramètre le nombre de marches
    et retourne le nombre de manières.

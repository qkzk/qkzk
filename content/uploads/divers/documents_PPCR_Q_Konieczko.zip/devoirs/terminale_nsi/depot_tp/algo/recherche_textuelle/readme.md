---
title: NSI Terminale - Algorithmie
subtitle: Recherche textuelle - TP
author: qkzk
date: 2020/03/14
---



# Recherche Textuelle


Dans ce TP nous allons implémenter les différents algorithmes vus
en TD concernant la recherche textuelle.

Vous pouvez les consulter [ici](https://qkzk.xyz/docs/nsi/cours_terminale/algorithmique/recherche_textuelle/)

Ensuite nous construirons l'index d'un vaste document (roman de 400 pages)
et nous effectuerons quelques comparaisons de vitesse.

Dans tous les cas nos fonctions prennent deux paramètres au moins :

* le _motif_, qui est la séquence de caractère recherchée.
* le _texte_, dans lequel on cherche ce motif.

Un troisième paramètre, éventuel est l'ensemble des caractères autorisés.
On utilisera, généralement les caractères imprimables de la table ascii.

Aussi, on évitera les caractères accentués de la langue française.


## Recherche naïve

Implémenter l'algorithme de recherche naïve.


## Construire un jeu de tests

Construire un jeu de tests qui assure de la validité de votre fonction.

On s'assurera de choisir des cas variés.

## Boyer-Moore-Horspool


### Algorithme du dictionnaire des dernières occurences

 
```
dernière occurrence (motif)
  m = longueur du motif
  créer un dictionnaire associant chaque lettre à m
  pour i allant de 0 à m-2,
      dictionnaire [ motif[i] ] = m - 1 - i
  fin du pour
  retourner le dictionnaire
```

### Algorithme de Boyer-Moore Horspool

```
Boyer-Moore-Horspool(x, t):
  '''
  x : motif, t : texte, m : longueur motif, n : celle du texte
  d : tableau des dernières occurrences du motif
  '''
  tant que j <= n - m,
    i = m - 1
    tant que i >= 0 et t[j + i] = x[i]:
      i = i-1
    fin tant que
    si i = -1 alors
      j est une occurrence de x
      j = j + 1
    sinon
      j = j + d[ t[j + i] ]
    fin du si
  fin du tant que
```

### Consigne

Implémenter ces deux fonctions.

Tester sur des cas variés.


---


## Construire un index sur un vaste document


L'indexation d'un document consiste à construire une table des occurences
de chaque mot.

L'idée est assez simple : un mot commence et se termine par une lettre.

On décide d'une longueur minimale pour définir un mot. Ainsi "a" (du verbe avoir
, "il a") est bien un mot de la langue française mais ne sera peut-être pas
indexé.

Si on prend comme taille minimale 5 alors la phrase :

`"Ce matin, un lapin a tué un chasseur"` aura pour index :

```
{'matin': [3], 'lapin': [12], 'chasseur': [27]}
```

### Ouvrir un chemin et en extraire un texte

On utilisera cette fonction :

```python
def ouvrir(chemin):
    with open(chemin) as f:
        texte = f.read()
    return texte
```


### Nettoyer le document


Le texte que nous allons utiliser, "_Les frères Karamazov_"
de Fiodor Dostoïevski est écrit en français et comporte quelques
caractères difficiles à manipuler, que nous allons remplacer avec cette
fonction :

```python
def preprocess(texte):
    '''
    retourne le texte contenu dans un fichier texte après l'avoir un
    peu nettoyé :
    1. tout en minuscule
    2. on retire les espaces de début et de fin
    3. on enlève les césures
    4. on remplace les apostrophes d'impression par des apostrophes normales

    @param chemin: (str) le chemin d'un fichier texte
    @return: (str) le contenu de ce fichier nettoyé
    '''
    texte = texte.lower().strip()
    texte = texte.replace('¬\n', '')
    texte = texte.replace("’", "'")
    return texte
```

Remarquons qu'on en profite pour convertir tous les caractères en minuscules.

### Indexer le texte

On décide qu'un mot est une suite de lettres entourée de deux symboles qui ne 
sont pas des lettres.


Une fois le texte nettoyé, voici l'algorithme utilisé pour l'indexation :


```
k = 0
Tant que k < longueur du texte:
    
    i = 0
    Tant que k + i < longueur du texte et texte[k + i] est une lettre
        i = i + 1
    si i > taille minimale d'indexation,
        mot = texte[k ... k+i]
        on ajoute l'occurence du mot à l'index
    sinon si i == 0, 
        # le symbole n'était pas une lettre
        k = k + 1
    sinon,
        k = k + i
        
```

### Lettres

Avant d'implémenter un tel algorithme il faut décider de ce que sont
les _lettres_ possibles de la langue française.

Le module `string` contient la chaîne de caractères `ascii_lowercase`
(minuscules et majuscules sans accents).

On définira donc une variable `lettre`, chaîne constituée de toutes
les lettres **avec et sans accents**.

Attention aux copiers collers. Si vous décidez de cette approche, utilisez
les symboles présents dans le fichier [karamazov.txt](karamazov.txt).

### Implémenter

La consigne est simple :

1. Implémenter l'indexation d'un texte depuis un fichier.
2. Tester sur le texte [karamazov.txt](karamazov.txt)
    *   L'index de ce document comporte 570 fois le mot `karamazov`.
    *   chaque occurence de ce mot dans votre index doit bien être la chaîne
        `'karamazov'`


---


## Comparer

Il convient maintenant de comparer la vitesse des recherches.

Afin de compenser le temps perdu à la construction d'un index, le texte
utilisé sera toujours [karamzov.txt](karamzov.txt).


Avec le module time, comparer le temps pris par la recherche des occurences
avec BMH et avec un index.

On obtient généralement :

```
recherche avec index < bhm < construction + recherche avec index
```




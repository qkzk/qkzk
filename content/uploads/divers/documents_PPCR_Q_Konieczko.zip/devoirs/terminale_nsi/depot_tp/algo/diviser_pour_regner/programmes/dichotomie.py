import pylab
from time import time


def dichotomie_iteratif(tableau, cle):
    '''
    Recherche dichotomique dans un tableau trié
    Retourne l'indice de clé si cet élément est dans le tableau,
    Retourne -1 sinon

    Version itérative (première)

    @param tableau: (list) TRIE
    @param cle: (int)
    @return: (int)

    >>> tableau = [5, 23, 28, 39, 45, 63, 71, 89]
    >>> dichotomie_iteratif(tableau, 23)
    1
    >>> dichotomie_iteratif(tableau, 3)
    -1
    '''
    debut = 0
    fin = len(tableau) - 1
    while debut < fin:
        milieu = (debut + fin) // 2
        if tableau[milieu] == cle:
            return milieu
        if tableau[milieu] > cle:
            fin = milieu - 1
        else:
            debut = milieu + 1
    return -1


def dichotomie_recursif(tableau, cle, debut=0, fin=None):
    '''
    Recherche dichotomique dans un tableau trié
    Retourne l'indice de clé si cet élément est dans le tableau,
    Retourne -1 sinon

    Version récursive (terminale)

    @param tableau: (list) TRIE
    @param cle: (int)
    @return: (int)
    >>> tableau = [5, 23, 28, 39, 45, 63, 71, 89]
    >>> dichotomie_recursif(tableau, 23)
    1
    >>> dichotomie_recursif(tableau, 3)
    -1
    '''
    # à faire entièrement
    pass


def exemple():
    # complet, rien à faire
    tableau = [5, 23, 28, 39, 45, 63, 71, 89]
    print("tableau", tableau)
    print("dichotomie_iteratif, indice de 89 dans tableau ?",
          dichotomie_iteratif(tableau, 89))
    print("dichotomie_iteratif, indice de 30 dans tableau ?",
          dichotomie_iteratif(tableau, 30))
    print("dichotomie_recursif, indice de 89 dans tableau ?",
          dichotomie_recursif(tableau, 89))
    print("dichotomie_recursif, indice de 30 dans tableau ?",
          dichotomie_recursif(tableau, 30))


def index_natif(tableau, cle):
    '''
    Même signature que dichotomie, mais utilise l'outil de Python

    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> index_natif(tableau, 89)
    5
    >>> index_natif(tableau, 3)
    -1
    '''
    try:
        return tableau.index(cle)
    except ValueError as e:
        return -1


def generer_tableaux(abscisses):
    # à faire
    pass


def comparer_vitesse():
    '''
    Compare les vitesses de calcul de trois méthodes sur les mêmes tableaux

    * max (natif),
    * max_iteratif,
    * max_diviser_pour_regner

    @return None:
    @SE: display the graph with pylab
    '''
    funcs = [index_natif,
             dichotomie_iteratif,
             # dichotomie_recursif  # enlever le commentaire qd ça marche
             ]

    # génère une liste de tailles
    abscisses = list(range(1000, 40000, 1000))
    # génère des tableaux de cette taille
    tableaux = generer_tableaux(abscisses)

    for func in funcs:
        durees = []
        for tableau in tableaux:
            # on mesure la durée de la recherche du max sur ce tableau
            cle_1 = max(tableau)  # pire des cas où ça marche
            cle_2 = -1            # pire cas, clé qui n'est pas dans le tableau
            start = time()
            func(tableau, cle_1)
            func(tableau, cle_2)
            end = time()
            # qu'on enregistre
            durees.append(end - start)
        pylab.plot(abscisses, durees, label=func.__name__)
        pylab.legend(loc='upper right')
    pylab.show()


if __name__ == '__main__':
    exemple()
    # enlever le commentaire quand ça marche
    # comparer_vitesse()

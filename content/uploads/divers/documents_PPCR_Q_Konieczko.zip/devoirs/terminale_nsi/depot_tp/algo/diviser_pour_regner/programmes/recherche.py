import pylab
from random import shuffle
from time import time


def recherche_iterative(tableau, cle):
    '''
    Retourne Vrai ssi un clé est dans tableau

    Version vue en première. Rien à faire.
    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> recherche_iterative(tableau, 89)
    True
    >>> recherche_iterative(tableau, 3)
    False
    '''
    for element in tableau:
        if element == cle:
            return True
    return False


def recherche_diviser_pour_regner(tableau, cle):
    '''
    Retourne Vrai ssi un clé est dans tableau

    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> recherche_diviser_pour_regner(tableau, 89)
    True
    >>> recherche_diviser_pour_regner(tableau, 3)
    False
    '''
    # à vous de le faire
    pass


def exemple():
    tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    print("tableau", tableau)
    print("recherche_iterative, 89 in tableau ?",
          recherche_iterative(tableau, 89))
    print("recherche_iterative, 30 in tableau ?",
          recherche_iterative(tableau, 30))

    # enlever les commentaires quand ça tourne
    # print("recherche_diviser_pour_regner, 89 in tableau ?",
    #       recherche_diviser_pour_regner(tableau, 89))
    # print("recherche_diviser_pour_regner, 30 in tableau ?",
    #       recherche_diviser_pour_regner(tableau, 30))


def recherche_native(tableau, cle):
    '''
    >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
    >>> recherche_native(tableau, 89)
    True
    >>> recherche_native(tableau, 3)
    False
    '''
    return cle in tableau


def generer_tableaux(abscisses):
    # il faudra programmer cette fonction dans la deuxième partie
    pass


def comparer_vitesse():
    '''
    Compare les vitesses de calcul de trois méthodes sur les mêmes tableaux

    Cette version est complète, rien à faire.

    * max (natif),
    * max_iteratif,
    * max_diviser_pour_regner

    @return None:
    @SE: display the graph with pylab
    '''
    funcs = [recherche_native,
             recherche_iterative,
             recherche_diviser_pour_regner]

    # génère une liste de tailles
    abscisses = list(range(1000, 50000, 100))
    # génère des tableaux de cette taille
    tableaux = generer_tableaux(abscisses)

    for func in funcs:
        durees = []
        for tableau in tableaux:
            # on mesure la durée de la recherche du max sur ce tableau
            cle_1 = min(tableau)
            cle_2 = -1
            start = time()
            func(tableau, cle_1)
            func(tableau, cle_2)
            end = time()
            # qu'on enregistre
            durees.append(end - start)
        pylab.plot(abscisses, durees, label=func.__name__)
        pylab.legend(loc='upper right')
    pylab.show()


if __name__ == '__main__':
    exemple()
    # enlever les commentaires quand vous avez tout programmé
    # comparer_vitesse()

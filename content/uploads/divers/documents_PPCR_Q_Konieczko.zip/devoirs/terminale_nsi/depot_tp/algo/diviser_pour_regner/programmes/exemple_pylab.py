'''
Exemple d'utilisation de pylab pour tracer des courbes.
'''

import pylab

pylab.plot([1, 2, 3], [1, 4, 9], label="premiere_courbe")
pylab.plot([1, 2, 3], [7, 5, 2], label="deuxieme_courbe")
pylab.legend(loc='upper right')

# quand tout est en mémoire
pylab.show()

---
title: Terminale NSI - Algorithmique
subtitle: Diviser pour régner : travail pratique.
author: qkzk
date: 2020/04/26
---

Ce TP est en deux parties.

1. D'abord on implémente les algorithmes vus en cours,
2. Ensuite on réalise les figures qui permettent de comparer empiriquement les
    vitesses avec d'autres algorithmes faisant la même chose.

# 1. implémenter diviser pour régner



### A faire 0 :

* **Vous référer aux cours pour les nouveaux algorithmes.**

* Les algorithmes vus en première sont rappelés à la fin du document.

    Votre matériel contient déjà ces algorithmes. Il n'est pas nécessaire de les
    refaire

## Programmer les différents algorithmes

Utiliser un fichier différent par question : [**maximum.py**](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/algo/diviser_pour_regner/programmes/maximum.py) pour la première etc.

### A faire 1

Programmer dans chaque fichier le nouvel algorithme **diviser pour régner**.

Proposer des tests s'il n'y en a pas déjà.

1. Maximum d'un tableau d'entiers,
2. Recherche d'un élément _dans un tableau non trié_,
3. Exponentiation :

    * naïve : `x ** n = x * x * ... * x`
    * rapide

4. Tri fusion
5. Recherche dichotomique sur un tableau trié (méthode récursive).

    Il suffit d'adapter l'algorithme itératif à une méthode récursive

---

# 2. Comparaison des vitesses

Nous allons recréer les figures présentées en cours.

Pour chaque algorithme étudié il faudra adapter légèrement la démarche.

### Principe

1. On crée une série d'exemples dont le temps d'exécution sera mesuré
  pour chaque fonction.

2. On mesure :


    **Pour chaque fonction testée,** on exécute les mêmes étapes :

      * On crée le tableaux des durées de cette fonction,
      * On parcourt le tableau des exemples. Pour chaque exemple :

          * on lance un chrono,
          * on exécute cet exemple pour la fonction testée,
          * on arrête le chrono (et on relève la durée)
          * on ajoute cette durée
      * On ajoute dans la mémoire le pylab

          * le tableau des abscisses,
          * le tableau des durées.

Remarquez bien qu'il faut **deux boucles imbriquées**.

Le principe est présenté dans votre fichier [**maximum.py**](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/algo/diviser_pour_regner/programmes/maximum.py)

Dans les autres fichiers, la partie _mesure_ est plus ou moins développée.


### Pylab

On utilise `pylab` qui permet de tracer simplement des courbes à
partir de deux listes :

```python
import pylab

pylab.plot([1, 2, 3], [1, 4, 9], label="premiere_courbe")
pylab.plot([1, 2, 3], [7, 5, 2], label="deuxieme_courbe")
pylab.legend(loc='upper right')

# quand tout est en mémoire
pylab.show()
```

Résultat :

![exemple pylab](figures/exemple_pylab.png)/

### Principe

```python
import pylab

def generer_tableaux(abscisses):
  '''retourne des tableaux de taille donnée'''
  tableaux = []
  for k in abscisses:
      nombres = list(range(k))
      shuffle(nombres)
      tableaux.append(nombres)
  return tableaux

def comparer_vitesse():
  '''dessiner la comparaison des vitesses'''
  # créer une liste avec les fonctions à comparer
  fonctions = [max, max_iteratif, max_diviser_pour_regner]
  # génère une liste avec les tailles
  abscisses = list(range(10, 500, 10)) # ajouter des 0 quand ça fonctionne !
  # génère des tableaux de cette taille
  tableaux = generer_tableaux(abscisses)

  for func in fonctions:
    durees = []
    for tableau in tableaux:
      # on mesure la durée de la recherche du max sur ce tableau
      debut = time() # début du chrono

      func(tableau)  # notre calcul

      fin = time()   # fin du chrono
      # qu'on enregistre
      durees.append(fin - debut)

    # on ajoute un dessin et sa légende
    pylab.plot(abscisses, durees, label=func.__name__)
    pylab.legend(loc='upper right')

  # quand tout est en mémoire, on dessine tout le monde
  pylab.show()
```

Lisez bien le code de cette fonction, vous devez l'adapter.

Remarquez bien que :\
**les fonctions testées doivent toutes avoir exactement la même signature**


### A faire 2 :

Si vous avez programmé correctement la fonction `max_diviser_pour_regner`
alors vous devriez pouvoir exécuter `comparer_vitesse()` et voir deux graphes.

### A faire 3 :

Adapter la méthode à l'exponentiation rapide.

1. Créer une fonction `expo_python`

    ```python
    def expo_python(x, n):
      return x ** n
    ```

1. A-t-on encore besoin de générer des tableaux ?

    Adapter votre fonction `comparer_vitesse()`
    pour qu'elle utilise la bonne _signature_ pour les calculs
    de puissance.
2. Dessiner la comparaison des vitesses.

### A faire 4 :

* Comparer les vitesses pour le tri fusion vs tri par insertion
* Pour la recherche dichotomique (itérative, récursive) vs recherche Python :

    Vous pouvez utiliser la fonction suivante qui a la même signature.

    ```python
    def index_natif(tableau, cle):
      '''
      >>> tableau = [5, 71, 23, 45, 28, 89, 63, 39]
      >>> index_natif(tableau, 89)
      5
      >>> index_natif(tableau, 3)
      -1
      '''
      try:
        return tableau.index(cle)
      except ValueError as e:
        return -1
    ```


# Rappels

Ici le rappel des algorithmes tri par insertion et recherche dichotomique
vus en première. Le code est fourni dans les fichiers respectifs.

Cela peut vous aider d'en avoir une version en pseudo-code.

## Tri par insertion

On cherche à trier par ordre croissant un tableau de nombres.

```
tri_insertion (tableau) :

On initialise un index = 0

tant que index < longueur du tableau :

    k = index

    tant que k > 0 et tableau[k - 1] > tableau[k]

      # ces éléments ne sont pas triés : on les échange
      échanger tableau[k] et tableau[k - 1]

      # on recule d'une case
      k = k - 1
```

Le tableau est modifié au fur et à mesure, la fonction ne retourne rien.


## Recherche dichotomique sur un tableau trié

On cherche à retourner la position d'un élément dans un tableau trié

Si l'élément n'est pas dans le tableau on retourne -1

```
dichotomie_iteratif (tableau, cle)  ----->   indice

# on initialise les positions de la recherche :
debut = 0
fin = longueur - 1

tant que debut < fin :

    milieu = (debut + fin) / 2 # la moyenne

    si tableau [ milieu ] == cle # on a trouvé !!!
        retourner milieu

    sinon, si tableau [ milieu ] > cle:
        # la clé est entre debut et milieu ?
        fin = milieu - 1

    sinon:
        # la clé est entre milieu et fin ?
        milieu = debut + 1

fin du tant que

# on arrive ici si la clé n'est PAS dans le tableau.
retourner -1
```

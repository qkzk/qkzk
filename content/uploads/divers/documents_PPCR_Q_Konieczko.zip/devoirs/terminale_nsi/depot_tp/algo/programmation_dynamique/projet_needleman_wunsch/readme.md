---
title: NSI Terminale
subtitle: "Programmation Dynamique : Needleman Wunsch"
author: qkzk
date: 2020/03/04
theme:
- Metropolis
header-includes:
    - \usepackage[margin=1.5cm]{geometry}
---

# Alignement de séquences : l'algorithme de Needleman-Wunsch


**Objectif** : étudiez puis implémentez en Python l'algorithme de Needleman-Wunsch
présenté sur [wikipedia](https://fr.wikipedia.org/wiki/Algorithme_de_Needleman-Wunsch)

Cet algorithme est difficile, commencez par l'étudier à la main en reprenant
l'exemple proposé.

Ensuite copiez le texte de l'algorithme et découpez les fonctions en spécifiant
leurs paramètres d'entrée et de sortie

Enfin traduisez ligne à ligne depuis le langage naturel vers Python et testez
sur l'exemple proposé.

On ne cherchera pas à optimiser l'algorithme.

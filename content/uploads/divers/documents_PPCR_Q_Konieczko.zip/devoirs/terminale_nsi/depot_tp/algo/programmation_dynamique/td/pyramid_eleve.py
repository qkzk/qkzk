'''Pyramide de nombres, version itérative'''


def afficher_pyramide(pyramide):
    '''
    Affiche une pyramide de nombres dans la console
    @param pyramide: (dict) une pyramide de nombres
        clés : entiers de 0 à nb_étages - 1
        pyramide : listes de taille clé + 1, remplie d'entiers

    >>> pyramide = {
    ...         0: [3],
    ...         1: [7, 4],
    ...         2: [2, 4, 6],
    ...         3: [9, 5, 9, 3]
    ...     }
    >>> afficher_pyramide(pyramide)
         3
        7 4
       2 4 6
      9 5 9 3
    '''
    for no_etage in pyramide:
        valeurs_etages = pyramide[no_etage]
        print(' ' * (len(pyramide) - no_etage), *valeurs_etages)


def calculer_somme_max(pyramide):
    '''
    Retourne la somme maximale d'une pyramide de nombre

    @param pyramide: (dict) une pyramide de nombres
        clés : entiers de 0 à nb_étages - 1
        pyramide : listes de taille clé + 1, remplie d'entiers
    @return: (int)

    Utilise un algorithme itératif
    >>> pyramide = {
    ...         0: [3],
    ...         1: [7, 4],
    ...         2: [2, 4, 6],
    ...         3: [9, 5, 9, 3]
    ...     }
    >>> calculer_somme_max(pyramide)
    23
    '''
    return
    # le nombre d'étages est la longueur de pyramide

    # on crée un dictionnaire de mêmes dimensions rempli de zéros

    # autre manière de faire la même chose en commentaire
    # somme_montante = {i: [0] * len(etage) for i, etage in pyramide.items()}

    # le dernier étage est initilisé avec les valeurs de la pyramide

    # pour chaque étage à partir de l'avant dernier, jusqu'au premier
        # on remplit les valeurs du somme_montante
            # c'est la valeur de la pyramide + le max des fils gauche et droit
            # les fils gauche et droit sont : 1 étage plus bas,
            # ils ont pour indice dans l'étage j et j + 1
                                                        somme_montante[i + 1][j + 1])

    # l'élément tout en haut du somme_montante contient la somme maximale



def exemple():
    '''présente un exemple dans la console'''
    pyramide={
        0: [3],
        1: [7, 4],
        2: [2, 4, 6],
        3: [9, 5, 9, 3]
    }
    afficher_pyramide(pyramide)
    # print("Somme maximale : ", calculer_somme_max(pyramide))


if __name__ == '__main__':
    exemple()
    import doctest
    doctest.testmod()

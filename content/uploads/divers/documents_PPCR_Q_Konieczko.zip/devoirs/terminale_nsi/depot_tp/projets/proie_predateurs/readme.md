# Modèle discret de Lotka-Volterra

Github ne permet pas d'afficher de jolies formules mathématiques, lisez plutôt
le [pdf](./readme.pdf) !

---

## Modèle proie-prédateur

Un modèle proie-prédateur vise à décrire l'évolution de la population de deux
espèces animales dans le temps : une proie et son prédateur.

L'interaction se décrit ainsi :

* pour survivre, le prédateur dévore la proie,
* si les prédateurs dévorent toutes les proies, elles disparaissent... et le prédateur aussi.

Un autre scénario est possible :

* si le prédateur dévore une grande proportion de proies, il pourra moins chasser et sa population va décroître rapidement,
* dans ce cas, la proie pourra à nouveau prospérer et va beaucoup se reproduire,
* maintenant qu'on a beaucoup de proies, les prédateurs restant peuvent chasser librement,
* leur population augmente rapidement et ils dévorent presque toutes les proies...

Et le cycle se poursuit.

Inspiré des travaux de colons nord-américains durant le 18^eme^ siècle, des
mathématiciens ont cherché à modéliser ces phénomènes. Ils proposèrent un système
d'équations différentielles appelé _équations de Lotka-Volterra_ 
qu'on doit normalement étudier de manière continue.

Il est possible de rendre ce système discret, ce qui permet de le simuler
facilement sur un ordinateur. On peut utiliser pour cela, la _méthode d'Euler_.

## Méthode d'Euler

Le principe est simple : considérer que lorsque la variation de temps est très
faible, on peut approcher une courbe par sa tangente.

On le fait constamment : localement, dans la pièce qui vous entoure, on peut
supposer que la terre est plate.

On calcule donc, pour une variation de temps $\Delta t$ très brève, une
nouvelle image de $f(x)$ avec la méthode :

$$f(t + \Delta t) \approx f(t) + \Delta t \times \frac{\text{d}f(t)}{\text{d}t}$$

On remplace donc une équation qui dépend d'un paramètre réel par une _suite_
qui se calcule à l'aide d'une formule de récurrence.

## Équations de Lotka-Volterra

Les équations de Lotka-Volterra sont décrites ainsi :

$$\left\{\begin{array}{ccc}
    \dfrac{\mathrm{d}x(t)}{\mathrm{d}t} &=&
    x(t)\ \Big(\alpha - \beta y(t)\Big) \\
    \dfrac{\mathrm{d}y(t)}{\mathrm{d}t} &=&
    y(t) \ \Big( \delta x(t) - \gamma\Big) 
\end{array}\right.$$

où

* $t$  est le temps ;
* $x(t)$  est l'effectif des proies en fonction du temps ;
* $y(t)$ est l'effectif des prédateurs en fonction du temps ;

les dérivées 

* $\mathrm {d} x(t)/\mathrm {d} t$ et  $\mathrm {d} y(t)/\mathrm {d} t$
 représentent la variation des populations au cours du temps.

Les paramètres suivants caractérisent les interactions entre les deux espèces :

* $\alpha$ , taux de reproduction intrinsèque des proies (constant, indépendant du nombre de prédateurs) ;
* $\beta$, taux de mortalité des proies dû aux prédateurs rencontrés ;
* $\delta$ , taux de reproduction des prédateurs en fonction des proies rencontrées et mangées ;
* $\gamma$ , taux de mortalité intrinsèque des prédateurs (constant, indépendant du nombre de proies) ;

## Signification physique des équations


### Proies

L'équation de la proie est :

$\dfrac{\mathrm{d}x(t)}{\mathrm{d}t} = x(t)\ \Big(\alpha - \beta y(t)\Big)$

Les proies sont supposées avoir une source illimitée de nourriture et se
reproduire exponentiellement si elles ne sont soumises à aucune prédation ;
cette croissance exponentielle est représentée dans l'équation ci-dessus par le
terme $\alpha x(t)$ . Le taux de prédation sur les proies est supposé
proportionnel à la fréquence de rencontre entre les prédateurs et les proies ;
il est représenté ci-dessus par $\beta x(t)y(t)$ . Si l'un des termes $x(t)$ ou
$y(t)$  est nul, alors il ne peut y avoir aucune prédation.

Avec ces deux termes, l'équation peut alors être interprétée comme : la
variation du nombre de proies est donnée par sa propre croissance moins le taux
de prédation qui leur est appliqué.

### Prédateurs

L'équation du prédateur est 

$\dfrac{\mathrm{d}y(t)}{\mathrm{d}t} =
    y(t) \ \Big( \delta x(t) - \gamma\Big)$

Dans cette équation, $\delta x(t)y(t)$ représente la croissance de la
population prédatrice. Notons la similarité avec le taux de prédation ;
cependant, une constante différente est utilisée car la vitesse à laquelle la
population des prédateurs augmente n'est pas nécessairement égale à celle à
laquelle il consomme la proie. De plus, $\gamma y(t)$ représente la mort
naturelle des prédateurs ; c'est une décroissance exponentielle. L'équation
représente donc la variation de la population de prédateurs en tant que
croissance de cette population, diminuée du nombre de morts naturelles.

\newpage

## Les figures que nous allons construire

* Solutions des équations de Lotka-Volterra obtenues par un algorithme de
 Runge-Kutta d'ordre 4, pour une valeur de $\alpha =2/3, \beta =4/3, \gamma =1, \delta =1$, 
 pour une gamme de conditions initiales (échelle de couleurs, du rouge au
 jaune clair) de 0.9 à 1.8

   $~$![Effectifs en fonction du temps](./lv_time.png)

\newpage

* Orbites solutions des équations de Lotka-Volterra obtenues dans les mêmes
    conditions. Les conditions initiales sont signalées par des cercles.

   $~$![Effectifs des prédateurs en fonction des proies](./lv_phase.png)

\newpage

## Approche du problème d'un point de vue informatique

Voici le plan :

1. Choisir un jeu de constante `A, B, C, D` pour $\alpha, \beta, \gamma, \delta$

2. Donner des noms explicites aux variables : le problème historique portait
    sur des populations de lièvres et de lynx dans la baie d'Hudson, on aura donc :

    * `lievre` : l'effectif des lièvres à un instant donné,
    * `lynx` : l'effectif des lynx à un instant donné,
    * `temps` : une valeur du temps,

3. Écrire deux fonctions qui calculent la dérivée du nombre de lièvres et du
    nombre de lynx en fonction de ces effectifs respectifs.

4. Écrire deux fonctions qui calculent la nouvelle valeur de l'effectif,
    respectivement des lièvres et des lynx.

5. Écrire une fonction qui simule les équations de Lotka-Volterra avec la
    méthode d'Euler pour une durée voulue.
    Elle renvoie trois listes : les temps, les effectifs de lièvres, les
    effectifs de lynx.

6. Écrire une fonction qui trace les effectifs de lièvres en fonction du temps,
    et les effectifs de lynx en fonction du temps (le même graphe fera l'affaire).

7. Écrire une fonction qui construit un diagramme de phase pour un jeu
    de condition initiale.

8. Adapter cette dernière fonction pour faire varier légèrement les conditions
    initiales et tracer toutes ces courbes dans un même graphique.





---
title: "NSI - Terminale"
subtitle: "Projet : Zombies"
author: "qkzk"
date: "2021/01/23"
theme: metropolis
geometry: margin=1.5cm

---

# Zombies

## Principe

**Zombies** est un jeu vidéo d'action en 2d dans une carte fixe.

Le joueur apparaît au centre de l'écran et peut se déplacer librement dans la
carte. Il se tourne vers le curseur de la souris.
Chaque clic de la souris fait tirer le joueur vers celle-ci.
Il doit attendre un bref instant avant de pouvoir retirer.

Lorsqu'il passe sur des munitions, son compteur de munition remonte à 20.

Les zombies apparaissent en dehors de l'écran et encerclent lentement le joueur.
Celui-ci doit abattre les zombies avant qu'ils ne l'attrapent. Si un
zombie attrape le joueur, il meurt. Chaque fois qu'un zombie est abattu,
un autre apparaît légèrement en dehors de l'écran et s'approche du joueur.


![zombies](zombies.png)

## Élément du jeu

Le jeu est programmé en python avec la librairie _pygame zero_.

Les seules images nécessaires sont :

* le fond (de l'herbe),
* le joueur,
* un zombie,
* des particules,
* d'une boite de munition.

## Programme

Seule quelques actions sont reconnues par le moteur du jeu :

* cliquer : tire vers la souris s'il le peut,
* appuyer sur une touche de directement : déplace le joueur (limité à l'écran),
* bouger la souris : fait tourner le joueur

Le joueur est modélisé par une classe `Player`  comportant quelques méthodes :

* `draw` : dessine le joueur, les particules et affiche les textes.
* `draw_texts` : affiche les infos à l'écran (munitions, score, meilleur score, "you died")
* `move` : change les coordonnées du joueur,
* `shoot` : tente de faire tirer le joueur,
* `reshoot` : change un attribut interne afin que le joueur puisse à nouveau tirer
* `pickup` : ramasse une cartouche de munition,

Les zombies sont modélisés par une classe `Zombie` :

* `move` : déplace le zombie dans la direction du joueur,
* `respawn` : s'il meurt il réapparaît aléatoirement en dehors de l'écran,


Les munitions sont modélisées par une classe `Ammo` :

* `draw` : dessine la boite de cartouche à l'écran si elle ne vient pas d'être ramassée
* `respawn` : choisit une position aléatoire pour les prochaines munitions et
    les affiche à l'écran.


Tous ces objets sont crées avant de lancer le jeu dans des variables globales :

```python
...

player = Player()
zombies = [Zombie() for _ in range(10)] # crée un tableau de 10 zombies
ammo = Ammo()

pgzrun.go()
```

## Callback

Comment empêcher le joueur de tirer toutes les 0.1 secondes ?
Comment faire apparaître les munitions 3 secondes après qu'elles aient été
ramassées ?

Le principe est d'utiliser un _callback_. Lorsqu'une action est réalisée "le joueur
tire", on change un attribut du joueur "`self.peut_tirer = False`" et on
demande à pygame zero d'exécuter une fonction avec un délai. 
Tant que le délai n'est pas écoulé, un clic ne produit rien.
Une fois ce délai, écoulé, pygame zero appelle la méthode en question qui rétabli
le drapeau à `True` et on peut tirer à nouveau.

Par exemple, quand le joueur tire, on peut exécuter :

```python
clock.schedule(une_fonction, 1.0)
```

Et la fonction `une_fonction` sera exécutée une seconde plus tard.


## Faire tourner le joueur et orienter les zombies vers le joueurs.

Chaque sprite (image) affiché à l'écran est un objet "`Actor`".
Ceux-ci disposent d'un attribut `angle` qu'on peut changer à volonté.

On pourra utiliser un peu de trigonométrie de seconde pour orienter les éléments.

Par exemple, pour les zombies :

```python
class Zombie:

    ...

    def move(self):
        angle = self.actor.angle_to(player.actor.pos)
        self.actor.angle = angle - 90 # l'image des zombies est tournée de 90°
        self.actor.left += cos(radians(angle))
        self.actor.bottom -= sin(radians(angle))
```

Je vous laisse vous débrouiller pour orienter le joueur vers le curseur de la
souris.



## Événements

On l'a dit plus haut, les seuls événements du jeu sont :

les événements clavier qui permettent de :

* bouger (haut, bas, gauche, droite et z, q, s, d)
* rejouer une fois mort (entrée)
* quitter (escape)

les événements souris qui permettent :

* de tirer en cliquant,
* de tourner le joueur en bougeant la souris.

Par simplicité, je vous recommande d'intégrer les événements clavier à la
classe du joueur (ils n'agissent que sur lui) dans une méthode `keyboard`

Il suffit alors d'intégrer : 

```python
def update():
    player.keyboard()
    ...
```



Pour les événements souris, il faut les capturer avec des fonctions de pygame
zéro : 

```python
def on_mouse_down(pos, button):
    pass


def on_mouse_move(pos):
    pass
```

Je vous laisse vous documenter à ce propos.

## Score et high score

Le principe d'un high score est qu'il doit être enregistré quelque part.

Une classe pour le score permet d'avoir un code facilement organisé.
On peut se contenter de l'écrire dans un fichier à chaque fois que le
meilleur score est dépassé.



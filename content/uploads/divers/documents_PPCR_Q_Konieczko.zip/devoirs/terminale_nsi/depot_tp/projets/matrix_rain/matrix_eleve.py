'''
Votre point de départ :

un script pgzero valide qui :

* définit quelques constantes
* crée un objet global `lettre`
* affiche la lettre à l'écran 60x par seconde,
* change son symbole une fois sur 10 (donc toutes les 0.6 secondes !)

'''
from random import choice, random
import pgzrun

# quelques constantes
SYMBOLS = "ﾊﾐﾋｰｳｼﾅﾓﾆｻﾜﾂｵﾘｱﾎﾃﾏｹﾒｴｶｷﾑﾕﾗｾﾈｽﾀﾇﾍｦｲｸｺｿﾁﾄﾉﾌﾔﾖﾙﾚﾛﾝ日012345789Z:・.\"=*+-<>¦｜ﾘｸ "
FONT = "ipaexg.ttf"
HEIGHT = 600
WIDTH = 600
TITLE = "THE MATRIX"


def update():
    '''
    cette fonction est appelée par pgzrun  60x par seconde
    elle permet de mettre à jour les objets globaux du jeu
    pour l'instant, elle change le symbole de `lettre` une fois sur 10
    '''
    global lettre
    # une chance sur 10 ...
    if random() < 0.1:
        # ... de choisir un nouveau symbole au hasard dans le tableau
        lettre = choice(SYMBOLS)


def draw():
    '''
    cette fonction permet de dessiner les objets globaux de pygame zero
    elle est appelée 60x par seconde par pgzrun
    '''
    # nettoie l'écran
    screen.clear()
    # dessine la lettre
    screen.draw.text(lettre,
                     center=(200, 200),
                     fontname="ipaexg.ttf",
                     color=(40, 200, 20),  # du vert
                     )


def on_key_down():
    '''
    cette fonction est appelée chaque fois qu'on presse une touche
    le dictionnaire `keyboard` associe un nom de touche à un booléen:

    keyboard = {
        ...
        "escape": False,
        ...
        "space": False,
        ...
    }

    Quand on presse une touche, le booléen devient vrai.
    Essayez de presser "Échap" cela va quitter le jeu.
    '''
    # si la touche escape est enfoncée ...
    if keyboard["escape"]:
        # ... quitte le programme
        exit()


# une variable globale
lettre = choice(SYMBOLS)
# lance le jeu (c'est toujours la dernière ligne de votre programme)
pgzrun.go()
# on n'arrive jamais ici

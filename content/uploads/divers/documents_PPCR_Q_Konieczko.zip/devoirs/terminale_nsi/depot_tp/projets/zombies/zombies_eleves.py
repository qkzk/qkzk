from math import cos
from math import sin
from math import radians
from random import randint

import pgzrun
import pygame

WIDTH = 512
HEIGHT = 512
TITLE = "Zombies"
HIGH_SCORE = "./high_score.txt"


class Score:
    def __init__(self):
        pass


class Player:
    def __init__(self):
        pass


class Zombie:
    def __init__(self):
        pass


class Ammo:
    def __init__(self):
        pass


class Particle:
    def __init__(self):
        pass


def on_mouse_down(pos, button):
    pass


def on_mouse_move(pos):
    pass


def draw():
    screen.blit("grass", (0, 0))


def update():
    pass


player = Player()
zombies = [Zombie() for _ in range(10)]
ammo = Ammo()

pgzrun.go()

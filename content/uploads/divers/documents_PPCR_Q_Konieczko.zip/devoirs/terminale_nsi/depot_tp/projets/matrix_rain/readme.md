---
title: The Matrix Rain
author: qkzk
date: 2020/04/14

---

**[dépôt github privé](https://github.com/qkzk/matrix_rain)**

# The Matrix Rain

![matrix rain](./img/giphy.webp)

Remake en python de la matrice telle qu'on peut la voir dans le film.

* Escape ou clic droit : quitter,
* autre touche ou clic gauche : basculer en plein écran (résolution à modifier)

Librairies : **pygame zero** et **pygame** (pour basculer en plein écran)

## Principe

Des colonnes de symboles descendent simultanément à l'écran. La majorité
d'entre eux sont des  [katakana](https://fr.wikipedia.org/wiki/Katakana).

De manière aléatoire ils se retournent et changent de symbole.  Ils sont tous
verts, légèrement floutés et celui le plus bas d'une colonne est parfois plus
clair.

Dans le film, les symboles sont des images miroir de symboles parmi les
chiffres et quelques katakana. Construire une image miroir d'une lettre est
pénible en pygame, il faut créer un sprite pour chaque lettre possible et lui
appliquer une transformation qui n'est pas implémentée dans pygame zero... Mais
tourner de 180° est facile. C'est ce que nous ferons.

Lire ce [fil de discussion](https://scifi.stackexchange.com/questions/137575/is-there-a-list-of-the-symbols-shown-in-the-matrixthe-symbols-rain-how-many)
pour en savoir plus. La première réponse contient la liste de symboles que nous
utiliserons.

Par défaut, nos systèmes ne peuvent afficher tous ces symboles. Il convient
d'employer une police particulière dans [fonts](./fonts).

## Paradygme

POO : afin d'en faire un projet de terminale NSI

## Étapes d'un projet

0. dessiner une fenêtre avec pygame zero, y écrire une lettre.

    placer la police [ipaexg.ttf](./fonts/ipaexg.ttf) dans [./fonts](./fonts)

    ```python
    import pgzrun
    # projet à développer ici
    pgzrun.go()
    ```

1. dessiner un des symboles à l'écran

    ```python
    from random import choice
    SYMBOLS = "ﾊﾐﾋｰｳｼﾅﾓﾆｻﾜﾂｵﾘｱﾎﾃﾏｹﾒｴｶｷﾑﾕﾗｾﾈｽﾀﾇﾍｦｲｸｺｿﾁﾄﾉﾌﾔﾖﾙﾚﾛﾝ日012345789Z:・.\"=*+-<>¦｜ﾘｸ "
    lettre = choice(SYMBOLS)

    def draw():
      screen.draw.text(lettre, center=(200, 200), fontname="ipaexg.ttf")
    ```

2. **La classe `kata`** pour les katakana.

    Cette classe va gérer une lettre ou symbole.

    attributs transmis : `x, y` qui définissent la position.

    méthodes :

      * `show` : dessine à l'écran,
      * `drop` : fait descendre,
      * `flip` : 1 chance sur 10 de basculer l'angle

      Pour écrire un texte tourné d'un certain angle, il est préférable
      de tourner autour du centre de celui-ci :

      ```python
      screen.draw.text("A", center=(200, 200), fontname="ipaexg.ttf", angle=180)
      ```

    * `set_symbol` : attribue un symbole aléatoire parmi les symboles.
    * `set_angle` : tire au hasard parmi 0 et 180°
    * `new_symbol` : une chance sur 50 de choisir un autre symbole.
    * `bright` :  une chance sur quatre d'avoir une couleur plus claire.
    * `drop` : descend jusqu'en bas, remonte en haut de l'écran.

    Dessiner un symbole et le bouger à l'écran.
    À cette étape, le projet est presque terminé !

3. **La classe `Column`**. Elle contient une liste de symboles en attributs.

    Le seul paramètre transmis à cette classe est une abscisse.

    Elle a trois méthodes :

    * `create_katas` : qui retourne une liste d'instances de `Kata` alignés verticalement.

      L'ordonnée la plus haute doit être au dessus de l'écran, ils ne doivent pas déborder de l'écran. Le nombre total de symboles est aléatoire, autour des 3/4 du nombre maximal.
    * `rain` qui réalise les animations pour tous les symboles : `drop`, `flip` et `new_symbol`
    * `show` qui appelle `kata.show()` pour chaque `kata`

    Avant de lancer le jeu, on crée un tableau d'instances de `Column`, suffisamment pour remplir la largeur de l'écran :

    ```python
    columns = votre_tableau_d_objets_Column
    pgzrun.go()
    ```

    À cette étape tout est terminé. Il reste à choisir les dimensions et couleurs
    les plus adaptées.



4. En faire un fond d'écran.

    On peut facilement forcer le script à se lancer en plein écran.

    ```python
    import pygame
    SURFACE_WIDTH = La_largeur_en_pixels
    SURFACE_HEIGHT = La_hauteur_en_pixels

    def draw():
      screen.surface = pygame.display.set_mode((SURFACE_WIDTH, SURFACE_HEIGHT),
                                             pygame.FULLSCREEN)
    ```

    Ensuite il convient de sortir immédiatement dès qu'on presse une touche.
    C'est facile à intercepter avec la fonction `on_key_down` qui est appelée dès qu'on appuie sur le clavier.


    ```python
    def on_key_down():
        if keyboard["escape"]:
            exit()
        print(keyboard) # pour afficher toutes les touches pressées
    ```

    De même on peut intercepter les clics de souris avec

    ```python
    def on_mouse_down(button):
      print(button)
    ```

## Source

[The coding train](https://www.youtube.com/watch?v=S1TQCi9axzg)

# Tale_nsi_2021


dépôt principal des travaux dirigés de la terminale NSI 2020/2021


## Garder une copie de tous les exos, mise à jour :

1. Cloner le dépôt

    ```bash
    $ mkdir travaux_diriges
    $ cd travaux_diriges
    $ git clone https://github.com/NSI-T-2021/Tale_nsi_2021.git
    ```
    Ainsi vous récupérez tous les travaux.

2. Avant de commencer un travail, vérifier que c'est à jour :

    ```bash
    $ cd Tale_nsi_2021
    $ git pull origin master
    ```

3. **COPIER L'ÉNONCÉ AVANT DE RÉPONDRE !!!!**

    Si vous avez fait un clone du dépôt, ne répondez jamais dans l'énoncé !!!



    Sans quoi, si vous modifiez et refaites un `git pull ...`

    Vous devrez soit :

    * perdre vos travaux (en écrasant)
    * créer une branche locale etc. (compliqué)

    **Comment faire ?**

    Par exemple pour le tp sur la récursivité :

    ```bash
    $ cd prog/recursivite
    $ mkdir -p /home/martin/travail/NSI/recursivite
    $ cp td /home/martin/travail/NSI/recursivite/
    $ cd /home/martin/travail/NSI/recursivite/td/
    ```

    Et vous travaillez là.

## Contenus

Ces contenus sont les travaux dirigés à destination de mes élèves de
terminale NSI.

## Organisation

Les TP sont rangés par thème du programme. Ils ne suivent pas notre progression.

Les énoncés sont fournis sans correction, avec le matériel nécessaire
pour les réaliser.

Si j'ai suivi mes propres engagements, ils sont tous indépendants.
Tout y est (sauf le cours !)

Pour les cours il faut y accéder via mon site. (sinon ça fait trop...)

## Difficulté

Elle est variable. J'en prévois toujours trop, ayant régulièrement
eu des élèves très motivés par l'info, je préfère que vous ne restiez pas sur
votre faim.

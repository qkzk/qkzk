# Bases de données relationnelles

Le cours est sur le site :

* [résumé](https://qkzk.xyz/uploads/docnsitale/bdd/sqlite_sheet_fr.pdf)
* [introduction](https://qkzk.xyz/docs/nsi/cours_terminale/bdd/cours_1/)
* [conception](https://qkzk.xyz/docs/nsi/cours_terminale/bdd/cours_2/)

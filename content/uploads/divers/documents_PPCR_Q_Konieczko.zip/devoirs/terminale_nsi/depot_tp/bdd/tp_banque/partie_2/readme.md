# Banque : seconde partie

Objectifs

1. implémenter une transaction
3. ajouter un contrôle via python


---

# Transférer de l'argent

* Un transfert d'argent se fait entre deux numéros de compte,
* Il doit disposer d'une valeur. Elle sera _débitée_ (= retirée) du compte A
    et _créditée_ (= ajoutée) au compte B
* le solde du compte est la somme des transferts + solde initial,
* la transaction est datée,

Ce système fermé ne permet pas de définir les soldes initiaux.
Il faut un solde de départ donné.

On part de l'état de la banque initial obtenue après le TP 1.

## Exemple :

Avant

| Numéro de compte 	| montant 	| date d'accès 	|
|------------------	|---------	|--------------	|
| 1                	| 100     	| 2020/06/02   	|
| 2                	| 250     	| 2020/07/21   	|

Transfert

| _champs_         	| _valeurs_  	|
|------------------	|------------	|
| compte débiteur  	| 1          	|
| compte créditeur 	| 2          	|
| montant          	| 30         	|
| date             	| 2020/09/02 	|

Après :

| Numéro de compte 	| montant 	| date d'accès 	|
|------------------	|---------	|--------------	|
| 1                	| 70      	| 2020/09/02   	|
| 2                	| 280     	| 2020/09/02   	|

Non seulement les montants sont modifiés mais aussi des dates d'accès.

> Réaliser ce transfert :
>
> 1. c'est ajouter une transaction à la table transaction
> 2. modifier les valeurs des tables de compte

_Attention_ :

* ce n'est qu'un exemple simplifié. En pratique on évite d'avoir
    de la _redondance_ d'information dans les tables. Ici sauvegarder le montant
    n'est pas une bonne idée ! On peut toujours le recalculer.

* Ensuite il y a un problème : on enregistre toutes les transactions dans une
    seule table ! Il est judicieux d'avoir un registre des transactions pour
    chaque compte...

# Étapes

1. Créer une nouvelle table transaction
2. Distinguer deux notions : pour la banque != pour sql
3. Saisir une transaction à la main

4. Programmer des fonctions python qui agissent sur la table

5. ajouter / modifier un client, un compte, une possession
6. ajouter une transaction


## 1. Créer une nouvelle table transaction

Voici l'action retenue :

![client_possede_compte_transaction.png](img/client_possede_compte_transaction.png)

Et ses données :

![client_compte__transactions_schema.png](img/client_compte__transactions_schema.png)

### À faire 1.

Dans un fichier `table_transaction.sql` rédiger la commande sql permettant de
créer la table `transaction`

## 2. Distinguer deux notions : pour la banque != pour sql

### À faire 2.

Qu'est-ce qu'une [transaction sql](sql_transaction/bdd_transaction.md) ?
Lisez attentivement ce document.

## 3. Saisir un transfert à la main

### À faire 3.

Dans un fichier **transactions_entre_comptes.sql** vous allez rédiger
à la main la syntaxe sql représentant le transfert suivant :

Transfert

| _champs_         	| _valeurs_  	|
|------------------	|------------	|
| compte débiteur  	| 1          	|
| compte créditeur 	| 2          	|
| montant          	| 30         	|
| date             	| 2020/09/02 	|

notez que vous devez :

* insérer un enregistrement dans la table `transaction`
* mettre à jour le `montant` et `date_access` dans la table des comptes,
    ceci, pour chacun des deux comptes.

Souvenez-vous : le débiteur _perd_ de l'argent, le créditeur en _gagne_.




## 4. Programmer des fonctions python qui agissent sur la table

Cette approche (rédiger les enregistrements à la main) atteint dès maintenant
ses limites. S'il était encore possible d'ajouter les comptes manuellement,
il devient impossible d'ajouter les transferts dès qu'ils deviennent nombreux.

Nous devons passer à la programmation avec Python.

Je vous renvoie au TP d'introduction, programmer une bdd avec Python.

Vous partez d'un script qui contient déjà

* une fonction qui crée les tables si elles n'existent pas : `creer_table`,
* une fonction permettant d'ajouter un client : `ajouter_client`,
* une fonction permettant d'ajouter un compte et sa possession : `ajouter_compte_possession`,
* une fonction permettant de modifier un champ du client : `modifier_champ_client`,
* une fonction de visualisation de l'état d'un compte : `etat_compte`,
* une fonction de visualisation de l'état d'un client : `etat_client`.

### À faire 4 Lisez soigneusement le code et **ajoutez la documentation**
aux fonctions qui ne le sont pas déjà.

Exécutez les exemples proposés dans `exemples()` et regardez l'état de la base
de donnée.

## 5. ajouter / modifier un client, un compte, une possession

Nous allons ajouter une fonction simple, permettant de modifier une possession.

## À faire 5.

Créer une fonction `modifier_possession` qui altère une possession.

On doit pouvoir lui passer deux paramètres entiers (`numero_client` et
`numero_compte`).

Vous ajouterez votre requête à la classe des requêtes contenues dans query.py


## 6. ajouter une transaction

Nous allons procéder par étape. Dans un premier temps nous nous contentons
d'écrire les syntaxes sql.

Une fois parvenus à transférer correctement de l'argent d'un compte à l'autre
nous allons écrire un script qui permet de le faire automatiquement.

**Attention**

**Par défaut, `sqlite3` enregistre vos modifications immédiatement.**

Nous allons donc modifier un paramètre à partir d'ici.

Voici un exemple qui présente une situation où la transaction échoue.
Rien n'est enregistré (parce qu'elle échoue !)


```python
import sqlite3

conn = sqlite3.connect("/tmp/test.db")
conn.isolation_level = None # NOUVEAU : empêche sqlite3 de sauvegarder immdiatement
cursor = conn.cursor()

cursor.execute("begin")
try:
    # on met dans un try... except la transaction
    cursor.execute("update test set i = 1")

    cursor.execute("COMMANDE QUI EST FAUSSE") # <---------- cette commande n'existe pas ! ça doit échouer

    cursor.execute("update test set i = 0")
    cursor.execute("commit") # ne sera pas exécuté
except sqlite3.Error:
    print("failed!")
    cursor.execute("rollback") # donc ça échoue.
```

### À faire 6.

* ajouter les paramètres `conn.isolation_level` dans le code de la fonction `connexion_curseur`
* écrire une fonction python `transferer_entre_comptes`
    qui transfère de l'argent d'un compte à l'autre. Elle prend 4 paramètres :

    * compte_debiteur: un entier
    * compte_crediteur: un entier
    * montant: un entier
    * date: une chaîne au format de date mis en place : `2019-12-31T20:54`

    On ne vérifiera pas que les dates sont correctement saisies (il faudrait...)

    Non seulement votre fonction ajoute une ligne à la table `transaction`
    mais elle modifie les deux comptes concernés.


## 7. créer une fonction de saisie pour un employé de banque (**bonus**)

Nous allons créer une fonction utilisable par un employé de banque.

Elle pose des questions, l'employé tape une réponse et s'il a saisi correctement,
le transfert est effectué. S'il tape n'importe quoi, elle plante ou elle quitte.

### À faire 7

écrire une fonction python `saisir_transfert` qui demande à l'utilisateur de
saisir successivement :

* un nom de débiteur,
* un prénom de débiteur,
* effectue une recherche de client sur ces données (on supposera qu'il n'y a
    pas d'homonymes) et on garde en mémoire le numéro de client.
* la même chose pour le créditeur,
* un montant,
* effectue la transaction,
* affiche les soldes du débiteur après celle-ci finaux,

Exemple de déroulé d'instruction interactives.

```python
>>> saisir_transfert()

Veuillez taper le nom du débiteur : Duchmol
Veuillez taper le prénom du débiteur : Robert

J ai trouvé les comptes :
Compte 1 avec pour solde 100€
Veuillez taper le numéro de compte : 1

Veuillez taper le nom du créditeur : Delune
Veuillez taper le prenom du créditeur : Claire

J ai trouvé les comptes
Compte 5 avec pour solde -54€
Compte 6 avec pour solde 1234€
Veuillez taper le numéro de compte : 6

Veuillez taper le montant du transfert : 30

Le transfert a été correctement effectué. Les soldes sont maintenant :

Compte 1 avec pour solde 70€
Compte 6 avec pour solde 1264€
```

date du jour au bon format :

```python
>>> from datetime import datetime
>>> date = datetime.now().strftime("%Y-%m-%dT%H:%M")
>>> date
'2020-04-14T12:42'
```

## Conclusion.

Dans ce TP nous avons revu comment créer en Python des commandes permettant
d’interagir avec une base de donnée.

La dernière fonction est très archaïque et ne permet pas grand chose...

En pratique il faudrait proposer au moins un site web qui lise un formulaire
et agisse sur la table. Nous le ferons mais avec un exemple plus simple et
qui ne nécessite pas autant d'étapes.


Voici les éléments que nous allons discuter :
------------------------------------------------------------------

- Qu'est-ce que la gestion d'une transaction ?

- Exemple d'une transaction

- Définition d'une transaction

- Qu'est-ce que le principe ACID

- Exemple d'une transaction

Introduction
------------

Les transactions sont des mécanismes normalisés dans la définition du
langage SQL. En revanche, leur implémentation est l'une des
caractéristiques qui établit la différence entre les divers fournisseurs
de base de données.

Qu'est-ce que la gestion d'une transaction ?
----------------------------------------------

Assurer l'intégrité des données est une des exigences fondamentales du
point de vue des utilisateurs d'une base de données.

Ce terme, l'intégrité, englobe :

-   Le stockage de données sans erreur.
-   La protection contre les destructions, les pertes, les abus et les
    accès non autorisés.

La gestion des transactions dans un SGBD doit permettre à plusieurs
utilisateurs de travailler sans conflit entre eux.

Pour cela, tout changement dans la base de données doit respecter les
contraintes d'intégrité définies par les utilisateurs.

Exemple d'une transaction
--------------------------

Soit l'exemple d'une transaction est celui d'un transfert d'argent
d'un compte bancaire vers autre compte. Imaginez, qu'après une panne,
votre compte a été débité de la somme de 5000 € sans que l'autre
compte soit crédité du même montant. Vous ne seriez pas très content des
services de votre banque.

Le mécanisme transactionnel empêche un tel scénario en invalidant toutes
les opérations faites depuis le début de la transaction, si une panne
survient au cours de cette même transaction.

Définition d'une transaction
-----------------------------

Une transaction est un ensemble d'ordres SQL, qui met à jour une base
de données en garantissant la cohérence de ses états successifs. Elle
comporte un début, une suite d'ordres SQL, puis une fin.

Les transactions doivent respecter les principes résumés par l'acronyme
ACID :

### Atomicité

Une transaction doit être complètement exécutée. Sinon elle ne doit
laisser aucune trace de son exécution dans la base de données.

Les états intermédiaires générés par les opérations d'une transaction
déterminée ne sont pas visibles aux autres transactions concurrentes.

Dans ce sens, une transaction constitue une unité d'exécution dont les
opérations doivent être annulées lorsque la transaction est interrompue


**L'atomicité obéit au principe du « tout ou rien »**


### Cohérence

Il est possible qu'une transaction en cours d'exécution transgresse
temporairement certaines contraintes de cohérence. Mais quand la
transaction est terminée, le résultat final doit respecter de nouveau
toutes les contraintes. Par conséquent, une transaction fait passer une
base de données d'un état cohérent à un autre état cohérent et garantit
l'absence de données contradictoires. La transaction représente donc
une unité d'exécution qui doit maintenir la cohérence d'une base de
données.


**La cohérence signifie l'absence de données contradictoires**


### Isolation

Le principe de l'isolation exige que les résultats générés par des
transactions simultanées soient identiques à ceux qu'on aurait pu
obtenir dans un environnement à un seul utilisateur. Isolées les unes
des autres, les transactions qui s'exécutent en parallèle sont
protégées contre des interférences accidentelles. C'est pourquoi la
transaction est considérée comme une unité dont les opérations peuvent
être sérialisées.


**L'isolation protège la base de données contre les effets de bord**


### Durabilité

Une base de données doit être maintenue dans un état cohérent jusqu'à
la validation des modifications effectuées par une transaction.

Lors d'incidents (erreurs de programmation, interruptions du système ou
pannes d'unités de stockage externes), la durabilité garantit que seule
une transaction correctement achevée permet de valider les changements
dans une base de données. Dans le cadre des procédures de redémarrage et
de restauration des bases de données, chaque transaction représente une
unité de reprise


**La durabilité présuppose la possibilité de reconstruire une base de
données**


Le principe ACID
----------------

Les quatre concepts d'atomicité (Atomicity), de cohérence
(Consistency), d'isolation (Isolation) et de durabilité (Durability)
définissent le principe ACID d'une transaction.

Ce principe fondamental des SGBD garantit que chaque utilisateur
transforme une base de données d'un état cohérent à un autre état
cohérent. Les états intermédiaires incohérents restent invisibles depuis
l'extérieur et sont annulés en cas d'incident.

Une transaction n'a que deux issues possibles : le succès « COMMIT » ou
l'échec « ROLLBACK ». Il n'y a pas de situation intermédiaire.

*Seuls les ordres SQL qui modifient des données interviennent dans une
transaction. Un ordre SELECT qui n'effectue qu'une lecture n'influe
pas sur la transaction à laquelle il appartient.*

Exemple d'une transaction
--------------------------

Supposant qu'un client « Menvussa » souhaite transférer un montant de 5000
€ vers le compte de son fournisseur « Duchmol ». L'opération sera
effectuée à travers la banque en transférant le montant de 5000 € du
compte « Menvussa » au compte « Duchmol ».

Voici la liste des ordres SQL à exécuter :


```sql
BEGIN TRANSACTION ; --on enregistre en MÉMOIRE pas dans la base !!!
 --debut d'une transaction sql
update compte set montant = montant - 5000 where nom='Menvussa' ;
update compte set montant = montant + 5000 where nom='Duchmol' ;
COMMIT ; --fin d'une transaction sql : TOUT OU RIEN
```


Explication :

-   L'instruction « `SET autocommit = 0` ; » permet de désactiver
    l'autovalidation.
-   L'instruction `START TRANSACTION` ; permet de lancer une transaction.
-   L'instruction `COMMIT` ; permet de valider les ordres SQL comprises
    entre `START TRANSACTION` et `COMMIT`. Pour annuler la transaction nous
    utilisons `ROLLBACK`


_Remarque :_ ici la base de donnée est simplifiée, dans l'exemple du TP
les comptes ne sont pas référencés par nom de client mais par numéro de compte.
Pour que Menvussa transfère de l'argent à Duchmol on doit d'abord choisir leurs
comptes respectifs.

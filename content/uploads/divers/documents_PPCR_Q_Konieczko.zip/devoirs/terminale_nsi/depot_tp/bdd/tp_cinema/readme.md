# Langage SQL : le Cinéma

# 0. Travail attendu

Afin de vous aider à retenir les requêtes SQL, vous rendrez vos réponses
sous la forme d'un fichier markdown (.md) que vous déposerez dans classroom.

* Un petit [tutoriel markdown](https://github.com/luong-komorebi/Markdown-Tutorial/blob/master/README_fr.md)
* Si vous souhaitez visualiser le rendu, vous pouvez le faire sur
    [stackedit.io](https://stackedit.io/) (cliquer sur _start writing_)
* Chaque commande SQL sera donc dans un bloc de code de la forme :
    
    ~~~sql
    ```sql
    SELECT attribut1, attribut2 FROM nom_de_table WHERE condition;
    ```
    ~~~

    (Pour taper l'accent grave, utiliser AltGr + 7)

# 1. Utilisation d'une base consacrée au cinéma

## 1.1 Exploration de la base de donnée

1. Téléchargez la base [cinéma](./cinema.db) située dans le dépôt.

2. Ouvrez la base dans **dbBrowser** (Fichier, ouvrir une base de données)

En explorant la structure de la base de données, répondez aux questions
suivantes :

1. Combien de relations possède la base de données ?

2. Combien d'attributs possède la relation Artiste ?
3. Quelle est sa clé primaire ?
4. Combien d'attributs possède la relation Film ?
5. Quelle est sa clé primaire ?
6. Quelle est sa clé étrangère ?
7. Effectuez un clic droit sur la relation Film, puis choisissez Modifier la
   table. En inspectant le code, indiquez quelle est la référence de la clé
   étrangère.
8. En procédant de la même façon pour toutes les tables, représentez le schéma
   relationnel sous forme graphique, en faisant bien figurer les relations
   entre les clé primaires et clés étrangères.

## 1.2 Requêtes simples

En utilisant l'ongle Exécuter le SQL, indiquez le code SQL permettant
d'afficher :

1. les titres des films triés par ordre alphabétique. (27 enregistrements)

2. Les prénoms, noms et année de naissance des artistes nés avant 1950. (14
   enregistrements)
3. Les cinémas qui sont situés dans le 12 e arrondissement. (1 enregistrements)
4. Les artistes dont le nom commence par la lettre H (on utilisera la commande
   `LIKE`). (3 enregistrements)
5. Les acteurs dont on ignore la date de naissance (cela signifie que la valeur
   n'existe pas). (2 enregistrements)
6. Le nombre de fois où Bruce Willis a joué le rôle de McLane (on utilisera la
   commande `UPPER()`) pour s'affranchir de la casse). (Réponse : 3)

### Tutoriels sur les nouvelles commandes :

* `LIKE` [tutoriel](https://www.sqlitetutorial.net/sqlite-functions/sqlite-like/).
* `UPPER` [tutoriel](https://www.sqlitetutorial.net/sqlite-functions/sqlite-upper/).

## 1.3 Requêtes avec jointure

On rappelle qu'une jointure consiste à rapprocher les clé primaire et étrangère
de deux relations.\
La syntaxe est la suivante :

```sql
        SELECT attribut
        FROM relation1
        JOIN relation2 on relation1.cle1 = relation2.cle2
```

En utilisant l'ongle Exécuter le SQL, indiquez le code SQL permettant de
répondre aux questions suivantes :

1. Quel est le nom et le prénom de l'acteur qui a joué Tarzan (pensez à la
   commande `UPPER()`, (1 enregistrement)

2. Quelle est l'année de naissance du réalisateur de _Reservoir Dogs_ ? (Réponse : 1948)
3. Quels sont les titres des films dans lesquels a joué Woody Allen. Donnez
   aussi le rôle joué.  (2 enregistrements)
4. Quels films peut-on voir au cinéma Rex ? (Attention aux doublons) (7
   enregistrements)
5. Quels films peut-on voir à 15h dans un cinéma parisien ? (4 enregistrements)
6. Quels sont les cinémas (nom, adresse et arrondissement) qui diffusent des
   films le matin.  (4 enregistrements)
7. Quels sont les cinémas (nom, adresse et arrondissement) qui diffusent des
   films le matin.  Indiquez aussi le titre du film. (4 enregistrements)
8. Quels films peut-on voir dans un cinéma du 12^eme^ arrondissement ? On donnera
   le titre du film, le cinéma dans lequel il est joué et son adresse. (3
   enregistrements)
9. Quels sont les nom et prénom des acteurs qui ont joué dans le film Vertigo.
   (2 enregistrements)
10. Quel réalisateur a tourné dans ses propres films ? Donnez le nom, le rôle
    et le titre des films. (4 enregistrements)
11. Où peut-on voir le film _Pulp Fiction_ ? On donnera le nom, l'adresse du
    cinéma et numéro de la séance. (1 enregistrement)
12. Où peut-on voir un film avec Clint Eastwood ? On donnera le titre du film,
    le nom et l'adresse du cinéma, ainsi que l'heure de début du film. (1
    enregistrement)

# 2. Modification de la base cinéma


1. On souhaite insérer un nouvel artiste. Il s'agit de Ridley Scott, né en 1937.
    Indiquez la requête SQL permettant de réaliser cette opération.

2. Ridley Scott est le réalisateur du film _Blade Runner_, sorti en 1982.
   Indiquez la requête.
3. Les acteurs principaux sont Harrisson Ford (né en 1942) dans le rôle de Rick
   Deckard et Rutger Hauer (né en 1944) dans le rôle de Roy Batty. Indiquez la
   requête SQL permettant de saisir ces nouveaux enregistrements.
4. Mark Hamill (né en 1951), Harrisson Ford (né en 1942) et Carrie Fisher (née
   en 1956) sont les acteurs principaux du film _L'empire contre attaque_ réalisé
   en 1980 par Irvin Kershner (né en 1923). Indiquez les requêtes SQL
   permettant de saisir ces enregistrements.  Indiquez l'ordre dans lequel il
   faut remplir les relations.
5. Le réalisateur moldave Mevatlave Kraspeck est décédé brutalement hier à
   l'âge de 103 ans.  Le Rex décide de lui rendre hommage en diffusant le film
   _Gant, Savon, Serviette et Ponge_ tourné en 1957 avec la star du cinéma muet
   Agathe Zeblouse (née en 1932) dans la salle 1 de 13h à 16h, le film _Shower
   on the Beach_ tourné en 1963 avec Camille Honnête (née en 1940) dans la salle
   1 de 16h à 18h et _Bains Moussants_ avec Jacques Célère (né en 1945 et décédé
   trop vite en 1968) tourné en 1967 dans la salle 2 de 15h à 18h. Indiquez les
   requêtes SQL permettant de modifier les séances du cinéma Rex.
7. Supprimez tous les films et acteurs ajoutés à la question 5, le réalisateur
    moldave n'étant pas décédé mais seulement parti en vacances, le Rex a
    renoncé à ces diffusions. Indiquez la requête SQL nécessaire.

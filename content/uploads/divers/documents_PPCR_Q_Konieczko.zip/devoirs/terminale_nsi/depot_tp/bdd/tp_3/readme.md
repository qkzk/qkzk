NSI Terminale
=============

Lycée des Flandres

Récupérer et organiser des données réelles
======================================

* Dans ce TP, vous allez travailler sur des données réelles
    [movies.csv](./movies.csv). Ces données en csv sont issues de
    [data.world](https://data.world).

* Le fichier [movies_correction.db](./movies_correction.db) est la base de donnée
    que vous devez obtenir après la deuxième partie. Si vous n'arrivez pas à créer
    cette BDD, utilisez la correction.


## Partie 1: Réfléchir sur les données

Depuis DB Browser, créer une nouvelle base de données que vous pouvez appeler `movies`.
Créer une table `movie_metadata` contenant les données du csv [movies.csv](./movies.csv) (onglet Fichier, Importer, Table depuis un fichier csv). Lors de l'import, pensez à cocher la case "Nom des colonnes en première ligne" et à choisir comme séparateur la virgule.

Vous pouvez à présent visualiser les colonnes et les données contenues dans cette table.

* À partir des données observées, imaginez un découpage des données permettant une décomposition plus claire.

## Partie 2: Création des tables et des contraintes

Nous allons utiliser le modèle suivant <img src="./movies.png" width="300"/>.

* Il faut maintenant créer les tables manquantes et les remplir.

```sql
create table realisateur as
  select DISTINCT realisateur as nom_realisateur,
    realisateur_facebook_likes as likes
    from movie_metadata;
```

Vous pouvez vérifier qu'il y a pas de doublon (deux fois le même nom) dans la nouvelle table créée avec la requête suivante
(complètement hors programme NSI):

```sql
select nom_realisateur, count(*)
  from realisateur
  group by nom_realisateur
  having count(*)>1;
```

Elle ne doit retourner aucun enregistrement.

Si c'est le cas, vous pouvez définir `nom_realisateur` comme clé primaire de la table `realisateur` (onglet "Structure de la Bases de données", "modifier la table", cochez CP comme Clé Primaire).

* Quel est l'ensemble des résultats que retourne la requête suivante?

```sql
select DISTINCT acteur1 as nom_acteur,
  acteur1_facebook_likes as likes
  from movie_metadata UNION
    select DISTINCT acteur2 as nom_acteur,
      acteur2_facebook_likes as likes
      from movie_metadata;
```

Inspirez vous de cette requête, et de la requête qui nous a permis
de créer la table `realisateur`, pour créer et remplir la table `acteur`.
N'oubliez pas qu'il y a 3 acteurs cités par film.
Une fois la table créée et remplie, ajoutez la clé primaire.


* Il reste la table `film`. Deux solutions sont possibles: renommer la table `movie_data` en `film`  puis supprimer les colonnes devenues inutiles, ou créer une nouvelle table en ne sélectionnant que les colonnes pertinentes (sur le modèle des tables précédentes). Ajouter la clé primaire et les clés étrangères.
Pour créer les clés étrangères, il faut double-cliquer sur la ligne
qui correspond à l'attribut que l'on veut au niveau de la colonne "Clé étrangère". Cela donne accès à des menus déroulants qui permettent de choisir la table et la colonne à laquelle la clé fait référence puis
presser la touche `entrer` pour valider la clé.


## Partie 3: Quelques requêtes

* Tous les acteurs du film Ben-Hur
(attention, le titre contient un espace à la fin de la chaîne de caractères)



* Tous les films de Brad Pitt


* Les films réalisés par Tim Burton dans lesquels Johnny Depp est l'acteur 1.




* Les acteurs qui ont plus de 10.000 likes, par ordre décroissant.



* Les films dont le réalisateur a plus de 5.000 likes, par ordre décroissant.



* Les acteurs dont le nombre de like est pair.



* Le nombre de likes pour ces acteurs dont le nombre de likes est
  pair.



* Les acteurs qui sont acteur1 d'un film et acteur2 d'un autre film.



Les deux requêtes suivantes nécessitent un `GROUP BY`, elles ne sont donc pas au programme pour les élèves.

* Coût moyen des films par réalisateur, du moins cher au plus cher.



* Le nombre de films par année, du plus grand nombre vers le plus petit



## Partie 4: Depuis un programme ?

Petit challenge: les requêtes suivantes peuvent-elles être faites uniquement en SQL ou un programme est-il nécessaire?

* Le pays dans lequel le plus de films ont été réalisés.



* Le pourcentage de films par pays.



* Y a t-il plus de likes pairs ou de likes impairs chez les réalisateurs?



* Les réalisateurs qui sont aussi acteurs (de leur film ou d'un autre)

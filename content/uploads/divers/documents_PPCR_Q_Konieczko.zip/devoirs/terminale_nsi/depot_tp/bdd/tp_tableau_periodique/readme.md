# Utiliser SQLITE depuis Python

# 0. Rappel des commandes de bases :

Vous pouvez consulter l'exemple ci-joint : [intro.py](./intro.py)

1. Importer le module `sqlite3`

    ```python
    import sqlite3
    ```

2. Se connecter à une base de donnée, créer un curseur.

    * La connexion se crée avec :

        ```python
        conn = sqlite3.connect("mon_fichier.db")
        ```

        Cet objet permet de modifier les propriétés de la base de donnée
        elle même. Nous l'utiliserons pour créer un curseur et fermer
        la connexion.

    * Le curseur se crée avec :

        ```python
        cursor = conn.cursor()
        ```

        Le curseur permet d'exécuter des requêtes et de lire les réponses
        rendues par la base.

    * Avant de quitter le script il faut fermer la connexion et le curseur, on
        ajoute tout en bas :

        ```python
        conn.close()
        cursor.close()
        ```

3. Exécuter des requêtes :

    * Obtenir une information (`SELECT`)

        ```python
        requete = '''
        SELECT * from ma_table WHERE ma_condition;
        '''
        cursor.execute(requete)
        ```

        Cette commande modifie l'objet `cursor` qui contient maintenant la
        réponse à la requête.

    * Afin de lire _une_ réponse :

        ```python
        cursor.fetchone()
        ```

        On obtient un _tuple_ avec les enregistrements.

    * Afin de lire _toutes_ les réponses :

        ```python
        cursor.fetchall()
        ```

        On obtient une _liste_ de _tuples_ avec les enregistrements.

    * On peut laisser des paramètres libres dans une requêtes avec des `?`

        ```python
        requete_avec_parametre = '''SELECT * FROM ma_table WHERE nom=?;'''
        cursor.execute(requete_avec_parametre, ('Dubois', ))  # Dubois remplace le ?
        ```

    * Toutes les requêtes d'écriture (`INSERT`, `DELETE`, `UPDATE`) doivent
        être enregistrées dans la BDD.

        Pour cela on enregistre avec la méthode `commit` de la classe
        connexion :

        ```python
        cursor.execute("DELETE FROM ma_table WHERE condition;")
        conn.commit()
        ```

# La base de donnée "TableauPeriodique.db"

Le schéma relationnel de la base **TableauPeriodique** est le suivant :


| **Element**        |        |
|--------------------|--------|
| **numeroAtomique** | entier |
| nom                | texte  |
| symbole            | texte  |
| nombreMasse        | entier |
| masseAtomique      | réel   |
| masseVolumique     | réel   |
| tFusion            | réel   |
| fEbullition        | réel   |
| rayonAtomique      | réel   |

La clé primaire est indiquée **en gras**.

Ouvrez le fichier tableau_periodique.py dans l’éditeur Thonny, et assurez vous
que le fichier

# Consignes : fonctions à créer

1. Créer une fonction `conn_cursor` qui retourne deux objets : une connexion et un curseur.

2. Créer une fonction `close` qui prend en paramètre une connexion et un curseur
    et ferme ces connexions.
3. Créer une fonction `lire_ligne` qui prend en paramètre une requête de lecture
    et renvoie une ligne de la réponse.
4. Créer une fonction `lire_tout` qui prend en paramètre une requête de lecture
    et renvoie toutes les lignes de la réponse.
5. Modifiez vos fonctions pour qu'elles acceptent des paramètres dans la requête.
6. Créer une fonction `ecrire` qui prend en paramètres une requête d'écriture
    et d'éventuels paramètres. On n'oubliera pas d'écrire dans la base avec
    un `commit`

# Consignes : accès aux informations :

Utilisez vos fonctions pour répondre aux questions suivantes.
Affichez (avec `print`) une phrase utilisant les réponses obtenues pour 
répondre à chaque question.

1. Quel est le symbole du _Zirconium_ ?

2. Affichez toutes les informations du Bore (_Boron_).
3. Quel est l'élément qui a la température d'ébullition la plus élevée ?
    La plus petite basse ?

# Consignes : modifier un élément :

(_Je précise que les données suivantes sont fantaisistes, jusqu'ici tout
était scientifiquement valide_)

1. Supprimer l'élément Plomb qui en fait, n'existe pas.
2. Modifier le _Neptunium_ pour lui donner le nom que vous voulez.
3. Ajouter l'élément `Horacium` :

    | Propriété       | Valeur   |
    |-----------------|----------|
    | Numéro atomique | 202      |
    | Nom             | Horacium |
    | Symbole         | Hc       |
    | nombre de masse | 43       |
    | masse atomique  | 43.45    |
    | masse volumique | 2.33     |
    | t. fusion       | 1612.32  |
    | t. ebullition   | 2143.16  |
    | rayon atomique  | 157      |

# Consignes : utilisation interactive

Créer un script qui affiche une série de question réponse proposant à un
utilisateur :

1. De choisir entre le nom complet et le symbole,

2. Qui présente chaque information de l'élément demandé sur une ligne,
3. Qui revienne à la question initiale si l'utilisateur le souhaite.

Exemple d'utilisation :

```bash
$ python elements.py
Répondez aux questions suivantes pour afficher les informations d un élément.

Souhaitez vous chercher par le nom ou par le symbole ? symbole
Quel élément souhaitez-vous afficher ? Hg

numéro atomique :   80
nom :               Mercury
symbole :           Hg
nombre de masse :   204
masse atomique :    200.59
masse volumique :   13.546
t. fusion :         234.28
t. ebullition :     629.73
rayon atomique :    157

Souhaitez-vous continuer (oui/non) ? oui
Souhaitez vous chercher par le nom ou par le symbole ? nom
...
```

Idéalement, votre script ne plante pas si l'utilisateur cherche un élément
introuvable.


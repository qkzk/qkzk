'''
Vous partez d'un script qui contient déjà

* une fonction qui crée les tables si elles n'existent pas : `creer_tables`,
* une fonction permettant d'ajouter un client : `ajouter_clients`,
* une fonction permettant d'ajouter un compte et sa possession : `ajouter_compte_possession`,
* une fonction permettant de modifier un champ du client : `modifier_champ_client`,
* une fonction de visualisation de l'état d'un compte : `etat_compte`,
* une fonction de visualisation de l'état d'un client : `etat_client`,
'''

import sqlite3
from query_enonce import Query

FICHIER_BDD = 'v2_client_compte_enonce.db'


def connexion_curseur(bdd=FICHIER_BDD):
    '''Crée une connexion à la bdd passée en paramètre.
    Retourne la connexione et le curseur
    @param bdd: (str) l'adresse d'un fichier contenant une bdd sqlite3
    @return: (tuple) connexion et curseur
    '''
    conn = sqlite3.connect(bdd)
    cur = conn.cursor()
    return conn, cur


def effectuer_modification(requete, parametres=None):
    '''
    Effectue une requête modifiant la base de donnée. La requête est enregistrée
    @param requete: (str) une requête
    @param parametres: (tuple) les champs particuliers. Laisser vide s'il n'y
        en a pas.
    '''
    conn, cur = connexion_curseur()
    if parametres is None:
        cur.execute(requete)
    else:
        cur.execute(requete, parametres)
    conn.commit()
    fermer_connexion(conn)


def selectionner_donnees(requete, parametres=None, multiples=False):
    '''
    Retourne les réponses de sqlite lorsqu'on consulte la bdd.

    @param requete: (str)
    @param parametres: (tuple) les champs
    @param multiples: (bool) initialisé à False. Une ou plusieurs réponse ?
    '''
    conn, cur = connexion_curseur()
    if parametres is None:
        cur.execute(requete)
    else:
        cur.execute(requete, parametres)
    if multiples:
        resultat = cur.fetchall()
    else:
        resultat = cur.fetchone()
    fermer_connexion(conn)
    return resultat


def fermer_connexion(conn):
    '''Ferme la connexion transmise en paramètre.'''
    conn.close()


def creer_tables():
    '''Permet de créer toutes les tables du sujet
    Ne plante pas, mais affiche une exception si les tables existent déjà.
    RQ. C'est un procédé courant, normalement on enregistre ça dans un journal.
    '''
    for query in Query.creer_tables:
        try:
            effectuer_modification(query, parametres=None)
        except sqlite3.IntegrityError as e:
            print(repr(e))


def ajouter_clients():
    '''Ajoute tous les cliens depuis une liste de requêtes.
    Ne plante pas, mais affiche une exception si les tables existent déjà.
    '''
    for query in Query.ajouter_clients:
        try:
            effectuer_modification(query, parametres=None)
        except sqlite3.IntegrityError as e:
            print(repr(e))


def ajouter_comptes_possessions():
    for query in Query.ajouter_comptes_possessions:
        try:
            effectuer_modification(query, parametres=None)
        except sqlite3.IntegrityError as e:
            print(repr(e))


def modifier_champs_client(no_client, valeurs):

    parametres = (valeurs['nom'], valeurs['prenom'], str(no_client))
    try:
        effectuer_modification(Query.modifier_champs_client,
                               parametres=parametres)
    except Exception as e:
        print(repr(e))
        raise e


def etat_compte(no_compte):
    '''
    Consulte l'état du compte fourni en paramètre.
    @param no_compte: (int)
    @return: (tuple) numéro de compte (int), solde (int), date d'accès (str)
    '''
    return selectionner_donnees(Query.etat_compte,
                                parametres=(no_compte,))


def etat_client(nom, prenom):
    return selectionner_donnees(Query.etat_client,
                                parametres=(nom, prenom),
                                multiples=True)


def presenter_compte(compte):
    '''
    Retourne une chaîne de caractères formatée contenant les infos
    particulières d'un compte.
    @param compte (tuple) numero, nom, prenom, solde, date d'accès.
    '''
    return '''Le compte n° {} appartenant à {} {} a un solde de {} euros,
dernier accès le {}
'''.format(*compte)


def exemple():
    '''
    * créer les tables
    * peuple client
    * peuple compte
    * peuple possession
    * modifier une valeur
    * afficher l'état des données perso d'un client
    * affiche l'état d'un compte
    '''
    creer_tables()
    ajouter_clients()
    ajouter_comptes_possessions()

    modifier_champs_client(2, {'nom': 'Dubruk', 'prenom': 'Franck'})
    etat_compte_1 = etat_compte(1)
    print(etat_compte_1)

    etat_delune = etat_client('Delune', 'Claire')
    print()
    for compte in etat_delune:
        print(presenter_compte(compte))


if __name__ == '__main__':
    exemple()

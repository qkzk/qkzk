
class Query:
    creer_tables = [
        '''-- table client
CREATE TABLE IF NOT EXISTS "client" (
	"no_client"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
	"nom"	TEXT NOT NULL,
	"prenom"	TEXT NOT NULL
);''',
        '''-- table compte
CREATE TABLE IF NOT EXISTS "compte" (
	"no_compte"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
	"montant"	INTEGER,
	"date_access"	TEXT
);''',
        '''
-- table possession
CREATE TABLE IF NOT EXISTS "possession"(
	"no_client"	INTEGER,
	"no_compte"	INTEGER,
	PRIMARY KEY("no_client", "no_compte"),
	FOREIGN KEY ("no_client") REFERENCES client("no_client"),
	FOREIGN KEY ("no_compte") REFERENCES compte("no_compte")
);''']

    ajouter_clients = [
        '''INSERT INTO client
	-- les noms des colonnes
	(no_client, nom, prenom)
	VALUES
	-- les valeurs entres guillements
	("1", "Duchmol", "Robert");''',

        '''INSERT INTO client
	(no_client, nom, prenom)
	VALUES
	-- les valeurs entres guillements
	("2", "Dubruk", "Raoul");''',
        '''INSERT INTO client
	-- on peut zapper le numero de client grâce à 'autoincrement'
	(no_client, nom, prenom)
	VALUES
	-- les valeurs entres guillements
	("3", "Minvussa", "Gérard");''',
        '''INSERT INTO client
	(no_client, nom, prenom)
	VALUES
	("4", "Honnête", "Camille");''',
        '''INSERT INTO client
	(no_client, nom, prenom)
	VALUES
	("5", "Delune", "Claire");''']

    ajouter_comptes_possessions = [
        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("1", "100", "2020-04-01T00:00");''',

        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("2", "875", "2019-02-13T00:00");''',

        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("3", "1234", "2020-02-28T00:00");''',

        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("4", "-54", "2019-12-14T00:00");''',

        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("5", "3409", "2019-09-13T00:00");''',

        '''INSERT INTO compte
	-- les noms des colonnes
	(no_compte, montant, date_access)
	VALUES
	--YYYY-MM-DDTHH:MM
	("6", "-91", "2019-01-02T00:00");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("1", "1");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("2", "2");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("3", "3");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("4", "4");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("5", "5");''',

        '''INSERT INTO possession
	-- les noms des colonnes
	(no_client, no_compte)
	VALUES
	("5", "6");''']

    modifier_champs_client = '''UPDATE client
SET nom = ?,
    prenom = ?
WHERE
    no_client = ?
    '''
    etat_compte = '''
SELECT
    *
FROM
    compte
WHERE
    no_compte = ?
    '''
    etat_client = '''
SELECT
  compte.no_compte, client.nom, client.prenom, compte.montant, compte.date_access
FROM compte
  INNER JOIN possession
    ON possession.no_compte = compte.no_compte
  INNER JOIN client
    ON client.no_client = possession.no_client
  WHERE
        client.nom = ?
    AND
        client.prenom = ?
'''

import sqlite3

# se connecter, créer un curseur
conn = sqlite3.connect("mon_exemple.db")
cursor = conn.cursor()


# lire une ligne
requete_lecture_1_ligne = '''SELECT * FROM ma_table WHERE nom='DUBOIS';'''
cursor.execute(requete_lecture_1_ligne)
une_ligne = cursor.fetchone()

# lire toutes les lignes
toutes_les_lignes = cursor.fetchall()

# passer des paramètres
requete_avec_parametre = '''SELECT * FROM ma_table WHERE nom=?;'''
cursor.execute(requete_avec_parametre, ('Dubois', ))  # Dubois remplace le ?
une_ligne = cursor.fetchone()

# écrire
requete_ecriture = '''DELETE FROM ma_table WHERE nom='Dubois';'''
cursor.execute(requete_ecriture)
# on enregistre avec :
conn.commit()


# fermer les objets
cursor.close()
conn.close()

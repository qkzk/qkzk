# TP banque, partie 1

## Présentation

Nous disposons du modèle suivant :

* Une banque contient des clients. Ils ont un nom et un prénom.
* Elle contient aussi des comptes. Chaque compte a un solde et une date d'accès.
* Chaque client peut contenir un ou plusieurs comptes.

Cela se résume par le schéma "type UML" suivant :

![img/1_client_possede_compte.png](img/1_client_possede_compte.png)

Et nous avons déjà proposé le modèle relationnel suivant :

![img/client_compte_schema.png](img/client_compte_schema.png)

Dans les données présentées ci-dessus :

* les numéros (de compte et de client) sont des entiers. Le solde aussi (supposé
    en euro). On utilisera le type `INTEGER`

* Les dates et les noms sont des chaînes de caractères. On utilisera le type
    `TEXT` Les dates sont saisies dans un format universel :

    `YYYY-MM-DDTHH:MM:SS` compris par tous nombre de langages.

---

Nous allons implémenter ce schéma, saisir les données présentes dans les trois
fichiers csv fournis et réaliser différents accès à ces données : sélections
simples, mises à jour et sélections plus complexes.

L'objectif est de vous entraîner au langage sql et toutes les manipulations
sont à faire dans sqlite browser.

Sqlite browser permet de créer tous les éléments à la main, en cliquant sur
les menus mais nous ne le ferons pas.

**Vos réponses sont les fichiers `.sql` correspondant à chaque partie du TP.**

## Création des tables


### À faire 0 - sqlite browser


1. Ouvrir le logiciel **sqlite browser (db browser)** et créer une nouvelle base
    de données. Fermer la page de création de table.

2. Cliquer sur l'onglet **Exécuter SQL**.


Toutes les manipulations suivantes doivent être exécutées directement dans
cet onglet.

* Vous préparez un fichier `.sql` dans **sublime text**,
* Vous copiez-collez votre syntaxe sql dans **sqlite browser**,
* Vous exécutez avec **F5** (bouton _play_)
* Vous rectifiez les erreurs de syntaxe sans modifier les valeurs à la main.
* Quand vous êtes satisfait, **"Ecrire les changements / Write Changes"**
* Avant de passer à la question suivante, vous pouvez ajouter un nouvel onglet.

    Cela vous évite d'écrire sur vos précédentes réponses.

### À faire 1 : création de la table

Dans le logiciel **sqlite browser** créer les trois tables `client`, `compte`,
et `possession`.

On veillera à respecter **toutes** les contraintes nécessaires.

C'est l'étape la plus délicate, réfléchissez bien avant d'avancer.

Sauvegarder les commandes de création dans un fichier intitulé `creation_banque.sql`

_Quelques indications._

1. Commencez par `client` et `compte`. Vous avez besoin de leurs champs pour créer `possession`
2. Vous pouvez "tricher" en vous aidant des menus de sqlite browser pour choisir les bonnes options.

    C'est particulièrement utile pour les clés principales.

3. Pour la table possession, n'oubliez pas deux choses :

    * le client ne possède le compte **qu'une fois** donc chaque possession est une clé principale.
    * le client et le compte doivent **déjà exister** donc les références sont des clés étrangères.

### À faire 2 : clients

Ajouter les clients correspondant au fichier csv `clients.csv`

Sauvegarder les commandes de création dans un fichier intitulé `ajouter_clients.sql`

### À faire 3 : comptes

Ajouter les comptes correspondant au fichier csv `comptes.csv`

Sauvegarder les commandes de création dans un fichier intitulé `ajouter_comptes.sql

### À faire 3 : possessions

Ajouter les possessions correspondant au fichier csv `possessions.csv`

Sauvegarder les commandes de création dans un fichier intitulé `ajouter_possessions.sql

## Sélections simples

Pour plus de facilité, vous enregistrez vos sélections dans un unique fichier
`selections_simples.sql`

### À faire 4 : sélections simples

Pour chaque question, proposer une commande sql qui affiche l'information demandée.

1. Afficher le prénom de M. Duchmol.
2. Existe-t-il un client prénommé Marcel ?
3. Quels sont les numéros de compte dont le solde est négatif ?
4. Quels sont les numéros de client ayant plusieurs comptes ?

## Mises à jour

Pour plus de facilité, vous enregistrez vos sélections dans un unique fichier
`mise_a_jour.sql`

### À faire 5 : mise à jour

1. Le prénom de M. Dubruk est faux, il se prénomme en fait Frank. Rectifiez cette erreur.
2. M. Menvussa est en fait très riche ! Le solde de son unique compte doit être multiplié par 10.

    1. Proposez une rectification simple, en tapant vous même la valeur (une commande sql, pas directement dans les valeurs de la table !).
    2. Proposez une rectification **sans taper la valeur dans la commande sql**


## Sélections complexes

Pour plus de facilité, vous enregistrez vos sélections dans un unique fichier
`selections_complexes.sql`

### À faire 6 : sélections complexes

Pour chaque question, proposer une commande sql qui affiche l'information demandée.

1. Affichez tous les clients et leurs soldes différents par ordre alphabétique du nom.

    ~~~
    Arabousse 100
    Boquet    150
    Boquet    -20
    ...
    ~~~

2. Quel est le solde total de Mme. Delune ?
3. Affichez les clients et leurs soldes totaux.
4. Quel est le client le plus aisé ?


## Conclusion

Dans ce TP vous avez revu les manipulations de base (création de table,
insertion, sélections et mises à jour). On pourrait ajouter le fait d'effacer
des données mais ce n'est pas très différent.

Dans un prochain TP nous allons implémenter en Python certain des accès réalisés.

Un dernier mot sur une des données présentée : **le solde**.

En pratique, ce n'est pas comme ça qu'il faut faire. Nous avons supposé nos
soldes entiers, c'est une bonne idée, mais que faire d'un solde de 34.54€ ?

Et ensuite, comment gérer les nombres à virgules pour vérifier les calculs ?

En informatique, on n'a pas toujours `0.1 + 0.1 == 0.2` (cf cours sur les
flottants de première). La solution est d'utiliser des centimes. On compte
l'argent en centimes et le tour est joué. Pour afficher à l'écran en euro,
on décale une virgule de 2 positions.

Autre problème : les banques enregistrent en fait des _transactions_ et le solde
est le résultat de ces transactions.

Dans un travail ultérieur, c'est ce que nous ferons. Nous allons gérer ces
transactions au sein d'une unique banque (pas d'argent en espèce, pas de compte
extérieur à la banque) et calculer nous même le solde. Nous pourrons ainsi
vérifier dans SQL et à l'extérieur (avec Python) que le solde est juste !

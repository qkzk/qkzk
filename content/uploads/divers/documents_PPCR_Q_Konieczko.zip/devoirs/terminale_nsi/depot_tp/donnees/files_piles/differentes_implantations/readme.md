---
title: "NSI - Terminale - Structure de données"
subtitle: "Les files : différentes implémentations d'une file"
author: "qkzk"
date: "2020/11/18"
theme: metropolis
geometry: margin=1.5cm

---

# Différentes implémentations d'une file



## En utilisant les listes python et le travail déjà réalisé sur les piles

**A faire 1** : reprendre le précédent TP sur la calculatrice NPI et adapter
la classe `Pile` en une classe `File`. Penser à renommer les méthodes et vous
assurer qu'on respecte bien la structure de donnée FIFO (First In First Out)

**A faire 2** : ajouter un jeu de tests génériques

## En utilisant deux piles

Il est possible d'implémenter une **file** en utilisant deux piles.

Voici le principe :

* Une pile appelée `entree` est remplie lorsqu'on enfile un élément,
* lorsqu'on défile un élément, on vide complètement cette première pile dans
    une seconde pile appelée `sortie`. On renvoie ensuite le résultat de `depiler(sortie)`

**A faire 3** : dessiner sur une feuille deux piles appelées
entrée et sortie compléter les deux files au fur et à mesure du déroulé
des instructions suivantes.

```python
>>> f = File()
>>> f.enfiler(1)
>>> f.enfiler(2)
>>> f.enfiler(3)
>>> f.defiler()
1
>>> f.defiler()
2
>>> f.defiler()
3

```

**À faire 4** reprendre aussi la classe Pile du TD NPI. Implémenter une nouvelle
classe `File_deux_piles` utilisant le principe présenté plus haut.

Tester vos résultats.

## Comparaison des complexités.


**A faire 5** : Mesurer pour les listes des entiers de 1 à 1000, 10000, 100000 etc.
le temps nécessaire pour remplir et vider chacune des deux piles implémentées.

Que dire de la complexité ?

Quelles sont les étapes qui ralentissent les deux implémentations ?

## Utiliser la classe `deque`

**A faire 5** : Exécuter le code suivant en mode interactif dans Thonny :

```python
from collections import deque
ma_file = deque()
print(dir(ma_file))
```

Documentez-vous (avec help) sur les méthodes suivantes :

* `append`
* `pop`
* `popleft`

** A faire 6**

On souhaite simuler une file avec un `deque`, quelles méthodes employer pour :

* créer une file ?
* enfiler ?
* défiler ?
* tester si la file est vide ?

Si l'interface des `deque` est très proche de celle des `list` habituelles,
la complexité n'est pas la même.

Comparer le temps d'exécution du remplissage d'une file avec `deque` et d'une
`list` python (qu'on vide avec `pop(0)`) pour 100000 éléments.

Verdict ?

**A faire 7**

Reprendre cette comparaison entre `deque` et `list` pour la simulation d'une
pile. On videra les deux avec `pop()`

Verdict ?

## Construire une pile de manière récursive

**A faire 8** Compléter les méthodes du fichier `pile_squelette`.

Il contient de quoi créer une pile de manière récursive à la manière des listes
déjà rencontrées précédemment.

Cette fois on utilise une classe `Cellule` qui permet de manipuler un élément
à la fois.

On utilisera une méthode récursive pour défiler. Prenez le temps de tester à
la main avant d'écrire du code.

Tester vos méthodes avec les exemples donnés plus haut.

**A faire 9** Comparer les temps d'exécutions pour empiler puis dépiler 10000
éléments avec nos deux implémentations des piles (celle du début et celle
récursive).




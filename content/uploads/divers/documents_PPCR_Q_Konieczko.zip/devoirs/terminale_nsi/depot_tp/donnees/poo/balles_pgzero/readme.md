---
title: Animer des balles à l'écran
author: qkzk
date: 2020/03/25
---

# Animation de balles à l'écran

![balles](balles.png)

On dispose 200 disques de rayon 1 aléatoirement à l'écran.

Ils grandissent tous en même temps jusqu'à se toucher... Quelle taille
peuvent-ils atteindre ?

Nous allons réaliser une animation présentant cela.

# Documents

Vous disposez d'un fichier [balles_squelette](balles_squelette.py) qui présente
la signature de tous les objets du projet. Il ne reste plus qu'à les écrire.

# Technologies

Ce projet sera réalisé en Python en paradigme **objet** avec la librairie
[pygame zero](https://pygame-zero.readthedocs.io/en/stable/index.html#)

## La classe `Balle`

Chaque balle à l'écran sera un objet de type `Balle`

Nous devons donc implémenter une classe `Balle`

Elle doit implémenter les méthodes suivantes :

* **`centre`**  : retourne les données du centre (tuple),
* **`rayon`** : retourne la valeur du centre (int),
* **`montrer`** : dessine la balle à l'écran
* **`intersecter`** : retourne vrai si une balle intersecte une autre (bool)
* **`grandir`** : augmente le rayon si c'est possible (c-à-d : aucune
    intersection avec une autre balle)

Nous détaillerons les méthodes plus bas.

## Utilitaires

Nous avons aussi besoin de quelques **fonctions** utilitaires. Elles ne figurent
dans aucune classe.

* **couleur aléatoire** : Retourne une couleur aléatoire.

  Attention dans pygame, les couleurs sont des tuples
  `(r, g, b)` où chaque couleur est un entier entre 0 et 255.

  Donc `(255, 0, 0)` va désigner du rouge.

* **`distance`** : retourne la distance entre deux couples de coordonnées :

  ```python
  >>> distance((1, 0), (4, 4))
  5.0
  ```

* **`setup`** : une fonction permettant d'initialiser un tableau contenant
  toutes nos balles.

  * Leurs positions sont aléatoires,
  * les rayons valent tous 1
  * les couleurs sont aléatoires.

* **`update`** : fonction appelé automatique par `pgzero` et qui se charge
  de dessiner les éléments à l'écran.

  On n'oubliera pas de vider l'écran (méthodes `screen.clear` et `screen.fill`) !

  [Documentation de pgzero](https://pygame-zero.readthedocs.io/en/stable/builtins.html#Screen.clear)

## pgzero

Nous allons utiliser **pygame zero** qui permet de dessiner très rapidement des
animations.

Un script pgzero se découpe en différentes parties :

1. les **imports** :

    La première ligne du programme doit être :

    ```python
    import pgzrun
    ```

2. l'**exécution** :

  La **toute dernière ligne du programme** doit être :

  ```python
  pgzero.go()
  ```

3. Les **constantes** :

  `pgzero` utilise différentes constantes qu'on peut définir à notre guise :

  * `WIDTH`, `HEIGHT` : (int) les dimensions de la fenêtre,
  * `TITLE` : (str) le titre de la fenêtre

## Compléments sur la classe `Balle`

C'est la classe principale de ce petit projet.

Je vous invite à créer ses méthodes dans cet ordre :

1. Commencez par définir les données géométriques de la balle, sans vous
    soucier des parties sur l'intersection et l'agrandissement.

    Définissez la classe, créez une instance de celle-ci

2. Dessiner une balle à l'écran, au centre, rouge, de rayon 20.
    On la verra comme ça !

3. Faites une figure et déterminez un critère portant sur les centres et les
    rayons vous permettant de savoir si deux disques s'intersectent.

3. Instanciez une dizaine de balles à des positions aléatoires avec des couleurs
    aléatoires, de diamètre 30. Elles devraient s'intersecter !

    Essayez d'écrire une méthode qui renvoie `True` si une balle en touche une
    autre

    Itérez sur vos balles : afficher dans la console une info disant qu'une
    balle intersecte une voisine. Essayez de savoir _lesquelles_ !

    ```python
    balle 1 intersecte balle 3
    balle 3 intersecte balle 1
    ...
    ```

5. méthode `grandir` :

  * que devez-vous faire ?
  * que devez-vous vérifier ?
  * Sur quoi doit-on itérer ?

4. Terminez le projet : faites grandir les 200 balles, de rayon 1 jusqu'à ce
    qu'elles ne puissent plus le faire.

5. Si ça n'est pas fait, n'oubliez pas de documenter !

## Sources

* [Circle packing](https://en.wikipedia.org/wiki/Circle_packing) : l'entassement de disque sur une surface

  ![order & chaos](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Order_and_Chaos.tif/lossy-page1-640px-Order_and_Chaos.tif.jpg)

  Ce phénomène, qui apparaît naturellement, est copieusement étudié en mathématiques

  Une variante de ce projet serait de reproduire cette image :

  ![configurations](https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Fundamental_Circle_Packings_%28Better%29.png/614px-Fundamental_Circle_Packings_%28Better%29.png)

* [The Coding Train: part 1](https://www.youtube.com/watch?v=QHEQuoIKgNE), [part 2](https://www.youtube.com/watch?v=ERQcYaaZ6F0)

  Reproduire ces projets en Python serait intéressant !

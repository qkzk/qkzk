---
title: Terminale NSI - Structures de données
subtitle: Arbres binaires, travaux pratiques séance 1
date: 2020/04/23
---

# Implémenter les algorithmes de base sur les arbres binaires

Dans le TD d'introdcution sur les arbres binaires on a vu
quelques algorithmes de base sur les arbres binaires.

Dans ce TP nous allons les programmer.

## Une structure pour les arbres binaires

**Quelle structure choisir pour représenter les arbres binaires ?**

De nombreuses approches sont possibles, la plus simple est
d'utiliser des tuples ou des listes.

_Dans un prochain TP on implémentera des arbres binaires autrement,_
_à l'aide de classes._

C'est travail élaboré, nous allons d'abord nous contenter du minimum.

En TD, tous les arbres étaient représentés avec des parenthésages.

Nous aimerions pouvoir faire de même.

On voudrait pouvoir ecrire :

```python
arbre_1 = (3, (1, (1, ∆, ∆), (5, ∆, ∆)), (4, (9, ∆, ∆), (2, ∆, ∆)))
```

Qu'on peut dessiner ainsi :

![arbre_1](img/arbre_1.png)

Ou comme ça :

```
3
├── 1
│   ├── 1
│   │   ├── ∆
│   │   └── ∆
│   └── 5
│       ├── ∆
│       └── ∆
└── 4
    ├── 9
    │   ├── ∆
    │   └── ∆
    └── 2
        ├── ∆
        └── ∆
```

Gros problème : **L'arbre vide**

Souvenons-nous que ∆ désigne un arbre _vide_.
Nous allons le remplacer par une constante, `VIDE = ()`

Et c'est tout.

```python
VIDE = ()
arbre_1 = (3,
          (1, (1, VIDE, VIDE), (5, VIDE, VIDE)),
          (4, (9, VIDE, VIDE), (2, VIDE, VIDE)))
```

Et voilà notre arbre en mémoire.

## Le module [arbres.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/arbres/3_tp/arbres.py)

Il contient les différentes fonctions et prédicats pour :

* savoir si un arbre est vide,
* obtenir son contenu (la valeur du noeud),
* obtenir son sous arbre gauche,
* obtenir son sous arbre droit.
* afficher une présentation de l'arbre,
* afficher un dessin de l'arbre (en mode texte).

Il est fourni complet et documenté.
Rien à ajouter à ces fonctions, ce n'est pas l'objectif du jour.

La dernière fonction, `presenter_exemple`
contient le code pour afficher un exemple dans la console.

---

### A faire 1. Utiliser ce module

0. Exécutez ce module dans la console.

1. Créez une fonction `exemple_complet`

  * Elle ne prend pas de paramètre et ne retourne rien.
  * Vous y construisez l'arbre présenté plus haut.
  * Affichez son contenu, son sous arbre gauche et son sous-arbre droit.
  * dessinez le dans la console.
  * Cet arbre est-il complet ?


2. Créez une fonction `exemple_filiforme`

  * Elle ne prend pas de paramètre et ne retourne rien.
  * Créez un arbre filiforme (voir le cours).
  * Dessinez le.
  * Calculez sa taille et sa hauteur. Vérifiez la propriété vue en cours
      permettant de savoir si un arbre est filiforme.

3. Créez une fonction `exemple_localement_complet`

  * Elle ne prend pas de paramètre et ne retourne rien
  * Créez un arbre localement complet, qui _ne soit pas complet_ (voir le cours)
  * Dessinez le.

---

### A faire 2. Les algorithmes vus en cours

1. Créez un nouveau fichier `algorithmes.py`
2. Importez le module principal avec

    ```python
    import arbres
    ```

3. Programmez les fonctions :

    * `taille`
    * `hauteur`
    * `est_filiforme`
    * `est_complet`
    * `est_localement_complet`

  Elles prennent toutes un arbre en paramètre et retournent soit un booléen
  (`est_filiforme`, `est_complet`, `est_localement_complet` ) soit la valeur
  en question (`taille`, `hauteur`).

  L'ordre dans lequel elles sont données est à respecter :

  * Vous aurez besoin de la taille et de la hauteur plus tard.
  * _localement complet_ est le plus difficile à programmer.

4. Rédiger une fonction `exemple` qui illustre toutes les propriétés :

    Par exemple :

    ```
    exemple : (1, (2, (4, (), ()), (5, (), ())), (3, (6, (), ()), ()))
    1
    ├── 2
    │   ├── 4
    │   │   ├── ∆
    │   │   └── ∆
    │   └── 5
    │       ├── ∆
    │       └── ∆
    └── 3
        ├── 6
        │   ├── ∆
        │   └── ∆
        └── ∆

    hauteur ?            : 2
    taille               : 6
    complet ?            : False
    localement complet ? : False
    ```

  Faites le pour plusieurs arbres.

  Bien sûr, vous ne calculez pas les réponses à la main mais vous les
  programmez !


### A faire 3. Vérifier vos travaux.

Un jeu de tests est fourni dans le fichier [tests_arbres.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/arbres/3_tp/tests_arbres.py).

Utilisez le pour vérifier vos travaux.

## Conclusion

Dans ce TP nous avons mis en pratique les notions et définitions
vues en cours.

Cela devrait vous aider à programmer une structure plus rigoureuse
pour représenter les arbres : avec des classes.

from string import ascii_lowercase as letters
from random import choice


def est_palindrome_retourne(mot):
    '''
    Vrai ssi un mot est un palindrome
    @param mot: (str)
    @return: (bool)
    '''
    return mot[::-1] == mot


def exemple():
    for mot in ["aba", "abccba", "robert"]:
        print(mot, est_palindrome_retourne(mot))


if __name__ == '__main__':
    exemple()

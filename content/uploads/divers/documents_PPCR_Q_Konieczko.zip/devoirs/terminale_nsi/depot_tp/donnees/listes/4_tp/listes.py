__title__ = "Classe Liste"
__author__ = "qkzk"
__date__ = "2020/04/20"
__doc__ = '''
titre  :   {0}
auteur :   {1}
date   :   {2}

Implémentation d'une classe pour les listes avec ses primitives :

* constructeur (0 éléments ou 2 éléments, le second étant une liste),
* tete : retourne la tête de la liste,
* queue : retourne la queue de la liste,
* est_vide : prédicat testant la vacuité
* __repr__ : pour affichage (console et print)
'''.format(__name__, __author__, __date__)


class ListeError(Exception):
    """
    Exception utilisée par les méthodes

    * ``__init__``
    * ``tete``
    * ``queue``

    de la classe :class:`List`.
    """

    def __init__(self, msg):
        self.message = msg


class Liste:
    def __init__(self, *args):
        '''
        Construit une nouvelle liste.

        Une liste peut être soit :
        * vide,
        * construite à partir d'un élément et d'une liste.

        @param *args: Les arguments. Soit rien, soit un élément et une liste.
        @SE: lève une exception dans les autre cas.
        '''
        if args == ():
            self.contenu = None
        elif len(args) == 2:
            if not isinstance(args[1], Liste):
                raise ListeError("Le second élément doit être un objet Liste")
            self.valeur_tete = args[0]
            self.liste_queue = args[1]
            self.contenu = (self.valeur_tete, self.liste_queue)
        else:
            raise ListeError("Les objets Liste prennent 0 ou 2 paramètres."
                             " {} objets transmis".format(len(args)))

    def est_vide(self):
        '''
        Prédicat : la liste est-elle vide ?
        @return: (bool) Vrai si la liste est vide
        '''
        return self.contenu is None

    def tete(self):
        '''
        Retourne la tête de la liste
        @return: (any) la tête de la liste
        @SE: lève une exception si la liste est vide.
        '''
        if self.est_vide():
            raise ListeError("Une liste vide n'a pas de tête")
        else:
            return self.valeur_tete

    def queue(self):
        '''
        Retourne la queue de la liste
        @return: (Liste) la sous liste de queue
        @SE: lève une exception si la liste est vide.
        '''
        if self.est_vide():
            raise ListeError("Une liste vide n'a pas de queue")
        else:
            return self.liste_queue

    def __repr__(self):
        """
        Returns the dot notation of a list

        >>> l = List(1,(List(2,(List(3,List())))))
        >>> repr(l)
        '(1.(2.(3.())))'
        """
        if self.est_vide():
            return '()'
        else:
            return '('+repr(self.tete())+'.'+repr(self.queue())+')'


################################################################################
#                                                                              #
#                                                                              #
#                       Fin de la classe Liste                                 #
#                                                                              #
#                                                                              #
################################################################################


def afficher_des_exemples():
    '''affiche des exemples dans la console'''
    l1 = Liste()
    print("l1              :", l1)
    print("l1 est vide ?    ", l1.est_vide())
    print()
    l2 = Liste(1, Liste(2, Liste()))
    print("l2              :", l2)
    print("l2 est vide ?    ", l2.est_vide())
    print(l2)
    print("tete            :", l2.tete())
    print("queue           :", l2.queue())


def tester_tout():
    '''teste toutes les méthodes de la classe Liste'''
    # init
    l_1 = Liste()
    l_2 = Liste(1, Liste())
    try:
        Liste(1)
        plante = False
    except ListeError as e:
        plante = True
    assert plante
    try:
        Liste(1, 2)
        plante = False
    except ListeError as e:
        plante = True
    assert plante
    try:
        Liste(1, 2, 3)
        plante = False
    except ListeError as e:
        plante = True
    assert plante

    # est vide
    assert Liste().est_vide()
    assert not Liste(1, Liste()).est_vide()

    # tete
    assert Liste(1, Liste()).tete() == 1
    # queue
    queue = Liste(1, Liste()).queue()
    assert repr(queue) == '()'

    # repr
    l1 = Liste(1, Liste(2, Liste(3, Liste())))
    assert repr(l1) == "(1.(2.(3.())))"


if __name__ == '__main__':
    tester_tout()
    afficher_des_exemples()

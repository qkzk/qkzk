# Tennis

Utilisation d'un terrain de tennis

## Principe

Un club de tennis propose un terrain gratuitement à ses adhérents.

Suite à des abus, quelques règles simples ont été instaurées :

### Règles

1. Chaque adhérent peut utiliser le terrain durant 1h.
2. Si le terrain est libre, un utilisateur peut l'utiliser immédiatement.
3. Si le terrain est déjà utilisé quand un adhérent le demande, on ajoute son nom à une file d'attente.
4. À la fin de l'heure d'utilisation, le prochain adhérent à l'avoir réservé peut l'utiliser.
5. Un adhérent ne peut s'inscrire plus d'une fois dans la file d'attente.
6. Un adhérent qui utilise déjà le terrain ne peut s'inscrire dans la file. Il doit avoir quitté le terrain pour cela.


## Exemple d'une matinée ordinaire

* Le club ouvre à 8h.
* Robert et Amandine arrivent à 8h. Le terrain est libre. Ils s'inscrivent et
    l'utilisent (règle 1 et 2).
* à 8h40, Robert va se réinscrire. Il ne peut pas, c'est refusé (règle 6).
    Qu'est-ce que tu fais Robert ? Lis le règlement stp.
* à 8h42, Robert envoie Amandine pour se réinscrire. REFUSÉ bon sang !
    Elle est déjà en train de jouer.
* à 8h45 Francis arrive avec Jean-Pat. Ils s'inscrivent et attendent 9h. (règle 3)
* à 9h Francis et Jean-Pat commencent un set endiablé. (règle 4).
    Robert va boire un coup. Comment ça pas de Ricard dans un club de tennis ?
* à 9h40 Louise et sa maman Francine arrivent. Elles s'inscrivent et attendent
    au bar (règle 3). Non madame, pas non plus de beaujolais...
* à 9h45 Robert perçoit l'enroule et retourne s'inscrire. Il glisse un billet
    à la réceptionniste pour passer avant Louise. REFUSE (règle 3).
    Le règlement, c'est le règlement Robert...
* 10h ! Francis sert pour le set. Il se fait sortir par la réceptionniste qui
    commence à en avoir marre. Même pas deux heures qu'ils sont ouverts et
    déjà tous les pénibles à l'abordage.

    Louise et Francine commencent leur partie
* 10h32 Francis se réinscrit.
* 11h. Robert reprend sa partie.
* 12h Robert quitte le terrain sans trop se plaindre. Il fait des efforts Robert...
    Francis peut enfin terminer son match avec Jean-Pat.

## Objectif du TP :

### 1. Produire une fonction qui gère les inscriptions dans la console

Elle prend trois paramètres :

1. Le planning actuel
2. Un nom d'utilisateur
3. Un nombre de minutes depuis l'ouverture du club (8h00)

Elle modifie le planning des utilisateurs :

Par exemple, quand Robert s'inscrit à l'ouverture du club (8h00)

```python
>>> planning = [] # pas d'utilisateur inscrits avant l'ouverture
>>> inscrire(planning, 'Robert', 0)
>>> planning
[{'nom': 'Robert', 'de': 0, 'à': 60}]
```

Il tente de se réinscrire à 8h40 :

```python
>>> inscrire(planning, 'Robert', 40)
>>> planning
[{'nom': 'Robert', 'de': 0, 'à': 60}]
```

Il n'obtient pas de nouveau créneau, car il joue encore

8h45 Francis arrive avec Jean-Pat. Ils s'inscrivent et attendent 9h :

```python
>>> inscrire(planning, 'Francis', 45)
>>> planning
[{'nom': 'Robert', 'de': 0, 'à': 60},
 {'nom': 'Francis', 'de': 60, 'à': 120}]
```

etc.

### 2. Produire une fonction qui retourne le nom de l'utilisateur pour une heure donnée

```python
>>> planning
[{'nom': 'Robert', 'de': 0, 'à': 60},
 {'nom': 'Francis', 'de': 60, 'à': 120}]
>>> utilisateur(planning, 65) # qui utilisait à 9h05 ?
'Francis'
>>> utilisateur(planning, 130) # qui utilisera à 10h10
>>> # pas de réponse : personne d'inscrit à cette heure (pour l'instant)
```

## Exemple complet


```python
demandes_dinscription = [
   ('Robert', 0),
   ('Robert', 40),
   ('Robert', 42),
   ('Francis', 45),
   ('Louise', 100),
   ('Robert', 145),
   ('Francis', 152),
]
```

Entre les deux on tente d'inscrire tout le monde avec notre fonction `inscrire`

Et le résultat du planning :

```python
planning_final = [
   {'nom': 'Robert', 'de': 0, 'à': 60},
   {'nom': 'Francis', 'de': 60, 'à': 120},
   {'nom': 'Louise', 'de': 120, 'à': 180},
   {'nom': 'Robert', 'de': 180, 'à': 240},
   {'nom': 'Francis', 'de': 240, 'à': 300},
]
```

Notez que Robert s'est fait recaler deux fois et que sa dernière réservation a
bien lieu à l'horaire voulu.

## File

Le planning tel qu'on l'a présenté est **une file**.

Il est représenté en mémoire par une liste Python.

Nous n'allons pas recréer toute la structure des files dans ce TP,
seulement nous contenter des méthodes sur les listes dont on a besoin.

## Matériel fourni

Vous disposez de deux fichiers :

[tennis_eleve.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/files/tennis/tennis_eleve.py) et [tests_tennis.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/files/tennis/tests_tennis.py)

Le second module comprend une suite de fonctions tests qui permettent de valider
les étapes.

Si vous l'exécutez maintenant il plante.

Vous pouvez exécuter chaque fonction indépendamment et vérifier que vous avez
franchi une étape.

Chaque étape est validée par un `print` tel que :

**`A faire 4: ok`**


A la fin, il doit se compléter sans erreur et afficher :


**`tests validés, TP terminé !`**

## La fonction `utilisateur`

C'est la plus simple, commençons par celle-la

voici ce qu'elle doit faire :

```python
>>> planning
[{'nom': 'Robert', 'de': 0, 'à': 60},
 {'nom': 'Francis', 'de': 60, 'à': 120}]
>>> utilisateur(planning, 65) # qui utilisait à 9h05 ?
'Francis'
>>> utilisateur(planning, 130) # qui utilisera à 10h10
>>> # pas de réponse : personne d'inscrit à cette heure (pour l'instant)
```

### A faire 1.

Proposer un algorithme qui trouve l'utilisateur pour une heure donnée.
On suppose que le planning fourni respecte les contraintes du club.

---

### A faire 2.

1. Programmer cette fonction

---

## La fonction `inscrire`

Nous allons la découper en étapes en fonction des règles :

Règle 6:

> 6. Un adhérent qui utilise déjà le terrain ne peut s'inscrire dans la file. Il doit l'avoir quittée pour cela.


### A faire 3.

Quelle fonction pourrait-on utiliser pour savoir si un utilisateur est déjà en
train d'utiliser le terrain quand il s'inscrit ?

1. Programmer cette étape.


---


### A faire 4

Le terrain est-il libre ?

Règle 2:

>  2. Si le terrain est libre, un utilisateur peut l'utiliser immédiatement.

La règle 2. nécessite de savoir si le terrain est libre à une certaine heure

1. Comment savoir si le terrain est libre à une heure donnée ?

2. Programmer une fonction `libre` qui prend le planning et un horaire en
    paramètre et retourne `True` si le terrain est libre à cet instant.

    ```python
    >>> planning = [{'nom': 'Robert', 'de': 0, 'à': 60}]
    >>> libre(planning, 45)
    False
    >>> libre(planning, 62)
    True
    ```

---

### A faire 5

L'utilisateur est-il déjà inscrit dans la file quand il tente de s'inscrire ?

Règle 5:

> 5. Un adhérent ne peut s'inscrire plus d'une fois dans la file.

Afin de limiter les abus (Robert s'inscrirait à la journée et viendrait avec
ses provisions si on le laissait faire !) on limite les inscriptions
par personne.

1. À un horaire donné, comment savoir si un utilisateur est déjà inscrit
    pour une _prochaine_ utilisation ?

    Par exemple avec :

    ```python
    planning = [
      {'nom': 'Robert', 'de': 0, 'à': 60},
      {'nom': 'Francis', 'de': 60, 'à': 120},
    ]
    ```

    * Francis ne peut pas se réinscrire à l'horaire 45. Il est déjà inscrit.
    * Francis peut se réinscrire à l'horaire 140. Il n'est pas déjà inscrit.

2. Programmer cette fonction.

    On pourra utiliser les tests suivants :

    ```python
    # déjà inscrit
    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
    ]
    assert deja_inscrit(planning, 45, 'Francis')
    assert not deja_inscrit(planning, 140, 'Francis')
    ```

---

### A faire 6 : formater une inscription

Supposons qu'on reçoive une demande d'inscription valide, il faut ajouter
les informations nécessaires au planning.

1. Créer une fonction `formater_inscription` qui prend comme paramètre `nom`
    et `horaire` et qui retourne un dictionnaire avec cette inscription.

    ```python
    >>> formater_inscription('Robert', 30)
    {'nom': 'Robert', 'de': 30, 'à': 90}
    ```

2. Tester votre fonction

---

### A faire 7 : si le terrain est libre...

Règle 1 et 2:

> 1. Chaque adhérent peut utiliser le terrain durant 1h.
> 2. Si le terrain est libre, un utilisateur peut l'utiliser immédiatement.


1. Programmer cette contrainte dans votre fonction `inscrire`

2. Utiliser le jeu de test suivant :

    ```python
    # a faire 7 : règle 1 et 2
    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
    ]

    # on inscrit quelqu'un quand le terrain est libre
    inscrire(planning, 'Louise', 130)

    assert planning == [{'nom': 'Robert', 'de': 0, 'à': 60},
                        {'nom': 'Francis', 'de': 60, 'à': 120},
                        {'nom': 'Louise', 'de': 130, 'à': 190}]
    ```

### A faire 8


Règles 1 et 3:

> 1. Chaque adhérent peut utiliser le terrain durant 1h.
> 3. Si le terrain est déjà utilisé quand un adhérent le demande, on ajoute son nom à la fin.

Supposons qu'un terrain soit indisponible quand quelqu'un arrive. Nous ajoutons
son nom au premier horaire disponible.

1. Écrire une fonction `duree_attente` qui prend un planning et un horaire
    et qui retourne la durée d'attente avant de pouvoir l'utiliser.
    Si le planning est vide elle retourne 0 (on n'attend pas !)

    ```python
    planning = [
          {'nom': 'Robert', 'de': 0, 'à': 60},
          {'nom': 'Francis', 'de': 60, 'à': 120},
      ]
    ```

    On obtient :

    ```python
    >>> duree_attente(planning, 110)
    10
    >>> duree_attente(planning, 130)
    0
    >>> duree_attente([], 100)
    0
    ```



2. Ajouter cette règle à votre fonction principale `inscrire`

    N'oublions pas qu'on doit vérifier que l'utilisateur n'est pas déjà inscrit !

3. Tester avec le jeu suivant :


    ```python
    planning = [
          {'nom': 'Robert', 'de': 0, 'à': 60},
          {'nom': 'Francis', 'de': 60, 'à': 120},
      ]

    inscrire(planning, 'Louise', 110)
    assert planning == [{'nom': 'Robert', 'de': 0, 'à': 60},
                        {'nom': 'Francis', 'de': 60, 'à': 120},
                        {'nom': 'Louise', 'de': 120, 'à': 180}]
    ```


### A faire 9

Votre planning d'inscription est terminé.

Il doit passer le test 9 (tout en même temps). Vérifiez.


## Conclusion

Nous avons programmé, étape par étape, toutes les règles.

Les règles étaient simples (si si) et permettaient d'écrire des tests AVANT
de programmer les fonctions.

C'est un principe fondamental et c'est ainsi que j'ai écrit le sujet.

Ce mode de développement s'appelle TDD pour ([Test Driven Developement](https://fr.wikipedia.org/wiki/Test_driven_development))
est très utilisé dans l'ingénierie informatique.

Il permet de s'assurer de remplir les contraintes au fur et à mesure sans écrire
trop de code inutile.

* Ma fonction `inscrire` fait 9 lignes seulement.
* Elle appelle 5 fonctions seulement, chacune faisant 4 lignes ou moins...


`5 * 4 + 9 = 29` : Bout à bout le tp est faisable en 30 lignes.

J'en aurais sûrement écrit le triple si j'avais envisagé une autre approche.


---

Ainsi que nous l'avons déjà dit, le planning d'inscription est une file
d'attente.

Elle est particulière, nous ne cherchons pas à la vider régulièrement !

Pour implémenter cela, il faudrait réellement que **le temps défile.**

Cela ne demanderait pas énormément d'effort de créer une page web
et une base de données pour enregistrer les inscrits et afficher
sur un écran le nom du prochain appelé.

Parmi toutes les sources intéressantes en informatique, on trouve beaucoup
de tutoriels vous proposant "d'automatiser avec Python".

Voilà une mise en oeuvre pratique et faisable :

Passer d'un système d'inscriptions rudimentaire et fastidieux à quelque chose
d'un peu automatisé.

---

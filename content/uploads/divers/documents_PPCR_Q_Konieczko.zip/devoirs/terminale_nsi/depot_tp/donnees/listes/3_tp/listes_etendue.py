from listes import *


class ListeEtendue(Liste):
    '''
    Extension de la classe liste afin de la rendre mutable
    '''

    def __nlle_tete(self, valeur):
        '''
        Ajoute une tête à une liste vide
        '''
        if not self.est_vide():
            raise ListeError("Vous ne pouvez modifier qu'une liste vide")
        self.valeur_tete = valeur

    def __nlle_queue(self, liste):
        '''
        Ajoute une queue à une liste vide
        '''
        if not self.est_vide():
            raise ListeError("Vous ne pouvez modifier qu'une liste vide")
        assert isinstance(liste, ListeEtendue)
        self.liste_queue = liste

    def ajouter(self, valeur):
        '''
        Aujoute une valeur à la fin de la liste
        @param valeur: (any)
        @return: None

        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.ajouter(4)
        >>> liste
        (0.(1.(2.(3.(4.())))))
        '''
        pass

    def longueur(self):
        '''
        Retourne la longueur de la liste.
        @return: (int)
        >>> LE = ListeEtendue
        >>> LE().longueur()
        0
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.longueur()
        4
        '''
        pass

    def get(self, position):
        '''
        Retourne l'élément d'indice donné dans la liste
        @param position: (int)
        @SE: lève une exception Liste.ListeError si la liste
             n'est pas assez grande.
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.get(2)
        2
        '''
        pass

    def contient(self, valeur):
        '''
        Vrai ssi valeur est dans la liste
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.contient(0)
        True
        >>> liste.contient(1)
        True
        >>> liste.contient(4)
        False
        '''
        pass

    def vers_liste_python(self):
        '''
        Retourne un objet Python List avec les mêmes éléments
        @return: List
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.vers_liste_python()
        [0, 1, 2, 3]
        >>> LE().vers_liste_python()
        []
        '''
        pass

    def retourner(self):
        '''
        Retourne la liste.

        @return: (ListeEtendue)
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> retournee = liste.retourner()
        >>> retournee
        (3.(2.(1.(0.()))))
        '''
        pass

    def effacer(self, position):
        '''Efface l'élément à la position donnée'''
        pass


def exemple():

    LE = ListeEtendue
    liste = LE(0, LE(1, LE(2, LE(3, LE()))))

    print(liste.longueur())

    print(liste)
    liste.ajouter(4)
    print(liste)

    print(liste.get(2))

    print(liste.contient(0))
    print(liste.contient(1))
    print(liste.contient(4))
    print(liste.contient(5))

    print(liste.vers_liste_python())

    print(liste.retourner())


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    exemple()

from random import uniform, random


class File:
	def __init__(self):
		pass

	def enfiler(self, valeur):
		pass

	def defiler(self):
		pass

	def est_vide(self):
		pass

DUREE_OUVERTURE = 8 * 60 * 60               # 8 heures
PATIENCE_MIN = 120
PATIENCE_MAX = 1800
TRAITEMENT_MIN = 30
TRAITEMENT_MAX = 300

class Client:
	def __init__(self):
		pass

	def arrivee(self):
		pass

	def patience(self):
		pass

	def depart(self):
		pass
	
	def duree_traitement(self):
		pass

def arrivee_client(proba):
	pass

def simuler_guichet(proba):
	pass

def simuler_fct_proba(finesse):
	pass

def main():
	pass

if __name__=='__main__':
	main()

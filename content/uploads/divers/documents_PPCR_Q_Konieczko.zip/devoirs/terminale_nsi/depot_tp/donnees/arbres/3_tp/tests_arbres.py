#!/usr/bin/python3
# -*- coding: utf-8 -*-

__author__ = 'qkzk'
__date_creation__ = '2020/04/23'
__doc__ = """
:mod:`tests_arbres` module
:author: {:s}
:creation date: {:s}
:last revision:

Réalise tous les tests des deux fichiers présents.
Lève une AssertionError si l'une des fonctions échoue.

Affiche un message dans la console pour chaque fonction qui réussit.
""".format(__author__, __date_creation__)

from arbres import *

# décommentez la ligne suivante pour importer le module que vous avez crée
# from utiliser import *


def tester_tlm():
    arbre_exemple_1 = (1, VIDE, VIDE,)
    arbre_exemple_2 = (1, (2, VIDE, VIDE,), (3, VIDE, VIDE,),)
    arbre_exemple_3 = (1,
                       (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
                       (3, (6, VIDE, VIDE,), (7, VIDE, VIDE,)),)

    liste_exemples = [VIDE,
                      arbre_exemple_1,
                      arbre_exemple_2,
                      arbre_exemple_3]

    liste_presentations = [

        "()",
        "(1, (), ())",
        "(1, (2, (), ()), (3, (), ()))",
        "(1, (2, (4, (), ()), (5, (), ())), (3, (6, (), ()), (7, (), ())))",
    ]

    # est vide
    assert est_vide(VIDE)
    assert not est_vide(arbre_exemple_1)

    # contenu
    try:
        contenu(VIDE)
        plante = False
    except TypeError as e:
        plante = True
    assert plante
    assert contenu(arbre_exemple_1) == 1

    # gauche
    try:
        gauche(VIDE)
        plante = False
    except TypeError as e:
        plante = True
    assert plante
    assert gauche(arbre_exemple_1) == VIDE

    # droit
    try:
        droit(VIDE)
        plante = False
    except TypeError as e:
        plante = True
    assert plante
    assert droit(arbre_exemple_1) == VIDE

    # presenter
    for arbre, presentation in zip(liste_exemples,
                                   liste_presentations):
        assert presenter(arbre) == presentation

    # dessin
    arbre_exemple_3 = (1,
                       (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
                       (3, (6, VIDE, VIDE,), (7, VIDE, VIDE,)),)
    figure = '''1
├── 2
│   ├── 4
│   │   ├── ∆
│   │   └── ∆
│   └── 5
│       ├── ∆
│       └── ∆
└── 3
    ├── 6
    │   ├── ∆
    │   └── ∆
    └── 7
        ├── ∆
        └── ∆
'''
    assert dessin(arbre_exemple_3) == figure

    incomplet_1 = (1,
                   (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
                   (3, (6, VIDE, VIDE,), VIDE,),)
    figure = '''1
├── 2
│   ├── 4
│   │   ├── ∆
│   │   └── ∆
│   └── 5
│       ├── ∆
│       └── ∆
└── 3
    ├── 6
    │   ├── ∆
    │   └── ∆
    └── ∆
'''

    assert figure == dessin(incomplet_1)

    incomplet_2 = (1,
                   (2, (4, VIDE, VIDE,), VIDE),
                   (3, (5, VIDE, (6, VIDE, VIDE,),), VIDE,),)
    figure = '''1
├── 2
│   ├── 4
│   │   ├── ∆
│   │   └── ∆
│   └── ∆
└── 3
    ├── 5
    │   ├── ∆
    │   └── 6
    │       ├── ∆
    │       └── ∆
    └── ∆
'''
    assert figure == dessin(incomplet_2)
    print("Tests pour module principal : ok")


def tester_algorithmes():
    arbre_exemple_1 = (1, VIDE, VIDE,)
    arbre_exemple_2 = (1, (2, VIDE, VIDE,), (3, VIDE, VIDE,),)
    arbre_exemple_3 = (1,
                       (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
                       (3, (6, VIDE, VIDE,), (7, VIDE, VIDE,)),)
    filiforme_1 = (1, (2, VIDE, VIDE,), VIDE,)
    filiforme_2 = (1, (2, (3, VIDE, VIDE,), VIDE,), VIDE,)

    incomplet_1 = (1,
                   (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
                   (3, (6, VIDE, VIDE,), VIDE,),)

    # taille
    assert taille(VIDE) == 0
    assert taille(arbre_exemple_1) == 1
    assert taille(arbre_exemple_2) == 3
    assert taille(arbre_exemple_3) == 7

    # hauteur
    assert hauteur(VIDE) == -1
    assert hauteur(arbre_exemple_1) == 0
    assert hauteur(arbre_exemple_2) == 1
    assert hauteur(arbre_exemple_3) == 2

    # filiforme
    assert not est_filiforme(VIDE)
    assert est_filiforme(arbre_exemple_1)
    assert not est_filiforme(arbre_exemple_2)
    assert est_filiforme(filiforme_1)
    assert est_filiforme(filiforme_2)

    # complet
    assert not est_complet(VIDE)
    assert est_complet(arbre_exemple_1)
    assert est_complet(arbre_exemple_2)
    assert est_complet(arbre_exemple_3)
    assert not est_complet(filiforme_1)
    assert not est_complet(filiforme_2)

    # localement complet
    # assert not est_localement_complet(VIDE) # sans quoi trop pénible à écrire
    assert est_localement_complet(arbre_exemple_1)
    assert est_localement_complet(arbre_exemple_2)
    assert est_localement_complet(arbre_exemple_3)
    assert not est_localement_complet(filiforme_1)
    assert not est_localement_complet(filiforme_2)
    assert not est_localement_complet(incomplet_1)

    print("Tests les algorithmes : ok")


if __name__ == '__main__':
    tester_tlm()

    # décommentez la ligne suivante pour tester votre module
    # tester_algorithmes()

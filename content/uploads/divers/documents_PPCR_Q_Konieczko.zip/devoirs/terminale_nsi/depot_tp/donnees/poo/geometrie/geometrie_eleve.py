__name__ = "Objets géométriques"
__author__ = "qkzk"
__date__ = "2020/04/21"
__doc__ = f"""
titre:   {__name__}
auteur:  {__author__}
date:    {__date__}

ATTENTION !!! On suppose que l'axe des ordonnées est orienté vers le bas,
comme toujours en informatique.

Implémentation de quelques objets géométriques du plan respectant le programme
de NSI terminale. On respecte la géométrie euclidienne.
Toutes les distances sont calculées de manière approchée.

Respecte strictement le programme.

On implémente :

* les disques,
* les rectangles (parallèles aux axes),
* les vecteurs

Toutes les méthodes sont testées à la fin.
"""

from math import pi


class Disque:
    '''Classe des disques. Ils sont instanciés par centre et rayon'''

    def __init__(self, x, y, r):
        '''
        Constructeur. Crée un objet Disque
        Instancité par centre et rayon
        @param x, y, r: (number)
        '''
        self.__centre = (x, y)
        self.__rayon = r

    def centre(self):
        '''
        Retourne le centre.
        @return : (tuple)
        '''
        return self.__centre

    def rayon(self):
        '''
        Retourne le rayon
        @return: (number)
        '''
        return self.__rayon

    def circonference(self):
        '''
        Retourne la circonférence
        @return: (float)
        '''
        return 2 * pi * self.rayon()

    def aire(self):
        '''
        Retourne l'aire
        @return: (float)
        '''
        return pi * self.rayon() ** 2

    def __repr__(self):
        '''
        Permet l'affichage dans la console et les print(Disque(...))
        @return: (str)
        '''
        return "Disque de centre {} et de rayon {}".format(self.__centre,
                                                           self.__rayon)

    def changer_centre(self, x, y):
        '''
        Règle un nouveau centre
        @param x, y: (number)
        '''
        pass

    def changer_rayon(self, r):
        '''
        Règle un nouveau rayon
        @param r: (number)
        '''
        pass

    def contient(self, xm, ym):
        '''
        Prédicat testant si un point est contenu dans le disque
        @param xm, ym: (number)
        @return: (bool)
        '''
        xc, yc = self.centre()
        return distance(xc, yc, xm, ym) < self.rayon()

    def intersecte(self, autre_disque):
        '''
        Prédicat testant si deux disques s'intersectent
        @param autre_disque: (Disque)
        @return: (bool)
        '''
        pass


class Rectangle:
    '''
    Classe des rectangles. Ils sont instanciés par les coordonnées du coin
    supérieur gauche, la largeur et la hauteur.
    Ils sont tous parallèles aux axes de coordonnées
    '''

    def __init__(self, x, y, l, h):
        '''
        Constructeur
        (x, y) : coordonnées du coin supérieur gauche,
        l : largeur
        h : hauteur
        @param x, y, l, h: (number)
        '''
        pass

    def x(self):
        '''
        Retourne l'abscisse du coin supérieur gauche.
        Attention y orienté vers le bas
        @return: (number)
        '''
        pass

    def y(self):
        '''
        Retourne l'ordonnée du coin supérieur gauche.
        Attention y orienté vers le bas
        @return: (number)
        '''
        pass

    def largeur(self):
        '''
        Retourne la largeur
        @return: (number)
        '''
        pass

    def hauteur(self):
        '''
        Retourne la hauteur
        @return: (number)
        '''
        pass

    def __repr__(self):
        '''
        Permet l'affichage dans la console et les print
        @return: (str)
        '''
        pass

    def perimetre(self):
        '''
        Retourne le périmètre
        @return: (number)
        '''
        pass

    def aire(self):
        '''
        Retourne l'aire
        @return: (number)
        '''
        pass

    def contient(self, xa, ya):
        '''
        Prédicat testant si un point A(xa, ya) est dans le rectangle
        @param xa, ya: (number) coordonnées du point
        @return: (bool) True ssi A in Rect
        '''
        pass

    def collision(self, rectangle):
        '''
        Prédicat testant si deux rectangles sont en collision
        R1 (self) intersecte R2 (l'autre) si et seulement si un des coins de
        l'un est dans l'autre
        @param retangle: (Rectangle) un rectangle R2
        @return: (bool) True ssi R1 intersecte R2
        '''
        # On affecte les coordonnées des 4 coins de l'autre rectangle
        xa, ya = rectangle.x(), rectangle.y()
        xb, yb = xa + rectangle.largeur(), ya
        ...  # à compléter

        # les rectangles sont en collision si un des coins du second
        # est DANS le premier.
        pass


def distance(xa, ya, xb, yb):
    '''
    Retourne la distance euclidienne AB où A(xa, ya) et B(xb, yb)
    @param xa, ya, xb, yb: (number) les coordonnées de A et B
    @return: (float)
    '''
    return ((xb - xa) ** 2 + (yb - ya) ** 2) ** 0.5

---
title: NSI Terminale - Structure de données
subtitle: 'TD: Vitesse des algorithmes et méthodes magiques'
date: 2020/05/15
author: qkzk
theme: metropolis
geometry: margin=1.5cm
---

# Travaux pratiques - Deuxième partie

## Méthodes magiques

Nous allons aussi ajouter quelques _méthodes magiques_ qui permettent
d'utiliser nos listes comme des objets `List` Python.

Ajouter à la fin de votre classe les méthodes suivantes :

```python

    def __delitem__(self, position):
        return self.effacer(position)

    def __getitem__(self, position):
        return self.get(position)

    def __len__(self):
        return self.longueur()

    def __next__(self):
        try:
            valeur = self.__iter.tete()
            self.__iter = self.__iter.queue()
            return valeur
        except:
            raise StopIteration

    def __iter__(self):
        self.__iter = self
        return self

    def __add__(self, autre_liste):
        if not isinstance(autre_liste, ListeEtendue):
            raise ListeError("Les deux éléments doivent être des listes")

        a = self
        somme = ListeEtendue()
        while not a.est_vide():
            somme.ajouter(a.tete())
            a = a.queue()
        b = autre_liste
        while not b.est_vide():
            somme.ajouter(b.tete())
            b = b.queue()
        return somme

    @classmethod
    def depuis_liste_python(cls, tableau):
        liste = cls()
        for x in tableau:
            liste.ajouter(x)
        return liste

```


Faites bien attention à l'indentation, elles doivent être _dans la classe_.

Étudiez soigneusement le code, en particulier la dernière méthode `depuis_liste_python`.

**Question** : à quel objet fait référence le paramètre `cls` ? Consultez
l'exemple ci-dessous si ça n'est pas clair pour vous.

Par quel nom d'objet pourrait-on le remplacer dans `liste = cls()` ?

**Question** : à quels opérateurs Python correspondent ces méthodes ?
Ajouter la documentation de chaque méthode.

---

Vous pouvez maintenant utiliser :

```python
>>> l = ListeEtendue.depuis_liste_python([0, 1, 2, 3])
(0.(1.(2.(3.()))))

>>> del l[0]
>>> l
(1.(2.(3.())))

>>> somme = 0
>>> for x in l:
...    somme += x
>>> somme
6

>>> sum(l)
6

>>> l + l
(1.(2.(3.(1.(2.(3.()))))))
```
---

## Comparaison des vitesses d'exécution

Dans cette partie du TP, nous allons comparer l'efficacité de nos listes
par rapport à celles déjà présentes dans Python.

Le module `pylab` permet de réaliser facilement des figures.

```python
import pylab
```

S'il n'est pas installé sur votre poste, on peut toujours utiliser `matplotlib` :

```python
import matplotlib.pyplot as pylab
```

### Réaliser une figure simple :

```python
pylab.plot([1, 2, 3], [1, 4, 9])
```

Le premier parametre est l'abscisse
Le second l'ordonnée

Ainsi on trace les points (1, 1), (2, 4) et (3, 9)
Par défaut, les points sont reliés.

On peut ajouter des informations : légende, titre, unités avec :

```python
pylab.legend(["carre"])
pylab.title(["fonction carré"])
pylab.xlabel('axe des x')
pylab.ylabel('axe des y')
```

Enfin, pour dessiner :

```python
pylab.show()
```

Le fait de dessiner vide le contenu du dessin.

Vous pouvez tracer plusieurs courbes à la fois, il suffit de faire plusieurs
appels à `pylab.plot( ... )`

Pensez alors à donner assez d'éléments à votre légende.

[Tutoriel pylab](https://jakevdp.github.io/mpl_tutorial/tutorial_pages/tut1.html)


### Mesurer le temps

```python
from time import time
debut = time() # lance le chrono
calcul = sum(range(1000))
fin = time() # arrête le chrono
fin - debut # contient la durée en seconde : 0.0010814666748046875
```

### A faire

**Dessiner une comparaison des durées d'exécutions pour les critères suivants :**

* créer une liste (les notres, celles de python) en ajoutant des entiers à la fin.
* faire la somme des termes d'une liste

On utilisera des tailles entre 100 et 5000.

Attention, en python la pile de récursion est limitée à 500 niveaux de
profondeur. Il convient donc de l'augmenter le temps du TP avec :

```python
sys.setrecursionlimit(20000)
```

Des exemples de figures sont disponibles dans le dossier [img](img)

![somme](img/somme.png)

### Conclusion

* La complexité pour la somme est linéaire, c'est le cas de toute les itérations
  sur une liste déjà crée.
* la création (et l'insertion) sont linéaires pour les listes Python mais pas
  pour les notres. La pile de récursion devient trop importante et les opérations
  sont de plus en plus lourdes.

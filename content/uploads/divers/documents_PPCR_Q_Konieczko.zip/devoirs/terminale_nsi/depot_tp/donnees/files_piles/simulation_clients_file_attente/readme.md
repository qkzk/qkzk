---
title: "NSI - Terminale"
subtitle: "Structure de données - File - Simulation"
author: "qkzk"
date: "2020/10/24"
theme: metropolis
geometry: margin=1.5cm

---

Utiliser une file informatique est donc naturel lorsque l’on modélise une file
d’attente au sens courant du terme. Considérons un exemple simple :

* Un unique guichet ouvert 8h00 consécutives (soit 8 × 60 × 60 secondes).

* Les clients arrivent et font la queue. La probabilité d’arrivée d’un nouveau
    client dans l’intervalle [t…t+1[ est p.

* Le temps que prend le service d’un client suit une loi uniforme sur [30…300[.

* Les clients, s’il attendent trop longtemps, partent sans être servis.
    Leur patience est une loi uniforme sur [120…1800[

Notre objectif est d’écrire une simulation informatique afin d’estimer le
rapport clients repartis sans être servis sur nombre total de clients, en
fonction de la probabilité p.

[Source: inria](http://gallium.inria.fr/~maranget/X/421/poly/piles.html)


# Étapes

1. Implémenter une classe pour les files. On utilisera une des méthodes
    vues précédemment. Toutes conviennent.
2. On défini les constantes suivantes :

    ```python
    DUREE_OUVERTURE = 8 * 60 * 60               # 8 heures
    PATIENCE_MIN = 120
    PATIENCE_MAX = 1800
    TRAITEMENT_MIN = 30
    TRAITEMENT_MAX = 300
    ```
3. définir une fonction `arrivee_client` qui prend un paramètre flottant `proba`
    et renvoie vrai si un réel aléatoire suivant une loi uniforme (obtenu avec `random()`)
    est entre 0 et `proba`.

    Penser à importer : `from random import random`

    Cette fonction renvoie donc vrai si un client arrive, ce qui est un phénomène
    aléatoire ayant un probabilité "`proba`".

4. La classe du `Client`. Elle contient les méthodes :

    * `__init__` : un paramètre entier : `arrivee`
    * `arrivee` : accesseur de l'heure d'arrivée,
    * `depart`  : accesseur de l'horaire maximal de départ.
    * `__patience` : méthode interne mesuran la patience maximale et aléatoire.

       Utilisée pour inialiser l'attribut `__depart`
    * `duree_traitement` : renvoie un nombre aléatoire suivant une loi uniforme
        entre les constantes `TRAITEMENT_MIN` et `TRAITEMENT_MAX`.

     Penser à importer : 

     ```python
     from random import uniform
     uniform(5, 10)     # réel aléatoire entre 5 et 10 réparti uniformément
     ```

5. La fonction `simuler_guichet`.

    Voici l'algorithme :

    ```
    f une file
    nb_clients, nb_deçus, t_libre : entiers inialisés à 0

    pour chaque seconde s entre 0 et la durée d'ouverture 
        si un client arrive:
            nb_clients augmente de 1
            on crée un objet Client avec son temps d'arrivée
            on l'enfile dans f
        si t_libre <= s         # le guichet est libre
            tant que la file n'est pas vide :
                on défile un client c
                si le temps de départ du client est supérieur à s
                    on augmente t_libre du temps nécessaire au traitement de ce client
                    on arrête la boucle
                sinon
                    on incrémente le nombre de déçus
                fin du si
            fin du tant que
    fin du pour
    renvoyer le taux de client déçus
    ```

    Vous savez ce qu'il vous reste à faire.

    1. Faire tourner l'algorithme à la main avec 3 clients "aléatoires"
    2. Implémenter

6. Faire queqlues essais en faisant varier la proba d'arrivée d'un client entre
    0 et 1.

    * À partir de quelle probabilité a-t-on environ 50% de déçus ?
    * Dans ce cas, combien le guichet voit-il arriver de client en une heure en
        moyenne ?

7. Construire une figure similaire à l'image jointe avec `matplotlib`.



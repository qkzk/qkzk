---
title: "NSI - Terminale"
subtitle: "Structure de données Pile : Notation polonaise inverse"
author: "qkzk"
date: "2020/10/24"
theme: metropolis
geometry: margin=1.5cm

---

# Utilisation d'une pile : la notation polonaise inverse

Nous allons prendre en compte la nature très informatique de la pile et
proposer un exemple plutôt informatique. Les calculatrices d'une célèbre marque
états-unienne ont popularisé une notation des calculs dite parfois « polonaise
inverse » ou plus généralement postfixe. Les calculs se font à l'aide d'une
pile, les nombres sont simplement empilés, et l'exécution d'une opération `op`
revient à d'abord dépiler un premier opérateur `e1`, puis un second `e2`, et enfin
à empiler le résultat `e2 op e1`. Par exemple, la figure donne les étapes
successives du calcul `6 3 2 - 1 + / 9 6 - *` exprimé en notation postfixe.

![Calcul de l'expression postfixe `6 3 2 - 1 + / 9 6 - *`](http://gallium.inria.fr/~maranget/X/421/poly/poly028.png)

Le fabricant états-unien de calculatrices affirme qu'avec un peu d'habitude la
notation postfixe est plus commode que la notation usuelle (dite infixe). C'est
peut-être vrai, mais on peut en tout cas être sûr que l'interprétation de la
notation postfixe par une machine est bien plus facile à réaliser que celle de
la notation infixe. 

# Implémentation - à faire

Écrire un programme `rpn.py` qui réalise le calcul donné sur la ligne de
commande.

On utilisera une classe pour la pile.

Voici un exemple d'utilisation :

```bash
$ python rpn.py "6 3 2 - 1 + / 9 6 - *"
6 -> 6.0
3 -> 3.0, 6.0
2 -> 2.0, 3.0
- -> 1.0, 6.0
1 -> 1.0, 1.0
+ -> 2.0, 6.0
/ -> 3.0
9 -> 9.0, 3.0
6 -> 6.0, 9.0
- -> 3.0, 3.0
* -> 9.0
9.0
```

Le résultat est renvoyé à la dernière ligne et les lignes intermédiaires
sont des affichages internes de la valeur lue et de l'état de pile à cette
étape.

## Comment lire les arguments saisis dans la console ?

Afin de lire une saisie en ligne de commande Python, comme le langage C,
propose un attribut de la librairie `sys` : `sys.argv`.

C'est une liste qui contient _toujours_ en premier paramètre le nom du module.

Donc :

* `sys.arvg[0]` est toujours le nom du fichier,
* `sys.argv` n'est jamais vide.



Il s'utilise comme cela :

```python
import sys

print(sys.argv)                             # affiche tous les arguments

if len(sys.argv) > 1:                       # l'utilisateur a tapé un argument
    expression = sys.argv[1]                # expression : le premier argument
    token = expression.strip().split()      # découpe l'expression en une liste
    print(token)
```

Voici ce qu'on obtient en exécutant le fichier [arguments.py](./arguments.py)

```bash
$ python arguments.py "bonjour la nsi"
['arguments.py', 'bonjour la nsi']
['bonjour', 'la', 'nsi']
```


# Remarque

La facilité d'interprétation de l'expression postfixe provient de ce que sa
définition est très opérationnelle, elle dit exactement quoi faire. Dans le cas
de la notation infixe, il faut régler le problème des priorités des opérateurs.
Par exemple si on veut effectuer le calcul infixe `1 + 2 * 3` il faut procéder à
la multiplication d'abord (seconde opération), puis à l'addition (première
opération) ; tandis que pour calculer `1 * 2 + 3`, on effectue d'abord la
première opération (multiplication) puis la seconde (addition).

Par contraste,
la notation postfixe oblige l'utilisateur de la calculatrice à donner l'ordre
désiré des opérations (comme par exemple `1 2 3 * + et 1 2 * 3 +`) et donc
simplifie d'autant le travail de la calculatrice. Dans le même ordre d'idée, la
notation postfixe rend les parenthèses inutiles (ou empêche de les utiliser
selon le point de vue).

# Notation infixe : à faire

Écrire un programme `infixe.py` qui lit une expression sous forme postfixe et affiche
l'expression infixe (complètement parenthésée) qui correspond au calcul
effectué par le programme `rpn.py`. On utilisera là encore une classe pour la
pile.

Voici un exemple d'utilisation :

```bash
% python infixe.py "6 3 2 - 1 + / 9 6 - *" infixe
6 -> '6'
3 -> '3', '6'
2 -> '2', '3'
- -> '(3-2)', '6'
1 -> '1', '(3-2)'
+ -> '((3-2)+1)', '6'
/ -> '(6/((3-2)+1))'
9 -> '9', '(6/((3-2)+1))'
6 -> '6', '9'
- -> '(9-6)', '(6/((3-2)+1))'
* -> '((6/((3-2)+1))*(9-6))'
((6/((3-2)+1))*(9-6))
```

# Remarque finale

Nous verrons plus tard que se passer des parenthèses inutiles ne se fait
simplement qu'à l'aide d'une nouvelle notion.




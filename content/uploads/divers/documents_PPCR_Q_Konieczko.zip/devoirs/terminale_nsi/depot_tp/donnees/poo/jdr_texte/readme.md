---
title: NSI Terminale - Données
subtitle : Projet d'introduction à la POO
author: qkzk
date: 2019/12/25
theme: metropolis
papersize: a4
header-includes:
    - \usepackage[margin=2cm]{geometry}
---

# Projet liaison première terminale : jeu de rôle en mode texte

# Principe

Faire se battre deux adversaires dans la console.

Ce projet est le point de départ de n'importe quel jeu en tour par tour.

On peut le réaliser avec ou sans POO. Mais c'est _nettement_ plus facile avec
de la POO.

Alors les données sont faciles à comprendre et à manipuler.

## Objectif

Partir d'un jeu de combat programmé en impératif (sans POO) et l'adapter
à la POO.

Pour cela examinons déjà ce qui se passe dans le projet initial "version
première"



## Première : version impérative sans POO


~~~python
>>> robert = joueur('Robert', 10, 2)
>>> amandine = joueur('Amandine', 10, 2)
>>> vainqueur = combat(robert, amandine)

Bagarre entre Robert et Amandine !
Robert tape Amandine et fait 1 points de dégâts.
...
Amandine tape Robert et rate.
Robert tape Amandine et fait 2 points de dégâts.
Robert a gagné !
Amandine est mort
>>> dagobert = joueur('Dagobert', 5, 2)
>>> combat(vainqueur, dagobert)

Bagarre entre Robert et Dagobert !
Robert tape Dagobert et fait 2 points de dégâts.
Dagobert tape Robert et rate.
Robert tape Dagobert et fait 2 points de dégâts.
Dagobert tape Robert et fait 2 points de dégâts.
Dagobert a gagné !
Robert est mort
~~~

Dans cette version le type renvoyé par `joueur` est un `dict`


```python
>>> robert
{'nom': 'Robert', 'vie': -1, 'force': 2}
```

On accède aux caractéristiques de Robert à l'aide des clés :

```python
>>> robert["vie"]
-1
>>> robert["nom"]
'Robert'
>>>
```

C'est pratique... mais pas génial.

Nous allons adapter ce projet afin qu'il se comporte de la même manière
MAIS que les objets `robert`, `amandine` (etc.) soient de type `Joueur`.

## Terminale : version POO

Implémente les mêmes fonctions avec une API légèrement différente
Cette fois le type des joueurs est `Joueur`

~~~python
>>> robert = Joueur('Robert', 10, 2)
>>> amandine = Joueur('Amandine', 10, 2)
>>> vainqueur = combat(robert, amandine)

Bagarre entre Robert et Amandine !
Robert tape Amandine et fait 1 points de dégâts.
...
Robert tape Amandine et fait 2 points de dégâts.
Robert a gagné !
Amandine est mort

>>> vainqueur
Robert a 1 points de vie et une force de 2

>>> type(robert)
<class '__main__.Joueur'>
>>> robert
Robert a 0 points de vie et une force de 2
~~~

## Remarques

L'API n'a pas vraiment changée.

On crée toujours Robert et Amandine avec un appel... mais cette fois on
appelle la classe et elle instancie un objet.

```python
>>> robert = Joueur('Robert', 10, 2)
>>> type(robert)
<class '__main__.Joueur'>
```

Non seulement on peut s'assurer que cet objet est du bon type mais on
peut aussi simplement l'afficher dans la console et il se présente :

```python
>>> robert
Robert a 0 points de vie et une force de 2
```

### Remarque. Si vous avez oublié ce que fait :


```python
if __name__ == '__main__':
  robert = ...
```

Lorsqu'on lance directement un script avec `python nom_script.py`

Celui-ci porte une variable interne `__name__` qui pointe sur la chaîne
`__main__`.

Lorsqu'on l'importe, il porte le nom donnée dans l'import :

```
import combat_texte_premiere

# ici __name__ = "combat_texte_premiere"
```

Donc que fait `if __name__ == '__main__':` ?

Cela vérifie que vous exécutez directement le script.

C'est _l'occasion de tester vos fonctions_. Puisque vous n'êtes pas
en train de vous en servir dans un projet plus vaste.

# Étapes du projet

## Version première

Vous allez vous inspirer du code [`combat_texte_premiere.py`](combat_texte_premiere.py)

Attention ! Ce fichier doit être lu en détail pour que vous compreniez comment
l'adapter.

Pour cela il vous reste une fonction à écrire... C'est le seul moyen d'être
sûr que vous l'ayez lu !

La fonction `vainqueur` n'est pas programmée.

### A faire 1. La fonction `vainqueur`

Lisez sa documentation et programmez la.

## Version terminale

Le fichier [combat_texte_terminale_eleve.py](combat_texte_terminale_eleve.py)
est votre point de départ. Copiez le afin de le garder propre et traitez
ces éléments dans l'ordre.

### A faire 2 : La méthode `__init__`

Elle est appelée chaque fois qu'on crée un objet avec `Joueur( ... )`

Notre joueur prend trois paramètres : `nom`, `vie` et `force`.

Comme toujours avec les méthodes, elle prend le paramètre `self` (qui désigne
l'instance elle-même). Cette méthode crée les attributs de notre objet.

**La méthode `__init__` ne retourne JAMAIS RIEN**

Seul `nom` est correctement implémentée. Implémentez les deux autres.

**Remarquez bien la syntaxe :**

* `nom` est le paramètre passé à la méthode. C'est une variable locale à cette
  méthode.
* `self.__nom` est un _attribut_ qui existe dans toute la classe.
* Utiliser deux "soulignés blancs" `__` empêche d'utiliser cet attribut à
  l'extérieur de la classe. C'est une sécurité, ce n'est pas indispensable.


### A faire 3 : `get_vie`

En vous inspirant (largement) de `get_nom` programmer `get_vie`.
Cette méthode retourne le nombre de points de vie du joueur.

### A faire 4 : `perdre_vie`

Cette méthode prend un paramètre : `points` (en plus de `self`, bien sûr).

Elle modifie l'attribut désignant la vie du joueur.
S'il avait 5 points de vie avant d'appeler cette méthode avec le paramètre 3,
il n'aura plus que 2 points de vie.

### A faire 5 : `__repr__`

C'est une **"méthode magique"** de Python.

Il existe une liste de méthodes magiques permettant d'utiliser les outils
Python traditionnels (`print()`, `+, *, -, >` etc.) sur des objets.

Nous allons simplement implémenter _l'affichage dans la console_.
Au passage, on gagne `print()`.

`__repr__` est la méthode appelée chaque fois que Python exécute `repr()`
sur un objet.

Donc quand on fait :

```python
>>> robert = Joueur('Robert', 3, 5)
>>> robert # ici !
```

Ici Python exécute `repr(robert)` qui appelle `robert.__repr__()`

Ce mécanisme est le même pour TOUTES les méthodes magiques.

Le principe est :

**`__repr__(self) --> (str)`**

On implémente une méthode **QUI RETOURNE UNE CHAÎNE** (pas qui affiche
quelque chose).

Pour l'instant notre méthode fait ça :

```python
>>> robert
Robert
```

La méthode est incomplète. On voudrait aussi connaître le nombre de points de
vie et la force. Complétez la chaîne de caractères de façon à avoir :

```python
>>> robert
Robert a 5 points de vie et 3 de force.
```

### A faire 6. La méthode `taper`

Elle est presque complète.

Le mécanisme et la signature sont respectés, mais le message manque de précision.

Lorsqu'un joueur rate, on voudrait le savoir.

Là le message est : "Robert fait 0 points de dégâts"

C'est triste.

On voudrait : "Robert a raté"

Modifiez le code de la fonction pour implémenter ce message.

**Attention :** lorsqu'il touche, on veut toujours avoir comme message :
"Robert a fait 2 points de dégâts"

### A faire 7. Être triste.

Lorsqu'on passe un examen, ce que vous ferez bientôt, on lit l'énoncé
en entier avant de commencer.

* Documenter ses fonctions est une bonne pratique du développeur,
* _Lire le sujet est une bonne pratique de l'élève._

Les trois fonctions utilitaires `combat`, `vainqueur`, `afficher_vainqueur`
qui suivent sont les mêmes que celles de la version "première".

Elles contiennent donc les réponses à **A FAIRE 1**.

Ça vous apprendra.

Plus sérieusement, vous pouvez remarquer qu'elles fonctionnent
avec la même interface dans les deux versions.

Avoir utilisé la programmation objet ne change pas la manière
dont on se sert des objets.

Seulement la manière de les programmer.


### A faire 8. Compléments (bonus)

Maintenant que nous avons un combat rudimentaire, c'est l'occasion de
l'améliorer.

On pourrait approfondir (et dépasser) le programme en créant des catégories
de combattants avec des pouvoir spéciaux.

Par exemple `Magicien` et `Druide`.

* `Guerrier` a un coup spécial `charger` qui tape deux fois plus fort.
* `Druide` a un coup spécial `soin` qui rend un nombre aléatoire de points de vie.

On crée donc deux classes qui **héritent** de "Joueur".

```python
class Guerrier(Joueur)
```

On crée pour chacune seulement la méthode `coup_special` avec la même signature
que `taper`

```python
class Guerrier(Joueur)
  def coup_special(self, adversaire):
    pass
```

On n'a pas besoin de modifier les méthodes déjà existantes.
MAIS ... **pour hériter facilement des attributs, ils ne doivent pas être propres**
**à une classe**. Tous les attributs de `Joueur` doivent être modifiés :

**`self.__nom`** doit devenir **`self.nom`** etc.

Il faut les modifier tous !

C'est moins propre, mais plus facile.

La méthode moins facile, consister à copier la méthode `init` pour chaque
classe.

**instance de `Guerrier`, `Druide`**

Pour utiliser vos nouvelles classes, il faut les instancier.

Pensez à donner à Robert la classe `Guerrier` et Amandine la classe `Druide`.

**Le Combat**

Pour l'instant, notre combat n'utilise que `Joueur.taper`. Il faut le modifier.

Dans combat, une fois sur deux (au hasard), plutôt que d'appeler `Joueur.taper`
on appelle `Joueur.coup_special` :

```python
Robert charge Amandine et fait 2 points de dégâts.
Amandine se soigne pour 2 points de vie
Robert tape Amandine et fait 1 points de dégâts.
Amandine tape Robert et fait 1 points de dégâts.
```

---

Si vraiment ça n'a pas résisté longtemps, vous pouvez créer d'autres catégories
de joueurs :

* voleurs qui tape ET se soigne un peu en même temps,
* magicien qui lance des boules de feu etc.

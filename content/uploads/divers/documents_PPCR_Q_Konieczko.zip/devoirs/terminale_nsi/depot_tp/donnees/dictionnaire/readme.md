---
title: "Structure de dictionnaire en Python"
author: "qkzk"
date: "2020/09/27"

---

# Implémenter une structure de dictionnaire en Python

**Qu'est ce qu'un _dictionnaire_ ?**

C'est une structure de donnée pour qui permet de :

* relier des couples `(clé, valeur)`,
* de réaliser l'association `clé -> valeur` le plus rapidement possible.

Python propose justement le type `dict` qui implante ces méthodes et pour lequel
le temps d'accès d'une valeur depuis sa clé est constant.

Cela signifie que le temps d'accès ne dépend pas de la taille du dictionnaire :
qu'il contienne 1 élément ou 10.000.000 éléments, le temps d'accès sera 
toujours identique.

Mais comment faire ?

Avant d'en arriver là, posons nous une question naïve :

**Quelle est la signature d'un dictionnaire ?**

Autrement dit, qu'aimerait on pouvoir faire avec un dictionnaire ?

* créer un dictionnaire vide,
* ajouter des éléments par leur couple `(clé, valeur)`,
* accéder à la valeur depuis une `clé`,


On peut ajouter d'autres méthodes pratiques comme :

* supprimer un élément,
* donner la longueur (c'est-à-dire le nombre de clés)
* itérer sur les clés (ou sur les valeurs ou les couples clé, valeur)

etc.

## Comment sont implantés les dictionnaires en Python ?

C'est une question particulièrement difficile, car l'implantation a
régulièrement avec le temps !

En simplifiant grossièrement, elle correspond à ce que nous ferons dans la 
partie "utiliser un hashage".

# Première implantation utilisant des listes

Puisqu'en Python les dictionnaires sont des types, nous allons créer une classe,
appelée `DictionnaireListe` qui retient ses éléments dans une liste
de couples `(cle, valeur)`

On doit pouvoir :

1. Créer un dictionnaire vide :

    ```python
    >>> d = DictionnaireListe()
    ```

2. Ajouter un élément :

    ```python
    >>> d.ajouter("cle", "valeur")
    ```

3. Accéder à un élément :

    ```python
    >>> d.acceder("cle")
    'valeur'
    ```

4. Tester l'appartenance :

    ```python
    >>> d.contient("cle")
    True
    >>> d.contient("bonjour")
    False
    ```

5. Effacer un élément :

    ```python
    >>> d.effacer('cle')
    >>> d.contient('cle')
    False
    ```

6. Afficher ce qu'il contient :

    ```python
    >>> d.ajouter("Bonjour", "La famille")
    >>> d
    DictionnaireListe((('Bonjour', 'La famille'),))
    ```

7. Créer un dictionnaire avec des éléments :

    ```python
    >>> d = DictionnaireListe( ((1, 2), (3, 4), (5, 6))  )
    >>> d.acceder(1)
    2
    >>> d.acceder(3)
    4
    ```

Dans cette partie, hormis `__init__` la seule méthode magique à implanter
est `__repr__` qui ne prend qu'un paramètre (`self`) et renvoie une chaîne de
caractères.

## À faire 1

1. Créer un script Python qui implante cette classe.
2. Écrire des tests (à l'aide d'`assert`) qui vérifient son bon fonctionnement.
3. (Bonus) Remplacer les méthodes "explicites" comme `acceder` par des méthodes
    magiques permettant d'utiliser la syntaxe habituelle de Python :

    Plutôt que :

    ```python
    >>> d.acceder("cle")
    'valeur'
    ```

    On souhaite utiliser

    ```python
    >>> d['cle']
    'valeur'
    ```


### Remarques importantes


1. On doit pouvoir importer votre module, on prendra donc soin de réaliser les
    tests dans une fonction `tester()` qui n'est exécutée que si le script
    est exécuté directement :

    ```python
    def tester():
        # vos tests ici

    if __name__=='__main__':
        tester() # ne sera exécuté que si le script est exécuté directement.
    ```

1. Procédez par étape et testez au fur et à mesurer.
2. Lors de l'initialisation, on crée une _liste_ vide.
3. Lors de l'ajout, on peut utiliser la méthode `append` des listes pour ajouter
    un élément.

    Dans la liste on ajoute un _couple_ `(cle, valeur)`
4. Pour accéder à une valeur depuis sa clé on peut simplement parcourir la liste
    des éléments jusqu'à trouver sa clé. On relève l'indice intéressant, ensuite
    on ne retourne que la valeur correspondante (le 2ème élément de la liste).

    Relisez cet algorithme jusqu'à ce qu'il vous semble clair

5. Effacer s'appuie sur le même algorithme. Une fois l'indice obtenu, on peut
    utiliser `del ma_liste[indice]` qui va supprimer un élément dans la liste.


### Complément sur les méthodes magiques

La plupart des méthodes implantées plus haut peuvent être remplacées
par des méthodes magiques.

Cela permet, par exemple de remplacer :

```python
d.ajouter(1, 2)
```

par :

```python
d[1] = 2
```

Voici l'aide de la correction qui peut vous éclairer :

```
Help on class DictionnaireListe in module __main__:

class DictionnaireListe(builtins.object)
 |  DictionnaireListe(collection=None)
 |
 |  Dictionnaire python implanté avec des listes
 |  Implante toute l'interface des dictionnaires
 |
 |  Methods defined here:
 |
 |  __delitem__(self, cle_recherchee)
 |
 |  __getitem__(self, cle_recherchee)
 |
 |  __init__(self, collection=None)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |
 |  __iter__(self)
 |
 |  __len__(self)
 |
 |  __repr__(self)
 |      Return repr(self).
 |
 |  __setitem__(self, cle, valeur)
 |
 |  clear(self)
 |      vide le dictionnaire
 |
 |  copy(self)
 |      retourne une copie du dictionnaire
 |
 |  get(self, cle)
 |      retourne la valeur de la clé si elle est contenue, None sinon
 |
 |  items(self)
 |      renvoie un itérateur des couples (clé, valeur)
 |
 |  keys(self)
 |      renvoie un itérateur des clé
 |
 |  values(self)
 |      renvoie in iterateur des valeurs

```

Ce n'est clairement pas un attendu du programme, d'autant que certaines
sont particulières (`__iter__` et `__delitem__`)


## Complexité algorithmique

Rappelons qu'on appelle _Complexité algorithmique_ l'évolution du temps
d'exécution lorsque la taille de l'objet augmente.

On range les complexité dans des classes similaires (de pire en pire) :

1. Constant : le temps d'exécution n'augmente pas avec la taille.

    Exemple : accéder à `l[3]` si `l` est une liste
2. Logarithmique : le temps d'exécution dépend du nombre de bits de la taille.

    Exemple : recherche dichotomique dans une liste triée.
2. linéaire : le temps est linéaire (`taille * 2 => durée * 2`)

    Exemple : Parcourir une liste et chercher un élément.
3. quadratique : `taille * 2 => durée * 2 * 2`

    Exemple : tri par insertion, tri par sélection...
4. Cubique, polynomial : `taille*2 => durée* 2 ** 3` ou `duree* 2 ** n`
5. Exponentiel : `duree ~ 2 ** taille`

    Exemple : calculer récursivement le n^ème^ terme de la suite de Fibonacci
    sans conserver de valeurs intermédiaires en mémoire.

Dans cette dernière catégorie, les temps explosent complètement...



Le temps d'accès pour cette première version du dictionnaire est (si vous
l'avez implanté correctement) une fonction _linéaire_ du nombre de clé
et nous allons le constater.

### À faire 2

Mesurer les temps d'accès.

Nous allons créer des dictionnaires de plus en plus grands (les nôtres
et ceux déjà proposés par Python) et comparer les temps d'accès à un élément.

* Pour mesurer un temps d'exécution on peut utiliser `time`

    ```python
    from time import time

    debut = time()
    # ici ce qu'on souhaite mesurer
    for i in range(1000000):
        i ** 2
    fin = time()
    duree = fin - debut
    # duree contient le temps d'exécution en seconde.
    ```

* Pour construire une figure on peut s'inspirer de :

    ```python
    from matplotlib import pyplot as plt


    x = [1, 2, 3]                       # les abscisses
    y_1 = [6, 5, 4]                     # 1ère série d'ordonnées
    y_2 = [7, 8, 9]                     # 2ème série d'ordonnées
    plt.plot(x, y_1)                         # y_1 en fct de x
    plt.plot(x, y_2)                         # y_2 en fct de x
    plt.legend(["série 1", "serie 2"])  # les légendes
    plt.show()                          # dessine la figure
    ```

* Exemple pour mesurer créer les séries de valeurs pour les dictionnaires :

    ```python
    from time import time
    from matplotlib import pyplot as plt

    x = list(range(10000, 100001, 10000))  # de 10000 en 10000 jusqu'à 100 000

    y = []

    for taille in x:
        d = {i: i for i in range(taille)}  # crée un dictionnaire de taille donnée

        debut = time()
        d[taille // 2] == taille // 2      # accède à un élément
        fin = time()

        duree = fin - debut

        y.append(duree)


    plt.plot(x, y)                               # y_1 en fct de x
    plt.legend(["dictionnaire Python"])     # les légendes
    plt.show()                              # dessine la figure
    ```

On constate que les temps d'accès varient relativement peu : ils sont constants.


**Consigne** : adapter l'exemple précédent pour mesurer les temps d'accès
de nos dictionnaires.


On constate cette fois que les temps d'accès progressent _linéairement_,
c'est beaucoup moins bien !

# Dictionnaire avec table de hachage

Comment éviter cet écueil ?

## Table de hachage

Le principe d'une table de hachage repose sur une catégorie d'algorithmes
particuliers qui sont capables de prendre un objet et de renvoyer une valeur
entière de taille voulue.

C'est donc une fonction qui converti n'importe quoi (ou presque) en un entier.

Python propose la fonction `hash` qui prend n'importe quel objet immuable
(nombres, chaînes, tuples... mais pas les listes ni les dictionnaires) et
renvoie un entier.

Cette fonction est extrêmement rapide et nous allons nous en servir.

```python
>>> hash(1234)
1234
>>> hash(12.34)
783986623132655628
>>> hash( (1, 2) )
-3550055125485641917
>>> hash( "bonjour !" )
1332844020439586283
>>> hash( [1, 2])
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unhashable type: 'list'
```

### Complément : fonction de _hachage_

Une _fonction de hachage_ est une fonction qui prend un objet en mémoire
et renvoie un entier (généralement de taille maximale fixée).

Pensons, par exemple à des objets qui sont des fichiers, une première fonction
de hachage pourrait être la taille du fichier.

**À quoi servent les fonctions de hachage ?**

Principalement à reconnaître les objets en question. Il est plus rapide de 
comparer la taille de deux fichiers pour les distinguer que de les comparer
bits par bits.

Si deux fichiers n'ont pas la même taille, ils sont différents ! Pas dur.

**Utilisation des fonctions de hachage**

En pratique, on peut distinguer trois usages courants :

1. celui que nous allons implanter aujourd'hui : à savoir donner une valeur
    entière facile à connaître pour un objet passé à la fonction.
2. signer un document ou un fichier. Lorsqu'on communique un document important,
    on peut l'accompagner de son hachage _cryptographique_. Cela fait référence
    à des fonctions de hachage particulières dont le résultat varient beaucoup
    dès qu'un bit est modifié.

    Ainsi il est quasi impossible de modifier discrètement le document sans
    que le hachage n'en soit modifié.

    Le récepteur du document vérifie que le hachage de sa version correspond
    à celui qui est publiquement partagé et il est _certain_ d'avoir exactement
    reçu le document souhaité.

    Git utilise ce principe pour s'assurer qu'un fichier n'a pas été modifié
    entre deux versions d'un programme.
3. Reconnaître une oeuvre (généralement du son ou de la vidéo). Comment fait
    youtube pour reconnaître les morceaux musicaux que diffusent les vidéastes ?

    Certaines fonctions de hachage sont conçues pour retourner une signature
    du son qui soit fiable même si celui-ci est légèrement altéré ou qu'on
    en change la qualité.

    De la même manière que nous reconnaissons tous certains morceaux légendaires
    (_le petit bonhomme en mousse..._) quelle qu'en soit la qualité
    d'enregistrement (perso j'ai acheté le vinyle).

**Comment fonctionnent les fonctions de hachage ?**

Là on dépasse totalement le cadre du programme. 

Elles ont toutes pour particularité d'être rapides et donc de n'utiliser
que des opérations "élémentaires" sur les bits.

Si vraiment vous êtes curieux, cette [discussion](https://stackoverflow.com/questions/2070276/where-can-i-find-source-or-algorithm-of-pythons-hash-function)
(en anglais) peut être un point de départ.

## Implanter des dictionnaires avec une table de hachage


Voici le principe :

* on décide que nos dictionnaires n'auront pas plus de 1024 éléments.
* lors de l'initialisation on crée une liste remplie de `None` de taille 1024 :

    ```python
    >>> ma_liste = [None] * 1024
    ```
* Pour ajouter un élément au dictionnaire, on calcule le hachage de sa _clé_.

    On en prend le modulo 1024 :

    ```python
    indice = hash(cle) % 1024
    ```

    On enregistre alors dans la liste, à l'indice donné par le hachage, le
    tuple `(clé, valeur)`

    Par exemple si notre dictionnaire contient la clé `'a'`, de valeur `'b'`
    et que le hachage modulo 1024 de `a` est 456 alors notre liste contient
    l'élément `('a', 'b')` à l'indice 456.

    ```python
    ma_liste[456] = ('a', 'b')
    ```
    Ne génère pas d'erreur car notre liste contient déjà 1024 éléments...

* Pour accéder à un élément depuis sa clé, on calcule à nouveau `hash(cle)`,

    ce nombre est _l'indice_ du couple dans la liste...

* On renvoie alors la valeur (le second élément de ce qui est dans la liste).

Relisez bien cet algorithme s'il n'est pas clair.


### A faire 4

Reprendre la classe des dictionnaires et créer une classe des dictionnaires
avec hachage.

Certaines méthodes sont maintenant beaucoup plus rapides.

## Comparer les vitesses

### A faire 5

Ajouter les vitesses d'accès aux éléments avec la table de hachage
à votre figure.

Si vous avez implanté correctement les méthodes, le temps d'accès devrait
être constant, trois ou quatre fois moins rapide que les dictionnaires natifs,
mais tout de même.

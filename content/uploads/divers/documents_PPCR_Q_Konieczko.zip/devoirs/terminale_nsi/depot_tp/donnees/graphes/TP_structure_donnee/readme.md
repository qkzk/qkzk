---
title: NSI Terminale - Algorithmes
subtitle: Les graphes - TP - Strucutre de donnée graphe
date: 2020/05/02
author: qkzk
---

# Structure de donnée graphe

Nous allons implémenter une simple structure de donnée pour les graphes.
Nous utiliserons la programmation objet, nous crééons donc une classe Graphe
pour les graphes simples.


## Primitives

Quelles sont les primitives et opérations dont nous allons avoir besoin ?

1.  Créer un graphe. On le supposera vide :

    ```python
    >>> g = Graphe() # un graphe vide
    ```
2.  `est_vide` : retourne vrai si le graphe est vide.

    ```python
    >>> g.est_vide()
    True
    ```
2.  Ajouter un sommet

    ```python
    >>> g.ajouter_sommet('a')
    >>> g.ajouter_sommet('e')
    ```
3.  Liste des sommets

    ```python
    >>> g.sommets()
    ['a', 'e']
    ```

    Ici attention aux noms de variables.

    `self.sommets` est une méthode, pas l'attribut qui contient la
    liste des sommets. Il faut lui donner un autre nom.

    Pourquoi pas `self.liste_sommets` ?


3.  Ajouter une arête (entre deux sommets existant ou non)

    _Bien lire la question d'après avant d'implementer cette méthode._

    C'est la méthode la plus importante. Comment enregistrer les arêtes ?

    Elles sont référencées par un _dictionnaire_

    *   clés : les sommets,
    *   valeurs : liste des sommets auxquels ils sont liés.

    ```python
    >>> g.ajouter_arete('a', 'b')
    ```
    Dans notre exemple, `'a'` et `'b'` sont liés.

    En mémoire on doit avoir :

    ```python
    {'a': ['b'],
    'b': ['a']}
    ```


4.  Récupérer les arêtes

    On récupère ici un _dictionnaire_ contenant les arêtes partant de chaque
    sommet. C'est le moyen le plus pratique d'enregistrer les arêtes.



    ```python
    >>> g.aretes()
    {'a': ['b'],
     'b': ['a']}
    ```

5.  Voisins

    Retourne les voisins d'un sommet.

    ```python
    >>> g1.voisins('a')
    ['b']
    >>> g1.voisins('b')
    ['a']
    >>> g1.voisins('e')
    []
    ```

5.  Sont adjacents ?

    Vrai si deux sommets sont reliés par une arête

    ```python
    >>> g.sont_adjacents('a', 'b')
    True
    >>> g.sont_adjacents('a', 'e')
    False
    ```

6.  Matrice d'adjacence

    Retourne la matrice d'adjacence d'un graphe.


    ```python
    >>> g1.matrice_adjacence()
    [[0, 1, 0],
     [1, 0, 0],
     [0, 0, 0]]
    ```

### Exemple de déroulé :

![graphe](img/8_graphe.png)


```python
from pprint import pprint
g = Graphe()
g.ajouter_arete('a', 'b')
g.ajouter_arete('a', 'c')
g.ajouter_arete('b', 'c')
g.ajouter_arete('b', 'd')
g.ajouter_arete('c', 'e')
g.ajouter_arete('d', 'f')
g.ajouter_arete('e', 'f')
g.ajouter_sommet('h')

print(g.voisins('a'))
print(g.sont_adjacents('b', 'e'))
print(g.sont_adjacents('b', 'f'))
print(g.sont_adjacents('f', 'e'))
print(g.sont_adjacents('e', 'f'))
pprint(g.matrice_adjacence()) # affichage plus lisible
```

On obtient alors dans la console :

```
False
False
True
True
['b', 'c']
[[0, 1, 1, 0, 0, 0, 0],
 [1, 0, 1, 1, 0, 0, 0],
 [1, 1, 0, 0, 1, 0, 0],
 [0, 1, 0, 0, 0, 1, 0],
 [0, 0, 1, 0, 0, 1, 0],
 [0, 0, 0, 1, 1, 0, 0],
 [0, 0, 0, 0, 0, 0, 0]]
```

## Compléments

Ils sont innombrables.

On peut

1.  Utiliser une méthode de classe pour _créer_ un graphe
    depuis sa matrice d'adjacence.

    C'est de très loin le plus intéressant et ça n'est pas très difficile

2.  Ajouter deux prédicats `est_oriente`, `est_simple`

3.  Implémenter les parcours et autres algorithmes avec notre classe

    Il suffit de reprendre les fonctions vues en TP et de changer les méthodes
    relatives à la classe. Des copiers collers adaptés en gros.

4.  Mutabilité. Pour l'instant on peut _ajouter_ des sommets et des arêtes.

    Implémenter la suppression.

    Attention, supprimer une arête est facile mais
    supprimer un sommet enlève _aussi_ les arêtes reliant ce sommet...

5.  Héritage (hors programme mais cool).

    Créer une class qui hérite de `Graphe` et implémente les _graphes orientés_.

    On hérite d'un maximum de choses.

    Il faut implémenter correctement :

    *   l'ajout d'arêtes (on conservera le
        meme nom, on devrait dire "arcs"...)
    *   `est_simple`, `est_oriente`
    *   `successeurs` (les voisins), `predecesseurs`

    Il faut s'assurer que les parcours et chemins fonctionnent toujours.

6.  Représenter le graphe.

    L'approche la plus simple est de gruger.

    On crée un graphe dans networkx (le plus rapide ? avec la matrice
    d'adjacence). Ensuite on le dessine.

    Le code est moche mais ça fait de jolis dessins.

---
title: NSI Terminale - Structure de données
subtitle: 'TP: Créer un type "Liste"'
date: 2020/04/20
author: qkzk
---

# la classe `Liste`

L'objectif de ce TP est de créer en Python un type d'objet "Liste"
qui respecte les conditions vues en cours.

Résumons les :

## Structure de donnée `Liste`

Une structure de donnée **liste** doit implémenter :

1. **La construction** à partir d'une liste vide ou à partir d'un couple tête (élément) et reste (liste).
2. **La sélection** de l'élément de tête ou du reste.
3. **Prédicat.** on doit pouvoir répondre à la question : "cette liste est-elle vide ?"


## Comment procéder ?

Par étapes !

## Qu'est-ce qu'un `type` en Python ?

On a déjà utilisé la fonction `type` pour connaître la nature d'un objet.

* la fonction `type` fait de nombreuses choses. Appelée avec un objet en paramètre
  elle retourne une information sur son type
* On peut l'utiliser pour vérifier un type, mais il y a mieux : `insinstance(objet, type)`

```python
>>> d = {1:"a", 2:"b"}
>>> type(d)
<class 'dict'>
>>> type(d) == dict
True
>>> isinstance(d, dict)
True
```

Dans Python, tous les élément sont des "objets". Ils ont tous un type.

## Créer de nouveaux types

On l'a déjà vu dans le chapitre programmation objet, pour créer un type,
il suffit de créer une nouvelle classe.

### A faire 1.

1. Dans le fichier `listes.py` on a défini une nouvelle classe `List`

    Une classe Python ne demande que 2 lignes pour être définies :

    ```python
    class NomDeLaClasse:
          pass
    ```

2. On a ajouté une instance d'un objet avec `ma_liste = Liste()` et vérifiez son type.

    Voici ce que vous devriez avoir :

    ```python
    <class '__main__.Liste'>
    ```

3. Oui, le code est fourni. Lisez le attentivement. Sans quoi vous n'avancerez pas.


## Instance d'un objet

### A faire 2.

Méthode pour instancier des listes.

Lorsqu'on crée un nouvel objet avec `ma_liste = Liste()`, Python appelle
une méthode magique appelée `__init__`.

C'est le **constructeur**.

Cette méthode prend autant de paramètres qu'on veut. Attention lorsqu'on la
défini, il faut toujours lui passer en premier paramètre le mot clé `self`

* Exemple correct

  ```python
  class Joueur:
    def __init__(self, vie):
      self.vie = vie
  ```

  Qui s'utilise avec :

  ```python
  >>> robert = Joueur(30)
  ```

* Exemple incorrect

  ```python
  class Joueur:
    def __init__(vie): # on a oublié self !
      self.vie = vie
  ```

  Et ça plante !

  ```python
  >>> robert = Joueur(30)
  Traceback (most recent call last):
    File "<stdin>", line 1, in <module>
  TypeError: __init__() takes 1 positional arguments but 2 were given
  ```

Que voulons-nous dans la méthode `__init__` ?

Pour l'instant _rien_. On veut juste créer une liste vide.

Vous pouvez donc créer une méthode `__init__` qui ne prend aucun autre paramètre que `self`

Que fait-elle ? Pour l'instant _rien_. `pass` fera l'affaire.

### Pourquoi ?

Pourquoi créer une méthode `__init__` vide ?

C'est la bonne approche. On ne sait pas encore quels attributs seront nécessaires.

Il vaut mieux créer les méthodes AVANT les attributs.

* Les méthodes nous disent ce que la structure de donnée peut faire !
* Les attributs sont les informations dont on aura besoin pour réaliser ces possibilités.

## Les méthodes d'une liste.

* Une liste a une tête, à laquelle on doit pouvoir accéder.
* Une liste à une queue (encore une liste), à laquelle on doit pouvoir accéder.
* Si une liste est vide on doit pouvoir le savoir.
* Par commodité, on aimerait afficher les listes dans la console.

Cela nous fait 4 méthodes à créer (en plus du constructeur) :

1. `tete` : qui retourne la tête de la liste ou lève une exception `ListError` si la liste est vide.
2. `queue` : qui retourne laqueue de la liste ou lève une exception `ListError` si la liste est vide.
3. `est_vide` : qui retourne un booléen.
4. `__repr__` : qui retourne une chaîne de caractères.

---

**Remarque** : vous allez apprendre à créer des exceptions dans Python. C'est simple.

1. Créer une classe qui hérite de `Exception ` :

    ```python
    class MonException(Exception):
      ...
    ```

2. Créer une méthode `__init__` (un constructeur). Qui prend un paramètre et l'attribut à `self.msg`

    ```python
    class MonException(Exception):
      def __init__(self, msg):
        self.msg = msg
    ```

Pour les utiliser il suffit d'écrire `Raise MonException("message")`

Et voilà !

Votre fichier source contient déjà la classe `ListException`, inutile de la créer.
Lisez le attentivement.

---

### A faire 3.

Créer les  quatre méthodes citées plus haut.

Pour l'instant donnez leur comme unique paramètre `self` et comme action `pass`.

Pour éviter de faire planter `__repr__` faîtes lui retourner une chaîne vide :

```python
  def __repr__(self):
    return ''
```

## Choisir une interface

Choisir une **interface**. Nous devons décider de la mnière d'utiliser nos listes.



Comment peut-on créer, par exemple, un dictionnaire en Python ?

```python
>>> mon_dict_vide = {}
```

Cette construction est équivalente à :

```python
>>> mon_dict_vide = dict()
```

Et un dictionnaire avec `"age : 14"`

```python
>>> mon_dict = {"age": 14}
```

On a donc deux constructeurs différents !

Selon qu'on le crée avec aucun élément ou avec des éléments, utilise sensiblement
la même syntaxe.

Voici ce qu'on veut faire :

```python
>>> liste_vide = Liste()
>>> liste_pas_vide = Liste(1, liste_vide)
>>> liste_vide.est_vide()
True
>>> liste_pas_vide.est_vide()
False
```

Remarquez bien l'appel réalise à `Liste`

1. La première fois : aucun paramètre.
2. La seconde fois : 2 paramètres.

Flûte, nous n'avons jamais fait ça...

### La solution : *args


Quoi ?


Testez l'exemple suivant

```python
def func(*args):
  return args
```

avec

```python
>>> func()
()
>>> func(1, 2, 3)
(1, 2, 3)
```

Que s'est-il passé ?

La notation `*args` dit à Python de décomposer tous les arguments dans un tuple,
appelé `args`. (_args_ pour _arguments_, les paramètres).

Ensuite on en fait ce qu'on veut !

Par exemple :

```python
def func(*args):
  if len(args) == 0:
    print("pas reçu d argument, Reviens demain petit")
  else:
    print("plein d arguments, t en veux ?")
```

Quand on l'utilise on a :

```python
>>> func()
pas reçu d argument, Reviens demain petit
>>> func(1, 2, 3)
plein d arguments, t en veux ?
```

BON !

Pour nous cela signifie deux choses :

1. créer une interface revient à créer la méthode `__init__`
2. on peut créer des interfaces qui varient en fonction du nombre de paramètres
    qu'on leur donne.

### A faire 4 : interface et constructeur

Adapter la technique vue ci-dessus avec :

```python
  def __init__(self, *args):
    if ...
```

1. Si on n'a pas reçu d'argument :

    ```python
    self.contenu = None
    ```

2. Si on a reçu des arguments :

    ```python
    self.contenu = *args
    ```

* **Complétez votre constructeur.**
* **Testez votre interface.** Vous devez pouvoir créer des listes avec 0 ou 2 arguments.

    En fait, autant que vous voulez... C'est un problème qu'on résoudra plus tard.

Quelques exemples pour tester :

```python
>>> l0 = Liste()
>>> l1 = Liste(1, l0)               # doit fonctionner
>>> l2 = Liste(1, Liste(2, l0))     # doit fonctionner
>>> l3 = Liste(1)                   # doit planter : pas assez de paramètres
>>> l3 = Liste(1, 2, 3)             # doit planter : trop de paramètres
```

### A faire 5 : La méthode `est vide`

Programmez la méthode `est_vide`

Vous avez maintenant une variable `self.contenu` qui vous permet de tester
si une liste est vide.

```python
>>> vide = None  # La variable `vide` pointe vers None.
>>> vide == None # correct mais mauvaise pratique : très lent
True
>>> vide is None # mieux car plus rapide
True
```

Le contenu de cette fonction tient en une ligne !


### A faire 6 : La méthode `tête`

Elle doit faire deux choses :

1. Si la liste `liste_1` n'est pas vide, `liste_1.tete()` retourne son élément de tête.
2. Si la liste `liste_2` est vide, `liste_2.tete()` lève une exception `ListeError`

Testez avec une liste non vide et une liste vide.

### A faire 7 : La méthode `queue`

Elle doit faire deux choses :

1. Si la liste `liste_1` n'est pas vide, `liste_1.queue()` retourne la liste de queue.
2. Si la liste `liste_2` est vide, `liste_2.queue()` lève une exception `ListeError`

Testez avec une liste non vide et une liste vide.

### A faire 8 : améliorer le constructeur

Deux choses à faire :

1. Empêcher de créer une liste avec autre chose que 0 ou 2 éléments.
2. Si la liste a deux éléments, le second doit être un objet de type `Liste`.

Programmez ça.

## Afficher les listes dans la console : la méthode `__repr__`


---

Je vous rappelle ce qui se passe quand vous exécutez :

```python
>>> l1 = Liste(1, Liste())
>>> l1
# ici python va afficher qq chose; mais comment ?
```

1. Python appelle `repr(l1)`
2. `repr(l1)` exécute `l1.__repr__()`
3. Cette méthode doit retourner une chaîne de caractères. Elle est affichée
  dans la console.
4. Deux possibilités ici :

    * pour l'instant, on n'a pas programmé `__repr__` : il affiche alors une description
      générale de l'objet

      ```python
      >>> l1
      <__main__.Liste object at 0x7fe0f05f60d0>
      ```
    * Quand on aura programmé la méthode `__repr__` : il affichera ce qu'on y aura mis.


      (quelque chose permettant d'afficher la liste.)

---

On peut décider de les afficher de beaucoup de manière :

Deux présentations possible :

* comme un tabeau / tuple :

  ```python
  >>> l1 = Liste(1, Liste(2, Liste(3, liste())))
  >>> l1
  (1, 2, 3)
  ```

  C'est joli mais ça crée des confusions. C'est quoi ? Un Tuple ?

  Je pensais que c'était une liste ! _Problème._

* comme une liste chaînée :

  ```python
  >>> l0 = Liste()
  >>> l0
  ()
  >>> l1 = Liste(1, Liste(2, Liste(3, l0)))
  >>> l1
  (1.(2.(3.())))
  ```

  Là c'est mieux ! Un peut moins facile à lire mais on comprend bien
  mieux la nature _récursive_ de cette structure !

  Vous avez compris, c'est ce qu'on va faire.



### Résumons.

1. `__repr__` est une méthode récursive.
2. Quel-est son cas d'arrêt ?

    (à vous de répondre...)

    Que doit-on retourner dans ce cas ?
3. Pour l'autre cas (allez, je vous aide, _si la liste n'est pas vide_), je pense
     que vous aurez du mal à trouver.

     Il faut retourner une construction recursive :

   ```python
   def __repr__(self):
     if ...
      ...
    else:
      return '('+repr(self.tete())+'.'+repr(self.queue())+')'
   ```

   Que fait ce retour ?

   Décomposons :

   * `repr(self.tete())` : exécute la méthode `__repr__` sur la tête de la liste.

      Cet objet est de n'importe quel type donc on ne peut pas forcement
      l'écrire dans la console sans faire `repr` dessus.

   * `repr(self.queue())` : exécute la méthode `__repr__` sur la liste de queue.

        Là cette partie est récursive.

   * `'('+ ... + ')'` on additionne des chaînes de caractères.


Vous devez pouvoir tester :

```python
>>> l0 = Liste()
>>> l0
()
>>> l1 = Liste(1, Liste(2, Liste(3, l0)))
>>> l1
(1, (2, (3, ())))
```


## Conclusion

Nous avons maintenant crée un nouveau `type` Python, les listes.

* Elles peuvent être instanciées,
* On peut récupérer ce qu'elles contiennent (tête et queue),
* On peut les afficher dans la console,
* On a des messages d'erreur permettant de savoir s'il existe un problème.

En ajoutant un peu de documentation, on obtient un code à la fois propre et
élégant (court et bien découpé).

## Poursuite

Remarquons que nos listes sont pauvres. Une fois crées, on ne peut rien en faire...

Il serait intéressant d'ajouter quelques méthodes :

* insérer un élément,
* répondre à la question : a-t-on `x` dans la liste ? A quelle position ?
* supprimer un élément,
* faire des boucles : `for x in ma_liste: ...`

Bref. C'est l'objet du prochain TP.

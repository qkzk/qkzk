# Palindromes

## Différentes manières de résoudre un même problème :

Ce mot est-il un _palindrome_ ?

**palindrome**:

> Mot ou groupe de mots qui peut se lire indifféremment de gauche à droite ou de
> droite à gauche en gardant le même sens (ex. la mariée ira mal ; Roma Amor).

Cas limites et exemples :

* `''` est un palindrome (la chaîne vide est un palindrome),
* `'a'` en est un aussi,
* `'aba'` aussi,
* `aaaaabcaaaaa` n'est pas un palindrome !

## Palindromes ?

### Problème : un mot donné est-il un palindrome ?

Nous allons répondre à cette question de plusieurs manières

## Algorithme naïf

L'algorithme le plus simple à implémenter en Python qu'on puisse envisager est
le suivant :


1. retourner `mot` est la stocker dans une variable `mot_retourne`
2. retourner `mot == mot_retourne`

Comment retourner une chaîne en Python ?

Efficacement, avec un `slice` : on parcourt la chaîne à l'envers.

Voici ce que ça donne :


```python
def is_palindrome_reverse(mot):
    '''Vrai si et seulement si "mot" est un palindrome'''
    return mot[::-1] == mot
```

Fin du TP, rentrez chez vous !

---

### **OU PAS**

## Tester

Nous allons écrire plusieurs solutions aux problème présenté.

Pour cela nous devons tester que nos fonctions répondent correctement au
problème. Idéalement, nous allons utiliser les mêmes tests pour les différentes
versions.

### A faire 1

Proposer un jeu de tests, englobés dans une fonction, qui lève une exception
si une vérification échoue.

Vous devez tester que la fonction `is_palindrome_version_jesaispasquoi` :

*   retourne vrai pour différents palindromes (courts, longs, avec une lettre
    centrale ou non)
*   retourne faux pour différents cas (courts, longs, aucune correspondance,
    presque un palindrome comme `abcdecba` etc.)


Vérifiez qu'ils sont juste avec la fonction proposée.

## Récursion

### A faire 2

1. Proposer un algorithme récursif pour tester qu'un mot est un palindrome.
2. Programmer une fonction récursive qui répond Vrai si et seulement si un mot
    est un palindrome
3. Testez la ! (on le fera à chaque fois !)


## Avec une _pile_

Pour simuler une _pile_ (last in, first out),

on remplit une liste `lettres`, on la vide avec `lettres.pop()`

```python
>>> mot = "bonjour"
>>> lettres = list(mot)
>>> lettres
['b', 'o', 'n', 'j', 'o', 'u', 'r']
>>> while lettres != []:
... c.pop()   # <------------------ vide par LA FIN
...
'r'
'u'
'o'
'j'
'n'
'o'
'b'
```

### A faire 3

Programmer une fonction utilisant **une pile** pour tester si un mot est un
palindrome.


## A une _file_ (first in, first out)

Pour simuler une file, on crée une liste et on la vide par l'avant.

```python
>>> mot = "bonjour"
>>> lettres = list(mot)
>>> lettres
['b', 'o', 'n', 'j', 'o', 'u', 'r']
>>> while lettres != []:
... c.pop(0)   # <----------------- remarquer le 0, vide par l'AVANT
...
'b'
'o'
'n'
'j'
'o'
'u'
'r'
```



### A faire 4

Programmer une fonction utilisant **une file** pour tester si un mot est un
palindrome.


## En limitant les comparaisons à 1 seul caractère.

Jusqu'ici on a comparé tous les mots entre eux. Nos tests pouvaient s'écrire

```python
if mot1 == mot2:
  ...
```

Nous allons nous restreindre **à des mots de taille 1 :**


```python
>>> 'a' == 'b'            # autorisé
False
>>> 'ab' == 'ac'          # interdit
False
```

Comment résoudre le même problème avec cette contrainte supplémentaire ?

* Si on n'autorise qu'une seule structure c'est compliqué.
* Si on autorise plusieurs structures en même temps c'est facile.

    Admettons qu'on ait le droit à `.pop()` et `.pop(0)` en même temps.

    C'est-à-dire une structure qui soit à la fois une pile ET une file.

    ```python
    >>> while len(l) > 1:
    ...   l.pop(0)      # sort le premier
    ...   l.pop()       # sort le dernier
    ...
    'b'
    'r'
    'o'
    'u'
    'n'
    'o'
    ```

### A faire 5

Programmer une fonction utilisant à la fois une **pile** ET une **file**
pour tester qu'un mot est un palindrome.

_On limitera les comparaisons à des chaînes d'un seul caractère._

## Comparer les vitesses.

### Quelques outils pratiques

Le module `string` contient quelques chaînes pratiques :

```python
>>> from string import ascii_lowercase as letters
>>> for c in letters:
...   print(c, end=' ')
...
a b c d e f g h i j k l m n o p q r s t u v w x y z
```

`ascii_lowercase` est la chaîne formée des minuscules de l'alphabet.

Dans le module `random` on trouve `choice` qui permet de choisir un élément
au hasard dans un objet itérable :

```python
>>> from random import choice
>>> choice("Robert")
'o'
>>> choice([1, 42, 'Matou'])
42
```

Appelons **taille** d'un palindrome le nombre de lettres de sa partie "gauche"

* `aa` : taille 1
* `abccba` : taille 3
* `abcdcba` : taille 3 (**on ignore le caractère central**)

_Ce n'est pas une définition universelle (je viens de l'inventer)._

### A faire 6

Programmer une fonction `generer_palindrome` qui prend une taille donnée
et retourne un palindrome aléatoire ayant cette _taille_.

## Mesurer des temps

_La méthode présentée ci-dessous n'est pas rigoureuse._
_Croyez moi, vous n'avez pas envie de programmer la méthode rigoureuse_

Pour mesurer le temps, l'approche la plus simple est de relever 2 fois et soustraire.

Admettons qu'on souhaite mesurer combien de temps prends ce beau calcul

```python
def calculer_dur():
  sum(list(range(1000000)))
```

```python
>>> from time import time
>>> debut = time()       # on lance le chrono
>>> calculer_dur()
>>> fin = time()
>>> fin - debut # contient la durée écoulée (en secondes) !
0.04842782020568848
```

### A faire 7

Effectuez la comparaison des cinq méthodes implémentée plus tôt

* en retournant,
* récursivement,
* avec une pile,
* avec une file,
* avec une pile ET une file,

On utilisera des mots générés aléatoirement avec notre fonction
(cf. **à faire 6**) de taille variable.

**Attention**, la récursion plante après 400/500 appels (on peut régler mais pas
grave).


## Conclusion

Les résultats sont frappants.

Les quatre méthodes créant des objets sont extrêmement lentes devant
la première, qui utilise principalement des outils natifs.

Pourquoi ?

Parce qu'elle ne crée qu'un seul objet, en parcourant très rapidement une
collection.

Dans toutes les autres on crée plusieurs choses (pour la récursion, c'est la
pile de récursion qui ralenti tout).

---

Remarquons que tous ces algorithmes ont une complexité linéaire. Ce qui change
c'est le coefficient...

Mais la différence est conséquente !

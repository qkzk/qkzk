from random import randint
from random import choice


class Chat:
    '''
    Classe représentant les chats.
    Ils font du bruit, se rencontrent et ont des caractéristiques.
    '''

    def __init__(self, nom, age, couleur):
        '''
        Crée un chat avec son nom, son age et sa couleur
        @param nom: (str)
        @param age: (int)
        @param couleur: (str)
        @return: None
        '''
        self.__nom = nom
        self.__age = age
        self.__couleur = couleur

    def miaou(self):
        '''
        Miaulement du chat content.
        @return: (str)
        '''
        chaine = ''
        for i in range(randint(1, 4)):
            chaine += 'miao' + 'u' * randint(1, 5) + ' '
        return chaine.strip()

    def ronron(self):
        '''
        Ronronnement du chat.
        @return: (str)
        '''
        return ('ron-ron-' * randint(2, 4))[:-1]

    def souffler(self):
        '''
        Soufflement du chat mécontent
        @return: (str)
        '''
        return 'ksss' + 's' * randint(3, 7)

    def nom(self):
        '''Retourne le nom du chat'''
        return self.__nom

    def age(self):
        '''Retourne l'age du chat'''
        return self.__age

    def couleur(self):
        '''Retourne la couleur du chat'''
        return self.__couleur

    def rencontrer(self, chat):
        '''Retourne un texte résumant la rencontre entre deux chats'''
        if self is chat:
            return self.miaou()

        elif self.__couleur == chat.__couleur:
            str = self.ronron()
            return str + " {0} aime bien {1}".format(self.nom(), chat.nom())

        else:
            chaine = self.souffler()
            return chaine + " {0} n'aime pas {1}".format(self.nom(), chat.nom())

    def __repr__(self):
        '''Retourne un texte présentant le chat'''
        return "{0} est un chat {2} agé de {1} ans".format(self.nom(),
                                                           self.age(),
                                                           self.couleur())


if __name__ == '__main__':
    horace = Chat("Horace", 7, "blanc")

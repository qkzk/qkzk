__title__ = 'Combat en mode texte'
__author__ = 'qkzk'
__date__ = '2020/02/21'
__doc__ = f'''
titre :  {__title__}
auteur : {__author__}
date :   {__date__}

Module de combat en mode texte avec quelques fonctionnalités

Version terminale:

On utilise des classes
'''


from random import random, randint


class Joueur:
    '''
    crée un joueur
    @param nom: (str) doit être défini
    @param vie: (int) nombre de pv. Valeur par défaut 5
    @param force: (int) force des coups. Valeur par défaut 1
    @return: (dict) un dictionnaire du joueur
    '''
    CHANCE_RATER = 0.2

    def __init__(self, nom, vie, force):
        self.__nom = nom
        # à compléter

    def get_nom(self):
        return self.__nom

    def get_vie(self):
        # à compléter
        pass

    def perdre_vie(self, points):
        # à compléter
        pass

    def __repr__(self):
        # à modifier
        return self.__nom

    def taper(self, adversaire):
        rate = random() < self.CHANCE_RATER
        degats = 0 if rate else randint(1, self.__force)
        message = message = f"{self.__nom} tape {adversaire.get_nom()} et"

        message += f' fait {degats} points de dégâts.'
        return degats, message


def combat(joueur_1, joueur_2):
    '''
    Combat à mort entre joueur_1 et joueur_2
    Le combat dure jusqu'à la mort d'un joueur. On affiche le journal
    de combat dans la console

    @param joueur_1, joueur_2: (dict) les joueurs
    @return: (dict) le vainqueur du combat
    '''
    print(f"\nBagarre entre {joueur_1['nom']} et {joueur_2['nom']} !")
    while joueur_1["vie"] > 0 and joueur_2["vie"] > 0:
        degats, message = taper(joueur_1, joueur_2)
        print(message)
        joueur_2["vie"] -= degats
        if joueur_2["vie"] <= 0:
            break
        degats, message = taper(joueur_2, joueur_1)
        print(message)
        joueur_1["vie"] -= degats

    gagnant, perdant = vainqueur(joueur_1, joueur_2)
    afficher_vainqueur(gagnant, perdant)
    return gagnant


def vainqueur(joueur_1, joueur_2):
    '''
    Retourne un couple avec le gagnant et le perdant d'un combat.

    Exemple :
    >>> vainqueur({vie=5, nom="Marcel"}, {vie=0, nom="Paul"})
    ({vie=0, nom="Paul"}, {vie=5, nom="Marcel"})
    '''
    j1_gagne = joueur_1['vie'] > 0
    gagnant, perdant = (joueur_1, joueur_2) if j1_gagne else (joueur_2, joueur_1)
    return gagnant, perdant


def afficher_vainqueur(gagnant, perdant):
    '''
    Écrit le nom du vainqueur et celui du perdant dans la console.

    Exemple :
    >>> afficher_vainqueur({vie=5, nom="Paul"}, {vie=0, nom="Marcel"})
    Paul a gagné !
    Marcel est mort
    '''
    print(f"{gagnant['nom']} a gagné !")
    print(f"{perdant['nom']} est mort")


if __name__ == '__main__':
    robert = Joueur('Robert', 10, 2)
    amandine = Joueur('Amandine', 10, 2)
    vainqueur = combat(robert, amandine)
    print(vainqueur)
    dagobert = Joueur('Dagobert', 5, 2)
    combat(vainqueur, dagobert)

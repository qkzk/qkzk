from geometrie import *


def tester_tlm():
    # distance
    tester_disque()
    tester_rectangle()
    tester_vecteurs()


def tester_disque():
    # Classe disque
    d1 = Disque(1, 2, 5)
    assert d1.centre() == (1, 2)
    assert d1.rayon() == 5
    assert abs(d1.circonference() - 2 * pi * 5) / 2 * pi * 5 < 10 ** -7
    assert abs(d1.aire() - pi * 5 ** 2) / pi * 5 ** 2 < 10 ** -7
    assert repr(d1) == "Disque de centre (1, 2) et de rayon 5"
    d1.changer_centre(3, 4)

    # Enlevez les commentaires au fur et à mesure.

    # assert d1.centre() == (3, 4)
    # d1.changer_rayon(10)
    # assert d1.rayon() == 10
    # assert d1.contient(0, 0)
    # assert not d1.contient(100, 100)
    # d2 = Disque(10, 5, 2)
    # assert d1.intersecte(d2)
    # d3 = Disque(100, 100, 1)
    # assert not d1.intersecte(d3)


def tester_rectangle():
    # rectangles
    pass
    # Enlevez les commentaires au fur et à mesure.
    # r1 = Rectangle(1, 2, 3, 4)
    # assert r1.x() == 1
    # assert r1.y() == 2
    # assert r1.largeur() == 3
    # assert r1.hauteur() == 4
    # assert repr(r1) == "Rectangle de coin supérieur gauche (1, 2). Largeur 3, hauteur 4"
    # assert r1.perimetre() == 2 * 3 + 2 * 4
    # assert r1.aire() == 3 * 4
    # assert not r1.contient(1, 1)
    # assert r1.contient(2, 3)
    # r2 = Rectangle(2, 3, 1, 1)
    # assert r1.collision(r2)
    # r3 = Rectangle(100, 3, 1, 1)
    # assert not r1.collision(r3)


def tester_vecteurs():
    # Vecteurs
    pass
    # Enlevez les commentaires au fur et à mesure.
    # u = Vecteur(1, 2)
    # assert u.coordonnees() == (1, 2)
    # assert abs(u.norme() - 5 ** 0.5) / (5 ** 0.5) < 10**-8
    # assert repr(u) == "Vecteur de coordonnées (1, 2)"
    # u_1 = Vecteur(1, 2)
    # v = Vecteur(2, 3)
    # assert u == u_1
    # assert not (u == v)
    # assert not (u != u_1)
    # assert u != v
    # assert u + v == Vecteur(3, 5)
    # assert u - v == Vecteur(-1, -1)
    # assert u * v == 1 * 2 + 2 * 3
    # assert u.det(v) == 1 * 3 - 2 * 2
    # assert not u.colineaire(v)
    # assert u.colineaire(Vecteur(2, 4))


if __name__ == '__main__':
    tester_tlm()

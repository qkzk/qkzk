---
title: Terminale NSI - Données
subtitle: Arbres binaires de recherche
date: 2020/04/24
---

## Introduction

Ce TP poursuit celui entamé dans la section précédente.

* Vous disposez pour cela d'un nouveau colab avec le même énoncé
* Vous avez aussi à votre disposition un fichier [parcours.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/arbres/5_tp_abr/parcours.py)
    qui contient les parcours présentés durant la dernière séance.

    Il présente deux méthodes pour les parcours _préfixe, infixe_ et _suffixe_.

    * Celle vue la dernière fois qui utilise une procédure
    * Une méthode plus rapide qui utilise une particularité de Python.

    **Dans tous les cas vous devez connaître ces différents parcours et être capable de les programmer.**

Arbres de recherche
===================

Un _arbre de recherche_, ABR, est un arbre binaire qui va être utilisé
pour réaliser « efficacement » des opérations de recherche d'une
valeur, mais aussi des opérations d'insertion et suppression de
valeurs.

Les valeurs des étiquettes de l'arbre doivent donc appartenir à un
ensemble ordonné.

Caractériser les arbres binaires de recherche
---------------------------------------------

### → _Définition._ Arbre binaire de recherche – ABR ###

Un _arbre binaire_ est un arbre binaire tel que pour tout nœud
d'étiquette _e_ :

* les étiquettes de tous les nœuds de son sous-arbre gauche sont
  inférieures ou égales à _e_, et
* les étiquettes de tous les nœuds de son sous-arbre droit sont
  supérieures à _e_.

### ↦ Des arbres binaires de recherche ###

Indiquez quels sont parmi les arbres suivants ceux qui sont des
arbres binaires de recherche.

![](fig/abr-or-not-1.png)

![](fig/abr-or-not-2.png)



### A faire 1 ↦ Les plus petite et plus grande étiquettes ###

Dans quel nœud d'un arbre binaire de recherche se trouve la plus
petite étiquette ? \
La plus grande ?

Dans quel nœud d'un arbre binaire de recherche se trouve l'étiquette
médiane ?

### A faire 2 ↦ Parcours ordonné ###

Lequel des classiques parcours d'arbres binaires permet de visiter les
nœuds d'un ABR dans l'ordre des étiquettes ?

### A faire 3 ↦ Reconnaître un arbre binaire de recherche ###

Proposez un prédicat Python qui reconnaît si un arbre binaire donné
est un arbre binaire de recherche.

Deux pistes possibles pour cela sont

1. De réaliser un parcours de l'arbre qui devrait visiter les nœuds
   dans l'ordre croissant (exercice précédent), et vérifier que les
   étiquettes sont bien dans l'ordre croissant. \
   _(On suppose qu'il n'y a pas de doublons dan l'arbre.)_

1. De proposer une fonction récursive qui renvoie la plus petite et la
   plus grande des valeurs des étiquettes d'un arbre, et vérifie qu'il
   est un ABR.

Recherche d'une valeur dans un arbre binaire de recherche
---------------------------------------------------------

### A faire 4 ↦ Recherche d'une valeur dans un arbre binaire de recherche ###

Proposez une fonction Python qui renvoie le nœud d'un arbre binaire de
recherche dont l'étiquette est égale à une valeur donnée. \
La fonction pourra retourner `None` si la valeur n'était pas présente
dans l'arbre.

Insertion d'une valeur dans un arbre binaire de recherche
---------------------------------------------------------

L'insertion d'une valeur `v` dans un arbre binaire de recherche peut
reposer sur le déroulé récursif suivant :

* si l'arbre est vide, renvoyer l'arbre arbre constitué d'une unique
  feuille portant la valeur `v`
* si la valeur à insérer `v` est inférieure ou égale à la valeur
  de la racine, renvoyer l'arbre formé de
  - la racine
  - l'arbre formé du fils gauche dans lequel aura été inséré la valeur
	`v`
  - le fils droit
* sinon – la valeur `v` est supérieur à la valeur de la racine –,
  renvoyer l'arbre formé de
  - la racine
  - le fils gauche
  - l'arbre formé du fils droit dans lequel aura été inséré la valeur
	`v`

**Remarque** Pour insérer une valeur _ailleurs_ que dans une feuille il faut
travailler davantage. C'est encore possible mais ça demande de transformer
l'arbre considérablement. Ce n'est clairement pas au programme de Terminale NSI.

### A faire 5 ↦ Insérer une valeur dans un ABR ###

Proposez une fonction Python qui renvoie un arbre binaire de recherche
donné augmenté d'une valeur donnée.

Suppression d'une valeur dans un arbre binaire de recherche
-----------------------------------------------------------

Soit une valeur `v`, nous cherchons à supprimer, s'il exsite, le
nœud d'étiquette `v` dans un arbre binaire de recherche donné.

Passons en revue les différents cas de figure :

* si l'arbre est vide, il n'y a rien à faire
* si l'arbre est réduit à une feuille, selon qu'elle porte cette
  valeur `v` ou non, il s'agit de renvoyer l'arbre vide ou la
  feuille
* si la valeur `v` est inférieure à la racine, à la manière de ce
  que nous avons fait pour l'insertion, reconstruire l'arbre
  formé de
  - la racine,
  - le fils gauche amputé de la valeur `v`
  - le fils droit
* si la valeur est supérieure à la racine, on agit de même,
  symétriquement pour les fils gauche et droit
* si la racine porte la valeur `v` et ne possède qu'un unique fils,
  ce nœud fils devient le nouvel arbre

Reste à traiter la cas où la racine porte la valeur `v` et possède
deux fils.

* considérons le _successeur_ de la racine ; il s'agit du nœud portant
  la plus petite des valeurs supérieures à `v`
* par définition d'un ABR, ce successeur est le nœud le plus à gauche
  du fils droit de la racine
* l'arbre amputé de `v` est donc formé :
  - de la valeur de ce successeur
  - du fils gauche
  - du fils droit amputé de la valeur du successeur.

Une implémentation « efficace » évite de parcourir le fils droit à la
recherche de la valeur du successeur, puis de parcourir le fils droit
pour supprimer le nœud portant cette valeur.

Coût des opérations
-------------------

Les arbres binaires de recherche sont introduits pour répondre au
besoin de réaliser avec la même efficacité les trois opérations de
_recherche_, _ajout_, et _suppression_ d'une valeur.

Chacun des algorithmes que nous avons définis pour ces trois
opérations nécessite de visiter un arbre de sa racine à une feuille,
comparant une valeur à l'étiquette des nœuds visités. \
Le nombre de comparaisons sera donc égal à la _hauteur_ de l'arbre.

Les parcours de la racine à une feuille peuvent être interrompus dans
le cas ou le nœud recherché est un nœud interne.

L'analyse du coût de ces algorithmes se ramène dont à l'étude de la
hauteur des arbres binaires des recherche.

Dans le meilleur des cas, un arbre binaire de recherche est
_équilibré_. Sa hauteur est alors `log_2 n`, `n` étant la taille,
nombre d'éléments, de l'arbre. \
Le coût des algorithmes pour nos trois opérations est alors au pire
logarithmique.

Dans le pire des cas, un arbre binaire de recherche est
_filiforme_. Sa hauteur est alors égale à `n`. \
Le coût des algorithmes pour nos trois opérations est alors au pire
linéaire.

L'analyse du coût en moyenne des algorithmes nécessite de considérer

* la profondeur moyenne d'un nœud dans un arbre binaire de recherche
  quelconque,

et

* la hauteur d'un arbre « moyen » parmi tous les arbres binaires.

Nous ne mènerons pas cette étude ici.

### → _Résultat._ Complexité des algorithmes sur les arbres binaires de recherche ###

La complexité des algorithmes de _recherche_, _insertion_, et
_suppression_ d'une valeur dans un arbre binaire de recherche est

* en moyenne logarithmique,
* au pire linéaire.

Le coût de ces opérations est au pire logarithmique dans le cas d'arbres
de recherche _équilibrés_.

Maintenir l'équilibre
---------------------

Le coût au pire logarithmique des opérations sur les arbres de
recherche équilibrés motive la modification de nos algorithmes pour
tenter de conserver cette propriété d'équilibre des arbres.

Le principe général repose sur des rotations opérées lors de
l'insertion ou la suppression d'une valeur.

On opère des rotations simples comme celles ilustrées ci-dessous,
et des rotations doubles.

![](fig/avl-rot-simple.png)

Ces arbres binaires de recherche équilibrés sont nommés AVL d'après le
nom de leurs inventeurs, Georgii Adelson-Velsky et Evguenii Landis.

---
title: NSI Terminale - Données
subtitle : Entrainement à la programmation objet
author: qkzk
date: 2020/05/14
---

L'objectif de ce TP est de vous familiariser avec la manipulation d'objets
et la création de classes simples.

# Utiliser des classes déjà écrites

Dans cette partie vous n'avez rien à _écrire_ dans le fichier.

Dans le fichier joint [matou.py](matou.py) vous disposez d'une classe
pour représenter les chats.

On peut :

* créer un objet de type `Chat`.
* consulter ses attributs à l'aide d'accesseurs (`nom()`, `age()`, `couleur()`)
* le faire émettre différents sons : `miaou(), ronron(), souffler()`
* le faire rencontrer d'autres chats.

Bon je ne suis pas allé au bout de cette idée mais on pourrait imaginer qu'ils
produisent d'autres bestioles à l'issue de cette rencontre...


**A faire 1 : documentation d'une classe**

Lisez attentivement le code pour le comprendre.

Exécutez le fichier en mode interactif et affichez l'aide de la classe.

```bash
$ python -i matou.py
```

puis

```python
>>> help(Chat)
```

_Commencez-vous à comprendre l'intérêt de la documentation ?_

---

A la fin du code, on a crée un chat : `horace`.

**A faire 2 : intéractions avec Horace.**

* Testez tous ses sons :

    ```python
    >>> horace.ronron()
    ```

* Testez son type,

* Appelez directement `horace` dans la console :

    ```python
    >>> horace
    ```

    Quelle est la méthode qui est exécutée ? Que retourne-t-elle ?

*   Utilisez les méthodes pour connaître les caractéristiques de Horace.

**A faire 3 : instancier des objets**

Lisez le code et créez trois autres chats :

| nom    	| age 	| couleur 	|
|--------	|-----	|---------	|
| Minus  	| 4   	| marron  	|
| Marcel 	| 5   	| marron  	|
| Fanny  	| 3   	| blanc   	|

On prendra soin de nommer les variables en minuscule : `marcel`

**A faire 4 : rencontres**

Faites les se rencontrer avec `minus.rencontre(horace)`

Que se passe-t-il si un chat se rencontre avec lui même ?

A quelle ligne du code est-ce que cela correspond ?

---

# Créer une classe

Dans cette partie vous allez implémenter une classe pour les voitures.

Voici les **attributs** qui seront définis lors de la création des voitures :

*   **couleur** : une chaîne, passée en paramètre lors de la création.
*   **km** : un entier. Le nombre de km au compteur. Lorsqu'on crée la voiture, cet attribut
    vaut 0.
*   **marque** : une chaîne.

On prendra soin de noter les attributs avec `__` afin de les préserver.

Par exemple : `self.__km = 0`

Voici les **méthodes** que vous allez implémenter

*   `__init__` : le **constructeur**. Inspirez-vous des chats.
*   `__repr__` : qui permet d'afficher les informations de la voiture dans
    la console

*   **`marque`**,  **`km`**, **`couleur`** : des accesseurs qui retournent les
    valeurs des attributs.

*   **`presenter`** : Retourne une phrase de keke qui aime un peu trop sa voiture.

*   **`rouler`** : augmente le nombre de km au compteur. Prend un paramètre
    entier : le nombre de km parcourus

*  **`peindre`** : prend une couleur en paramètre et remplace
    l'ancienne couleur.

    ```python
    >>> bmw
    Voiture noire de marque BMW avec 1337 km au compteur
    >>> bmw.peindre('verte')
    >>> bmw
    Voiture verte de marque BMW avec 1337 km au compteur
    ```

*   **`course`** : Faire une course avec une autre voiture. Vous décidez d'un
    critère (aléatoire, absurde, le nombre de km... ce que vous voulez)
    mais on doit avoir un vainqueur.

    Cette méthode prend en paramètre un autre objet de la classe voiture.
    Faîtes planter le programme si on essaye de faire une course avec
    soi même. Vous pouvez utiliser :

    ```python
    raise ValueError(message_d_erreur_a_taper)
    ```

    et définir un message d'erreur qu'un développeur puisse comprendre.


    Chaque course fait 10 km et les compteurs des deux voitures doivent
    augmenter.

    ```python
    >>> bmw.course(ferrari)
    'La BMW noire avec 10 km au compteur a battu la Ferrari'
    >>> bmw.course(bmw)
    Traceback (most recent call last):
      File "<stdin>", line 1, in <module>
      File "voiture.py", line 65, in course
        raise ValueError("Vous devez passer un autre objet Voiture en paramètre")
    ValueError: Vous devez passer un objet Voiture en paramètre
    ```


Si vous ne l'avez pas déjà fait, ajoutez la documentation.

Voici ce qu'on peut lire dans la correction :

```python
>>> help(Voiture)
```
```
Help on class Voiture in module __main__:

class Voiture(builtins.object)
 |  Voiture(couleur, marque)
 |
 |  Classe permettant de manipuler des voitures.
 |  On peut les présenter, les faire rouler et s affronter dans des courses.
 |
 |  Methods defined here:
 |
 |  __init__(self, couleur, marque)
 |      Constructeur.
 |      @param couleur: (str)
 |      @param marque: (str)
 |
 |  __repr__(self)
 |      présente la voiture
 |
 |  couleur(self)
 |      retourne la couleur de la voiture
 |
 |  course(self, voiture)
 |      Fait s affronter deux voitures dans une course.
 |      Retourne une chaine décrivant le résultat de la course.
 |      @param voiture: (Voiture) l adversaire,
 |      @return: (str) le résultat de la course.
 |
 |  km(self)
 |      retourne le kilométrage de la voiture
 |
 |  marque(self)
 |      retourne la marque de la voiture
 |
 |  peindre(self, couleur)
 |      Change la couleur de la voiture
 |
 |  presenter(self)
 |      Retourne une chaîne un peu vulgaire qui parle de la voiture...
 |
 |  rouler(self, km)
 |      Augmente le nombre de kilomètres de la voiture
 |      @param km: (int)
 |      @return: None
 |
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |
 |  __dict__
 |      dictionary for instance variables (if defined)
 |
 |  __weakref__
 |      list of weak references to the object (if defined)


```

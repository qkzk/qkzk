import pylab
# import matplotlib.pyplot as pylab # @windows n'a pas pylab d'installé
import sys
from time import time
from listes_etendue import *

sys.setrecursionlimit(20000)
LE = ListeEtendue


if __name__ == '__main__':
    pass

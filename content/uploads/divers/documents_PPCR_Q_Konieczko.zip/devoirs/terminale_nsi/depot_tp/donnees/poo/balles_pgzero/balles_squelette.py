'''
Script qui illustre quelques propriétés de la programmation objet

On jette 200 disques de rayon 1 de couleurs sur l'écran.
Quelle taille peuvent-ils atteindre avant de s'intersecter ?

Squelette à remplir !
'''

from random import randint
import pgzrun

WIDTH = 600
HEIGHT = 600
TITLE = "BALLES"


class Couleurs:
    '''
    Méthode anonyme permettant de générer des couleurs
    pas d'attribut, des variables de classe
    pas de méthode propres aux instance, mais une méthode de classe.
    '''
    pass


class Balle:
    '''
    Classe des balles
    Implémante une API pour créer et manipuler des balles.
    Méthodes :
    * centre, rayon : renvoient les données du centre (un tuple) ou du rayon (int)
    * montrer: dessine la balle à l'écran
    * intersecter: retourne vrai si une balle intersecte une autre
    * grandir: augmente le rayon si c'est possible (aucune intersection)
    '''

    def __init__(self, x, y, rayon, couleur):
        '''
        Initialise les attributs d'une balle
        @param x, y: (int) les coordonnées
        @param rayon: (int) le rayon
        @param couleur: (tuple) la couleur (format (r, g, b))
        '''
        pass

    def centre(self):
        ''' '''
        pass

    def rayon(self):
        '''
        Retourne la valeur du rayon
        @return: (int)
        '''
        pass

    def montrer(self):
        '''Dessine la balle à l'écran'''
        pass

    def intersecter(self, autre):
        '''
        Vrai si la balle intersecte l'autre balle
        @param autre: (Balle) une autre balle
        @return: (bool)
        '''
        pass

    def grandir(self, balles):
        '''
        Augmente le rayon de 1 si c'est possible (càd si aucune autre balle
        n'est en contact)
        @param balles: (Ball) une autre balle
        @S.E.: modifie la valeur de certains attributs
        '''
        pass


def distance(a, b):
    '''
    Retourne la distance entre deux "points" représenté par des tuples de
    coordonnées
    @param a, b: (tuple) (x, y)
    @return: (float) la distance qui sépare a de b
    '''
    pass


def setup():
    '''
    initialise le tableau des balles aléatoirement
    @return: (list) le tableau des balles.
    '''
    pass


def update():
    '''
    Appelé 60x par seconde par pygame
    Dessine les éléments à l'écran (et lit les événements, mais ici il
    n'y en a pas...)
    '''
    screen.fill((51, 51, 51))


# balles = setup()
pgzrun.go()

def utilisateur(planning, horaire):
    '''
    Retourne le nom de l'utilisateur à une heure donnée.
    Ne retourne rien si aucun utilisateur
    @param planning: (list)
        des dictionnaires de la forme
        'nom': (str)
        'de': (int)
        'à': (int)
    @param horaire: (int)
    @return: (str)
    '''
    pass


def inscrire(planning, nom, horaire):
    '''
    Ajoute un utilisateur au planning.
    Respecte les règles du club.
    @param planning: (list) contient des dictionnaires
    @param nom: (str)
    @param horaire: (int)
    '''
    pass


def libre(planning, horaire):
    '''
    Retourne Vrai ssi le terrain est libre à l'horaire demandé
    @param planning: (list) contient des dictionnaires
    @param horaire: (int)
    @return: (bool)
    '''
    pass


def deja_inscrit(planning, horaire, nom):
    pass


def formater_inscription(nom, horaire):
    pass


def duree_attente(planning, horaire):
    pass

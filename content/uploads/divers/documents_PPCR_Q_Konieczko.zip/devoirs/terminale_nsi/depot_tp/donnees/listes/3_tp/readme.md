---
title: NSI Terminale - Structure de données
subtitle: 'TD: Comparaison des vitesses'
date: 2020/05/15
author: qkzk
theme: metropolis
geometry: margin=1.5cm
---

# Où en sommes-nous ?

* Nous avons crée une structure de donnée pour les listes chaînées
* On peut créer une liste vide ou contenant un élément de tête et une liste de queue
* Vous pouvez visualiser dans [python tutor](http://pythontutor.com/visualize.html#code=class%20ListeError%28Exception%29%3A%0A%20%20%20%20%22%22%22%0A%20%20%20%20Exception%20utilis%C3%A9e%20par%20les%20m%C3%A9thodes%0A%0A%20%20%20%20*%20%60%60__init__%60%60%0A%20%20%20%20*%20%60%60tete%60%60%0A%20%20%20%20*%20%60%60queue%60%60%0A%0A%20%20%20%20de%20la%20classe%20%3Aclass%3A%60List%60.%0A%20%20%20%20%22%22%22%0A%0A%20%20%20%20def%20__init__%28self,%20msg%29%3A%0A%20%20%20%20%20%20%20%20self.message%20%3D%20msg%0A%0A%0Aclass%20Liste%3A%0A%20%20%20%20def%20__init__%28self,%20*args%29%3A%0A%20%20%20%20%20%20%20%20if%20args%20%3D%3D%20%28%29%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20self.contenu%20%3D%20None%0A%20%20%20%20%20%20%20%20elif%20len%28args%29%20%3D%3D%202%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20if%20not%20isinstance%28args%5B1%5D,%20Liste%29%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20raise%20ListeError%28%22Le%20second%20%C3%A9l%C3%A9ment%20doit%20%C3%AAtre%20un%20objet%20Liste%22%29%0A%20%20%20%20%20%20%20%20%20%20%20%20self.valeur_tete%20%3D%20args%5B0%5D%0A%20%20%20%20%20%20%20%20%20%20%20%20self.liste_queue%20%3D%20args%5B1%5D%0A%20%20%20%20%20%20%20%20%20%20%20%20self.contenu%20%3D%20%28self.valeur_tete,%20self.liste_queue%29%0A%20%20%20%20%20%20%20%20else%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20raise%20ListeError%28%22Les%20objets%20Liste%20prennent%200%20ou%202%20param%C3%A8tres.%22%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%22%20%7B%7D%20objets%20transmis%22.format%28len%28args%29%29%29%0A%0A%20%20%20%20def%20est_vide%28self%29%3A%0A%20%20%20%20%20%20%20%20return%20self.contenu%20is%20None%0A%0A%20%20%20%20def%20tete%28self%29%3A%0A%20%20%20%20%20%20%20%20if%20self.est_vide%28%29%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20raise%20ListeError%28%22Une%20liste%20vide%20n'a%20pas%20de%20t%C3%AAte%22%29%0A%20%20%20%20%20%20%20%20else%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20return%20self.valeur_tete%0A%0A%20%20%20%20def%20queue%28self%29%3A%0A%20%20%20%20%20%20%20%20if%20self.est_vide%28%29%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20raise%20ListeError%28%22Une%20liste%20vide%20n'a%20pas%20de%20queue%22%29%0A%20%20%20%20%20%20%20%20else%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20return%20self.liste_queue%0A%0A%20%20%20%20def%20__repr__%28self%29%3A%0A%20%20%20%20%20%20%20%20if%20self.est_vide%28%29%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20return%20'%28%29'%0A%20%20%20%20%20%20%20%20else%3A%0A%20%20%20%20%20%20%20%20%20%20%20%20return%20'%28'%2Brepr%28self.tete%28%29%29%2B'.'%2Brepr%28self.queue%28%29%29%2B'%29'%0A%20%20%20%20%20%20%20%20%20%20%20%20%0Aif%20__name__%3D%3D'__main__'%3A%0A%20%20%20%20l%20%3D%20Liste%281,%20Liste%282,%20Liste%283,%20Liste%28%29%29%29%29&cumulative=false&curInstr=32&heapPrimitives=nevernest&mode=display&origin=opt-frontend.js&py=3&rawInputLstJSON=%5B%5D&textReferences=false)
  l'exécution de notre travail jusqu'ici.



# Mutabilité

Rappelons le principe : un objet composé est _mutable_ si on peut en
_modifier le contenu_.

Dans un précédent TP nous avons crée une structure de donnée `Liste`
qui implémente les listes chaînées. Elles ne sont pas mutables : une fois
définies elles ne peut évoluer.

Quelles sont les opérations que nous pourrions implémenter ? Quelles sont
les opérations manquantes ?

Voici ce que nous souhaitons faire :

* mesurer la longueur d'une liste,
* ajouter un élément à la fin de la liste,
* récupérer l'élément d'indice donné,
* savoir si la liste contient un élément donné,
* retourner une liste.

_Remarque_ : Lorsque nous passerons à l'implémentation, nous allons aussi ajouter les méthodes
suivantes :

* transformer notre liste en une liste Python
* implémenter quelques _méthodes magiques_ afin d'utiliser les opérateurs habituels

  * `len`,
  * `liste[3]` qui retourne l'élément d'indice 3,
  * `liste[1] + liste[2]` qui concatène deux listes,
  * Itérer sur les listes : `for x in liste: ...`
  * Créer depuis une liste Python.



## Travaux dirigés

Rédiger un algorithme papier pour les premiers points :

1. mesurer la longueur d'une liste,
2. ajouter un élément à la fin de la liste,
3. récupérer l'élément d'indice donné,
4. savoir si la liste contient un élément donné,
5. retourner une liste.
6. effacer un élément de position donnée.

Attention, vous vos algorithmes doivent être récursifs.

_Si on me demandait d'inventer un sujet de bac c'est le premier auquel je penserais._

## Travaux pratiques - Première partie

Vous disposez :

* d'un fichier [listes.py](listes.py) qui contient notre travail
  à l'issue de la séance précédente.
* d'un fichier [listes_etendues.py](listes_etendues.py) qui implémente une
  classe qui hérite des listes.

  Les premières fonctions sont déjà présentes, sous forme de squelette.

  Il ne reste plus qu'à les implémenter !

**Votre travail consiste à implémenter les algorithmes proposés précédemment.**

* Vous créez donc une méthode par algorithme et l'implémentez.
* Vous testez chaque méthode.

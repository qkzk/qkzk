class ListeError(Exception):
    """
    Exception utilisée par les méthodes

    * ``__init__``
    * ``tete``
    * ``queue``

    de la classe :class:`List`.
    """

    def __init__(self, msg):
        self.message = msg


class Liste:
    '''
    Classe pour les listes

    Doit implémenter les méthodes :

    * __init__ (constructeur)
    * est_vide
    * tete
    * queue
    * __repr__
    '''
    pass


def exemple():
    '''tester toutes les méthodes ici'''
    l1 = Liste()
    print(l1)


if __name__ == '__main__':
    exemple()

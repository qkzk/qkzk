class Cellule:
    '''Une cellule d'une pile'''

    def __init__(self, valeur, suivant):
        self.__valeur = valeur
        self.__suivant = suivant

    def valeur(self):
        '''accesseur de la valeur'''
        pass

    def suivant(self):
        '''accesseur de la suite'''
        pass


class Pile:
    '''implémante une pile'''

    def __init__(self):
        self.__cellule = None

    def est_vide(self) -> bool:
        '''predicat vrai ssi la pile est vide'''
        pass

    def empiler(self, valeur):
        '''ajoute un élément à la pile'''
        pass

    def depiler(self):
        '''renvoie le sommet de la pile et le dépile'''
        if self.est_vide():
            raise TypeError("La pile est vide")
        pass

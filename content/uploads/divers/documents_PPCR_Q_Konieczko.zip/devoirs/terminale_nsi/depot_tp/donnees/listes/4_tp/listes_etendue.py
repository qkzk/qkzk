__title__ = "Classe Liste Étendue"
__author__ = "qkzk"
__date__ = "2020/05/16"
__doc__ = '''
titre  :   {0}
auteur :   {1}
date   :   {2}

Implémentation d'une classe qui hérite de Liste et ajoute la mutabilité :

Sont implémentés :

* ajouter (à la fin = append)
* longueur,
* get,
* vers une liste python,
* retourner,
* effacer,
* insérer,

'''.format(__title__, __author__, __date__)


from listes import *


class ListeEtendue(Liste):
    '''
    Extension de la classe liste afin de la rendre mutable


    '''

    def __nlle_tete(self, valeur):
        '''
        Ajoute une tête à une liste vide
        '''
        if not self.est_vide():
            raise ListeError("Vous ne pouvez modifier qu'une liste vide")
        self.valeur_tete = valeur

    def __nlle_queue(self, liste):
        '''
        Ajoute une queue à une liste vide
        '''
        if not self.est_vide():
            raise ListeError("Vous ne pouvez modifier qu'une liste vide")
        assert isinstance(liste, ListeEtendue)
        self.liste_queue = liste

    def ajouter(self, valeur):
        '''
        Aujoute une valeur à la fin de la liste
        @param valeur: (any)
        @return: None

        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.ajouter(4)
        >>> liste
        (0.(1.(2.(3.(4.())))))
        '''
        if self.est_vide():
            self.__nlle_tete(valeur)
            self.__nlle_queue(ListeEtendue())
            self.contenu = (self.valeur_tete, self.liste_queue)
        else:
            self.queue().ajouter(valeur)

    def longueur(self):
        '''
        Retourne la longueur de la liste.
        @return: (int)
        >>> LE = ListeEtendue
        >>> LE().longueur()
        0
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.longueur()
        4
        '''
        if self.est_vide():
            return 0
        return 1 + self.queue().longueur()

    def get(self, position):
        '''
        Retourne l'élément d'indice donné dans la liste
        @param position: (int)
        @SE: lève une exception Liste.ListeError si la liste
             n'est pas assez grande.
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.get(2)
        2
        '''
        if position == 0:
            return self.tete()
        else:
            return self.queue().get(position - 1)

    def contient(self, valeur):
        '''
        Vrai ssi valeur est dans la liste
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.contient(0)
        True
        >>> liste.contient(1)
        True
        >>> liste.contient(4)
        False
        '''
        if self.est_vide():
            return False
        elif self.tete() == valeur:
            return True
        else:
            return self.queue().contient(valeur)

    def vers_liste_python(self):
        '''
        Retourne un objet Python List avec les mêmes éléments
        @return: List
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.vers_liste_python()
        [0, 1, 2, 3]
        >>> LE().vers_liste_python()
        []
        '''
        if self.est_vide():
            return []
        else:
            return [self.tete()] + self.queue().vers_liste_python()

    def retourner(self):
        '''
        Retourne la liste.

        Cet algorithme n'est pas récursif.
        @return: (ListeEtendue)
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> retournee = liste.retourner()
        >>> retournee
        (3.(2.(1.(0.()))))
        '''
        elems = self.vers_liste_python()
        retournee = ListeEtendue()
        while elems:
            valeur = elems.pop()
            retournee.ajouter(valeur)
        return retournee

    def retourner_rec(self, retournee=None):
        '''
        Retourne la liste.

        Version récursive.
        @return: (ListeEtendue)
        >>> LE = ListeEtendue
        >>> liste = LE(0, LE(1, LE(2, LE(3, LE()))))
        >>> liste.retourner_rec()
        (3.(2.(1.(0.()))))
        '''
        if retournee is None:
            retournee = ListeEtendue()

        if self.est_vide():
            return retournee

        else:
            retournee = ListeEtendue(self.tete(), retournee)
            return self.queue().retourner_rec(retournee=retournee)

    def effacer(self, position):
        '''Efface l'élément à la position donnée'''
        if position == 0:
            if self.queue().est_vide():
                self.valeur_tete = None
                self.liste_queue = None
                self.contenu = None
            else:
                self.valeur_tete = self.queue().tete()
                self.liste_queue = self.queue().queue()
                self.contenu = (self.valeur_tete, self.liste_queue)
        else:
            self.queue().effacer(position - 1)

    def inserer(self, position, valeur):
        '''
        insère un élément à une position donnée
        @param position: (int) > 0 !!!
        @param valeur: (any)
        '''
        if position == 0:
            raise ValueError("Vous ne pouvez insérer en tête")
        if position == 1:
            self.liste_queue = ListeEtendue(valeur, self.queue())
            self.contenu = (self.valeur_tete, self.liste_queue)
        else:
            self.queue().inserer(position - 1, valeur)


def exemple():

    LE = ListeEtendue
    liste = LE(0, LE(1, LE(2, LE(3, LE()))))

    print(liste.longueur())

    print(liste)
    liste.ajouter(4)
    print(liste)

    print(liste.get(2))

    print(liste.contient(0))
    print(liste.contient(1))
    print(liste.contient(4))
    print(liste.contient(5))

    print(liste.vers_liste_python())

    print(liste.retourner())

    # print(liste.get(5))
    print(len(liste))
    print(liste[2])
    print("iter")
    somme = 0
    for x in liste:
        somme += x
    print(somme)
    print(sum(liste))

    print(liste + liste)
    print(liste)

    l = LE.depuis_liste_python([1, 2, 3])
    print(l)

    print(l.retourner_rec())

    l.effacer(2)
    print(l)

    l.effacer(0)
    print(l)

    del l[0]

    print(l)

    print("insertion")
    l = LE(0, LE(2, LE()))
    l.inserer(1, 1)
    print(l)
    # print(l)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    exemple()

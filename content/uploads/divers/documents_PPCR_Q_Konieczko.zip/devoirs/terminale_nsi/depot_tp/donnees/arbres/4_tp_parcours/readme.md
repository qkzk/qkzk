---
title: Terminale NSI - Données
subtitle: Arbres binaires - Utilisation d'une classe
author: qkzk
date: 2020/04/24
---

# Utilisation d'une classe pour représenter les arbres binaires

Dans le TP précédent, nos arbres étaient représentés par des _tuples_.
Cela ne pose pas de problème tant qu'on sait ce qu'on fait...
et tant qu'on ne va pas trop loin.

Cela devient problématique dès qu'on expérimente un peu :

* les objets crées n'ont jamais le bon type. Ils sont des _tuples_,
* certaines opérations interdites deviennent possibles, comme créer un arbre binaire qui n'a pas le bon nombre d'élements.
* Les erreurs sont plus difficiles à repérer.

## Utiliser une classe pour représenter les arbres.


La classe `BinaryTree`, définie dans le
[module `binary_tree.py`](binary_tree.py) proposé ici, permet de
représenter des arbres binaires.

Cette classe fournit

* « deux » constructeurs : `BinaryTree()` et `BinaryTree(data, left, right)`
* trois accesseurs : `get_data()`, `get_left_subtree()`, et
  `get_right_subtree()`
* un reconnaisseur : `is_empty()`

Ce module propose aussi des fonctionnalités de visualisation d'arbres
binaires, et d'exportation aux formats DOT et PNG.

## 1. Essais

Chargez le colab associé à ce TD dans votre navigateur et essayez les différentes méthodes.

Il est parfaitement possible de faire ce TP "localement" sur vos machines.

Mais... visualiser les arbres (générer les images associées) pose problème. Il faut installer encore des logiciels.

Si ça fonctionne localement, tant mieux. Sinon, faîtes le dans colab.


### A faire 1.

Créez l'arbre suivant en mémoire et dessinez le


![arbre_123456789](img/arbre_123456789.png)

## Parcourir d'abord.

Imaginons l'arbre suivant :

![arbre_abcdefg](img/arbre_abcdefg.png)

Parcourir un arbre:

> C'est **retourner la liste des noeuds de l'arbre dans un certain ordre.**
>
> On distingue deux parcours principaux : en **profondeur** ou en **largeur**.
>
> Il existe trois parcours en profondeur : _préfixe, infixe, suffixe_.

## Parcours en largeur.

Si vous suivez l'ordre alphabétique pour décrire les sommets de l'arbre,
vous obtenez :

`A, B, C, D, E, F, G`

Qui correspondent à un parcours :

1. de haut en bas,
2. en suivant les niveaux,

**C'est un parcours en largeur d'abord**

### Algorithme du parcours en largeur


On initialise une file vide `Q` avec la racine.

Tant que la file `Q` n'est pas vide, faire :

* on défile un élément `courant`,
* on ajoute tous les somments adjacents de `courant` à la file,
* on marque `courant` comme visité (on peut l'ajouter à une liste `visite`)

On retourne `visite`

### Parcours en largeur sur `arbre_abcdefg`

Parcours en largeur sur cet exemple :

```
0. On initialise la file :            Q = [A]
1. On défile courant = A              Q = []

    * on ajoute tous les sommets adjacents de A à la file
                                      Q = [B, C]
    * on marque courant comme visité :
                visites = [A]
2. On défile courant = B              Q = [C]

    * on ajoute tous les sommets adjacents de B à la file
                                      Q = [C, D, E]
    * on marque courant comme visité :
                visites = [A, B]
3. On défile courant = C              Q = [D, E]

    * on ajoute tous les sommets adjacents de C à la file
                                      Q = [D, E, F, G]
    * on marque courant comme visité :
                visites = [A, B, C]
4. On défile courant = D              Q = [E, F, G]

    * on ajoute tous les sommets adjacents de D à la file
       (il n'y en a pas !)            Q = [E, F, G]
    * on marque courant comme visité :
                visites = [A, B, C, D]
5. On défile courant = E              Q = [F, G]

    * on ajoute tous les sommets adjacents de E à la file
       (il n'y en a pas !)            Q = [G]
    * on marque courant comme visité :
                visites = [A, B, C, D, E]
6. On défile courant = F              Q = []

    * on ajoute tous les sommets adjacents de G à la file
       (il n'y en a pas !)            Q = []
    * on marque courant comme visité :
                visites = [A, B, C, D, E, G]

La file Q est vide, on s'arrête.

On retourne visites = [A, B, C, D, E, G]
```

---

L'ordre obtenu correspond bien à celui :

1. de gauche à droite (d'abord),
2. de haut en bas (ensuite)

Comme si on lisait les sommets de l'arbre naturellement.

C'est **le parcours en largeur d'abord**.

**Parcours en largeur:**

> On visite tous les sommets d'un même niveau
> **AVANT** de descendre plus profond dans l'arbre,
>
> On visite entièrement un niveau avant de descendre

### Implémenter le parcours en largeur.

Ce parcours nécessite une file (FIFO) pour être implémenté.\
Nous l'implémenterons après avoir vu les autres parcours.

## Parcours en profondeur

Le principe d'un parcours en _profondeur_ est de descendre dans l'arbre
le plus profondément possible AVANT de parcourir les sommets d'un même niveau.

Reprenons l'exemple précédent :


![arbre_abcdefg](img/arbre_abcdefg.png)

### Trois parcours possibles


1. Parcours _préfixe_

    Il semble naturel de citer le sommet AVANT de descendre d'un étage,
    commençons par ça :

    On obtient : `A, B, D, E, C, F, G`

    Qu'est ce qu'on a fait ?

    Pour chaque sommet rencontré :

    1. **Citer le sommet !**
    1. Visiter son fils gauche,
    1. Visiter son fils droit,


    C'est ce qu'on appelle un parcours _préfixe_

    On cite le sommet AVANT de visiter les fils.

2. Parcours _infixe_

    Si on change l'ordre des étapes 1, 2, 3, on obtient un parcours différent :

    Par exemple pour :

    Pour chaque sommet rencontré :

    1. Visiter son fils gauche,
    1. **Citer le sommet !**
    1. Visiter son fils droit,

    On obtient alors :  `D, B, E, A, F, C, G`



    C'est ce qu'on appelle un parcours _infixe_

    On cite le sommet ENTRE les visites des fils gauche et droit.

3. Parcours _suffixe_

      Enfin pour cet ordre :

      Pour chaque sommet rencontré :

      1. Visiter son fils gauche,
      1. Visiter son fils droit,
      1. **Citer le sommet !**

      On obtient alors :  `D, E, B, F, G, C, A`

      C'est ce qu'on appelle un parcours _suffixe_ (ou _postfixe_)

      On cite le sommet APRÈS les visites des fils gauche et droit.


### Pourquoi plusieurs parcours ?

Cela peut surprendre mais ces trois parcours ont des applications.

* Le parcours préfixe est utilisé lors d'une exploration de labyrinthe :

  _à chaque nouvelle pièce rencontrée : est-ce la sortie ?_
* le parcours infixe est utilisé lorsqu'on cherche la présence d'une clé dans l'arbre.
    Couplé à un bon algorithme (dichotomie) et à un remplissage adapté de l'arbre
    c'est ce qui conduit aux résultats les plus rapides (à ma connaissance).
* le parcours suffixe est utilisé par les compilateurs informatiques pour traduire
    une expression en langage machine.

    `(3 + x) * (2 + y)` -> arbre -> langage machine

    ![arbre `(3 + x) * (2 + y)`](img/arbre_operation.png)

    L'immense intérêt de cette méthode est qu'il n'est pas nécessaire d'avoir de parenthèses dans l'expression.

    C'est ce qu'on appelle la _notation polonaise inverse_ (NPI).

    Pour l'expression notée "naturellement" : `(3 + x) * (2 + y)` cela donne :

    `3 x + 2 y + *`

    qui correspond bien au parcours suffixe de l'arbre.
    Pour écrire une telle opération, il suffit de d'écrire les opérateurs (`+, *`)
    APRÈS les opérandes (`3, x, 2, y`).


### Algorithmes des parcours en profondeur


Les trois parcours en profondeur d'abord se traitent facilement avec un aglorithme
récursif :

1. **Parcours préfixe**

    ```
    visiterPréfixe(Arbre A) :
        visiter (A)
        Si nonVide (gauche(A))
              visiterPréfixe(gauche(A))
        Si nonVide (droite(A))
              visiterPréfixe(droite(A))
    ```
2. **parcours infixe**

    ```
    visiterInfixe(Arbre A) :
        Si nonVide(gauche(A))
           visiterInfixe(gauche(A))
        visiter(A)
        Si nonVide(droite(A))
           visiterInfixe(droite(A))
    ```


3. **parcours postfixe**

    ```
    visiterPostfixe(Arbre A) :
      Si nonVide(gauche(A))
        visiterPostfixe(gauche(A))
      Si nonVide(droite(A))
        visiterPostfixe(droite(A))
      visiter(A)
    ```

### A faire 2 : Exemple



On considère l'arbre suivant :

![arbre_123456789](img/arbre_123456789.png)

Donner les sommets dans l'ordre

1. largeur d'abord,
2. préfixe,
3. infixe,
4. suffixe

# Implémentation

Nous allons implémenter tous les parcours.

## Un exemple :

Pour l'arbre ci-dessous, voici les ordres qu'on doit obtenir :

```python
arbre_abcdefg = bt.BinaryTree(
  "a",
  bt.BinaryTree(
    "b",
    feuille("d"),
    feuille("e"),
  ),
  bt.BinaryTree(
    "c",
    feuille("f"),
    feuille("g")
  )
)

largeur = ['a', 'b', 'd', 'e', 'c', 'f', 'g']
prefixe = ['a', 'b', 'd', 'e', 'c', 'f', 'g']
infixe = ['d', 'b', 'e', 'a', 'f', 'c', 'g']
suffixe = ['d', 'e', 'b', 'f', 'g', 'c', 'a']
```

![arbre arbre_abcdefg](img/arbre_abcdefg.png)


## Implémenter le parcours en largeur

1. On doit utiliser une _file_. Parce qu'il est plus facile de
    travailler avec des objets `list` on utilisera une liste appelée `fifo`
    On doit se limiter aux opérations :

    * enfiler : `fifo.append( ... )`
    * défiler : `fifo.pop(0)`
    * la file est-elle vide ? : `fifo == []`

    Pour débugguer vous pouvez afficher le contenu de votre file.
2. Que doit-on ajouter à cette file ?\
      Sûrement pas _la valeur contenue_ : il faut lui ajouter l'_arbre_
3. On doit remplir une liste avec les sommets visités. C'est aussi ce qu'il faut retourner.


### A faire 3

Complétez le code de `parcours_largeur`.

Votre fonction prend en paramètre un arbre (`BinaryTree`) et retourne une liste
de feuilles.

## Implémenter les parcours en profondeur


### A faire 4

Il se fait le plus facilement de manière _récursive_.

1. Traduire en python le premier algorithme (du parcours prefixe)

    On l'englobe dans une _procédure_ `procedure_prefixe` à laquelle on passe
    deux paramètres :

      1. l'arbre (`BinaryTree`)
      2. un tableau vide appelé `visites`

    Cette procédure s'appelle elle même deux fois.
    Une fois qu'elle a été exécutée, on affiche `visites`.
    Il doit maintenant contenir les sommets dans le bon ordre.

2. Créer une fonction `parcours_prefixe`

    * Elle prend un paramètre `arbre` (`BinaryTree`),
    * Elle crée un tableau vide appelé `visites`,
    * Elle appelle la procédure en question avec les paramètre souhaités,
    * Elle retourne `visites` (qui doivent être dans le bon ordre).



Une fois vos résultats testés, créer les deux autres parcours de la même
manière.

**Remarque** on peut parfaitement le faire dans une seule fonction,
mais ça me parait plus facile à comprendre comme ça.

### A faire 5. Avec une pile

Il est possible d'obtenir un parcours en profondeur de manière _impérative_
(c'est-à-dire) _sans récursion_ en adaptant légèrement le parcours en largeur.

* On a utilisé une _file_, que se passe-t-il si on utilise une pile _lifo_
    (le dernier entré sort en premier)
* Que doit-on changer dans la fonction `parcours_largeur` pour remplacer la
    _file_ par une _pile_ ?
* programmer une parcours en profondeur d'abord de cette manière.
* Essayez les deux ordres dans lequel on remplit la pile :

    * d'abord le fils droit, ensuite le fils gauche,
    * le contraire

  Obtient-on le même ordre ?

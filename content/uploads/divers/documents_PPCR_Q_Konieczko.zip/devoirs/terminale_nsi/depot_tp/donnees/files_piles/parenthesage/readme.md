---
title: "NSI - Terminale"
subtitle: "Structure de donnée : Pile - Parenthésage"
author: "qkzk"
date: "2020/10/23"
theme: metropolis
geometry: margin=1.5cm

---

# Vérifier qu'une expression est correctement parenthésée

Il nous est facile de vérifier que les expressions `(x + 2)(x - 3)` et `[1/(x + 4)]`
sont correctement parenthésées tandis que `(x-2))` ou `((x + 2)` ne le sont pas.

Mais comment procède la machine quand elle nous met en surbrillance une
parenthèse incorrecte ?

## Algorithme

Le principe est d'utiliser une _pile_.

On lit l'expression, contenue dans une chaîne de caractère et, pour chaque
parenthèse rencontrée, on empile les parenthèses ouvrantes.

Chaque fois qu'on rencontre une parenthèse fermante, on dépile.

Si les deux parenthses ne se correspondent pas, l'expression n'est pas
parenthésée correctement.

Une fois la boucle terminée, la pile doit être vide.

Si c'est le cas, l'expression est correctement parenthésée.

## Exemple

Considérons l'expression : `(x+2)(x-3)`

Voici le déroulé étape par étape :

| parenthèse | état de la pile | action                  | comparaison |
|------------|-----------------|-------------------------|-------------|
| `(`        | vide            | empiler                 | -           |
| `)`        | `(`             | dépiler `(` et comparer | juste       |
| `(`        | vide            | empiler                 | -           |
| `)`        | `(`             | dépiler `(` et comparer | juste       |

La boucle est terminée et la pile est maintenant vide, l'expression
est bien parenthésée.

## A faire : à la main

Traiter les trois autres exemples donnés à la main :

* `[1/(x + 4)]`
* `(x-2))`
* `((x + 2)`

## A faire : Implémentation

1. Implémenter une classe `Pile` avec les méthodes :

    * `est_vide`
    * `empiler`
    * `depiler`
    * `__repr__`

2. Écrire une fonction `bien_parenthesee_simple` qui prend en paramètre une
    chaîne de caractère et renvoie un booléen vrai ssi l'expression est
    bien parenthésée.

    Dans cette version, on ne traitera que les parenthèses `( )`

3. Proposer un jeu de tests pour la vérifier.

4. Améliorer votre version en `bien_parenthesee` qui a la même signature
    mais traite aussi les autres parenthèses : `[], {}, <>`

# Parser du code HTML

Cette partie est plus délicate.

L'objectif est de s'assurer que les balises html ouvrantes et fermantes
sont bien organisées.

On se contente de texte html dans lesquels :

* Le code est convenablement écrit, : toutes les balises commencent par `<` et se terminent par `>`.
* Les seuls `<` et `>` sont ceux des balises elles-mêmes (pas de `>` dans les attributs, pas de CSS ni de JS)
* aucun attribut n'est présent dans les balises :
    * `<p>bonjour</p>` est autorisé,
    * `<p class="mon_paragraphe">bonjour</p>` ne l'est pas.
* La première ligne `<DOCTYPE>` est absente.

L'algorithme est sensiblement le même.

## À faire : Implémentation

Programmer une fonction `html_bien_formate` qui prend un texte html respectant
les contraintes énoncées plus haut et répond vrai ssi celui-ci est bien formaté.

### Remarques

* Il faut faire attention aux balises [auto-fermantes](http://xhtml.le-developpeur-web.com/balise_autofermante-xhtml.php).
    Le plus simple est de les ignorer lorsqu'on les rencontre.

* On pourra commencer par découper le texte selon les symboles `<` puis `>` avec
    la méthode `split` des chaînes de caractères.

* La méthode `strip` des chaînes de caractères permet de se débarasser
    des espaces et retours à la ligne et début et fin de chaîne.

* Une classe permettant de gérer les balises peut s'avérer utile.

    Dans ma version j'ai utilisé les méthodes :

    * `est_ouvrant`
    * `est_auto_fermant`
    * `get_tag` qui renvoie le tag qu'elle contient
    * `est_correspondant` qui prend une balise et répond vrai ssi l'une est la
        fermante de l'autre.
    * `__repr__`

## Fonction de test possible

```python
def tester():
    '''teste les méthodes et fonctions'''

    texte = '''
        <html>
            <head>
                <title>Dsqf</title>
            </head>
            <body>
                <div>
                    bla
                    <br/>
                    blabla
                </div>
            </body>
        </html>
    '''
    assert html_bien_formate(texte)
    texte = '''
        <html>
            <head>
                <title>Dsqf</title>
            <body>
            </head>
                body
            </body>
        </html>
    '''
    assert not html_bien_formate(texte)
    texte = '''
        <html>
            <head>
                <title>Dsqf</title>
            </head>
            <body>
                body
            </body>
    ''' 
    assert not html_bien_formate(texte)

```



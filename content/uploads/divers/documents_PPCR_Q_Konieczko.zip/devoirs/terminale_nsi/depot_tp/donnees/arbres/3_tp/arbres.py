#!/usr/bin/python3
# -*- coding: utf-8 -*-

__author__ = 'qkzk'
__date_creation__ = '2020/04/23'
__doc__ = """
:mod:`arbres_listes` module
:author: {:s}
:creation date: {:s}
:last revision:

Fonctions de base permettant de manipuler les arbres binaires.

Propose aussi deux présentations affichables dans la console :

* avec des listes,
* à la manière de la commande tree d'unix

""".format(__author__, __date_creation__)
VIDE = ()


def est_vide(arbre):
    '''Prédicat. True ssi l'arbre est vide'''
    return len(arbre) == 0


def contenu(arbre):
    '''Retourne le contenu. Lève une exception si l'arbre est vide'''
    if est_vide(arbre):
        raise TypeError("L'arbre vide n'a pas de contenu")
    else:
        return arbre[0]


def gauche(arbre):
    '''Retourne le sous arbre gauche. Lève une exception si l'arbre est vide'''
    if est_vide(arbre):
        raise TypeError("L'arbre vide n'a pas d'arbre gauche")
    else:
        return arbre[1]


def droit(arbre):
    '''Retourne le sous arbre droit. Lève une exception si l'arbre est vide'''
    if est_vide(arbre):
        raise TypeError("L'arbre vide n'a pas d'arbre droit")
    else:
        return arbre[2]


def presenter(arbre):
    '''Retourne une forme imprimable de l'arbre'''
    return str(arbre)


def dessin(arbre, prefix=""):
    '''
    Retourne un dessin imprimable de l'arbre.
    S'inspire de la fonction `tree` d'UNIX.
    Utilise un algorithme récursif.
    '''
    if est_vide(arbre):
        return ''
    else:
        txt = ''
        if prefix == "":
            txt += str(contenu(arbre)) + '\n'

        contenu_gauche = formater_contenu(gauche(arbre))
        txt += prefix + "├── " + contenu_gauche + '\n'
        txt += dessin(gauche(arbre), prefix + "│   ")

        contenu_droit = formater_contenu(droit(arbre))
        txt += prefix + "└── " + contenu_droit + '\n'
        txt += dessin(droit(arbre), prefix + "    ")

        return txt


def formater_contenu(arbre):
    return '∆' if est_vide(arbre) else str(contenu(arbre))


def presenter_exemple():
    exemple = (1,
               (2, (4, VIDE, VIDE,), (5, VIDE, VIDE,)),
               (3, (6, VIDE, VIDE,), (7, VIDE, VIDE,)),)

    print("exemple :", presenter(exemple))
    print(dessin(exemple))
    print("vide ?".ljust(17), ":", est_vide(exemple))
    print("contenu".ljust(17), ":", contenu(exemple))
    print("sous arbre gauche".ljust(17), ":", gauche(exemple))
    print("sous arbre droit".ljust(17), ":", droit(exemple))

    print()
    print("arbre vide              :", VIDE)
    print("contenu de l'arbre vide :")
    try:
        contenu(VIDE)
    except TypeError as e:
        print(repr(e))


if __name__ == '__main__':
    presenter_exemple()

import sys

print(sys.argv)                             # affiche tous les paramètres

if len(sys.argv) > 1:                       # l'utilisateur a tapé un paramètre
    expression = sys.argv[1]                # expression : le premier argument
    token = expression.strip().split()      # découpe l'expression en une liste
    print(token)

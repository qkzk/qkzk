---
title: NSI Terminale - Données
subtitle : Pratique de la programmation objet
author: qkzk
date: 2020/04/21
---

# Pratique de la programmation objet

L'objectif de ce TP est de vous faire écrire des classes et des méthodes.

On part de l'exemple courant : les objets géométriques que tout le monde
connait. Ils interviennent régulièrement dans les jeux et autre,
autant comprendre comment ils sont écrits.

### ATTENTION

**Dans toute la suite on suppose que le plan EST ORIENTÉ VERS LE BAS**

**LES Y VONT VERS LE BAS !!!**

**Ca ne change rien... sauf quand on parle de coin supérieur gauche, inférieur droit etc.**

# Pratique de la programmation objet

## Matériel fourni

Vous disposez de deux fichiers :

1. [geometrie_eleve.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/poo/geometrie/geometrie_eleve.py)

    C'est ici que vous devez écrire votre code. Remplissez le au fur et à mesure.

2. [geoemetrie_eleve_tests.py](https://github.com/NSI-T-2021/Tale_nsi_2021/blob/master/donnees/poo/geometrie/geometrie_eleve_tests.py)

    Contient tous les tests des méthodes.
    Ce fichier est complet, mais certaines méthodes sont commentées afin
    d'éviter de planter.

    Enlevez les commentaires au fur et à mesure et exécutez ce fichier.

    Si vous avez bien programmé, il n'y a pas d'erreur.

    Si vraiment vous ne trouvez pas comment écrire une méthode et voulez passer,
    commentez son test !

## la classe disque

La classe `disque` est quasi complète.

Voici ce qu'on peut déjà faire :

```python
>>> d1 = Disque(3, 4, 5)  # centre (3, 4), rayon 5
>>> d1
Disque de centre (3, 4) et de rayon 5.
>>> d1.centre()           # retourne le centre
(3, 4)
>>> d1.rayon()            # retourne le rayon
5
>>> d1.diametre()         # retourne le diamètre
10
>>> d1.contient(2, 3)     # le point (2, 3) est-il dans le disque ?
True
>>> d1.contient(10, 20)   # idem
False
```

Par ailleurs vous disposez d'une fonction utilitaire `distance` qui calcule
la distance euclidienne entre deux points du plan.

Elle prend quatre paramètres : `(x_a, y_a, x_b, y_b)` qui sont les
coordonnées des points `A(x_a, y_a)` et `B(x_b, y_b)`.

```python
>>> distance(1, 2, 4, 6)
5.0
>>> distance(0, 0, 1, 0)
1.0
>>> distance(-3, -2, 3, 10)
10.0
```



1. Lisez le code en détail
2. Implémentez une méthode `changer_centre` qui prend deux paramètres et règle
    un nouveau centre aux coordonnées données.

    ```python
    >>> d1 = Disque(3, 4, 5)        # centre (3, 4), rayon 5
    >>> d1.centre()                 # retourne le centre
    (3, 4)
    >>> d1.changer_centre(5, 2)     # règle un nouveau centre
    >>> d1
    Disque de centre (5, 2) et de rayon 5.
    ```

3. Implémentez une méthode `changer_rayon` qui prend un paramètre et règle
    un nouveau rayon donné.

4. Implémentez une méthode `intersecte` qui prend en paramètre un objet `Disque`
    et retourne `True` si les disques s'intersectent et `False` sinon.

    ```python
    >>> d2 = Disque(5, 4, 3) # centre (5, 4), rayon 3
    >>> d1.intersecte(d2)    # se coupent-ils ?
    True
    >>> d3 = Disque(10, 100, 1000)
    >>> d1.intersecte(d3)
    False
    ```

## La classe `Rectangle`

On s'intéresse ici aux rectangles du plan. On se limite aux rectangles
dont les côtés sont parallèles aux axes.

Ils sont définis par 4 données :

`x, y, l, h` qui désignent :

* `x` : l'abscisse du coin supérieur gauche,
* `y` : l'ordonnée du coin supérieur gauche,
* `l` : la largeur (horizontalement),
* `h` : la hauteur.

La classe rectangle a déjà un squelette complet. Toutes les signatures
et toute la documentation est fournie.

**Il reste à écrire le code.**

1. Créer une classe `Rectangle` avec son constructeur (`__init__`)

    ```python
    >>> r1 = Rectangle(0, 1, 2, 4) # coin sup. gauche (0, 1), largeur 2, hauteur 4
    ```

2. Aire et périmètre. Créer deux méthodes `aire`  et `perimetre` qui
    retournent les valeurs de ceux-ci.

3. Méthodes `x`, `y`, `largeur`, `hauteur`

    Implémentez ces quatres méthodes qui retournent les données du rectangle

    ```python
    >>> r1 = Rectangle(0, 1, 2, 4)
    >>> r1.x()
    0
    >>> r1.y()
    1
    >>> r1.largeur()
    2
    >>> r1.hauteur()
    4
    ```


3. Afficher dans la console. La méthode `__repr__`

    **Rappel** Cette méthode magique est appelée par Python quand on affiche
    l'objet dans la console.

    Voici ce qui se passe quand on crée un rectangle et tente de l'afficher :

    ```python
    >>> r1 = Rectangle(1, 2, 3, 4)
    >>> r1         # <---------------- ici
    Rectangle de coin supérieur gauche (1, 2) de largeur 3 et de hauteur 4
    ```

    Python appelle `repr(r1)`... qui appelle `r1.__repr__()`...

    Cette méthode retourne **une chaîne de caractères**

    Que Python affiche dans la console : _Rectangle de de coin supérieur gauche ..._

    Inspirez-vous de celle des disques pour créer la méthode `__repr__` des rectangles


3. `contient`.

    On souhaite répondre à la question, le point `A(xa; ya)` est-il dans le
    rectangle `R` ?

    ```python
    >>> r1 = Rectangle(0, 1, 2, 4)
    >>> a = (1, 2) # un tuple !
    >>> r1.contient(a)
    True
    >>> b = (10, 10)
    >>> r1.contient(b)
    False
    ```

    Rédiger (papier!) puis programmer un jeu de tests permettant de répondre.

3. `collision`. On souhaite savoir si deux rectangle du plan se rencontrent.

      C'est le cas si l'un des sommets du second rectangle est dans le premier
      rectangle.

      ![collision](http://www.jeffreythompson.org/collision-detection/images/rect-rect.jpg)

      1. Rédiger sur le papier un jeu de test qui permette de répondre.
      2. Programmer la méthode `collision`. Voici l'interface que nous devons
          développer

      ```python
      >>> r1 = Rectangle(0, 0, 2, 4)
      >>> r2 = Rectangle(1, 1, 4, 2)
      >>> r1.collision(r2)
      True
      >>> r3 = Rectangle(10, 10, 1, 1)
      >>> r1.collision(r3)
      True

      ```



## La classe Vecteurs

Nous allons implémenter quelques outils sur les vecteurs.
Nativement Python ne propose pas grand chose sur les vecteurs.

Il existe une vaste librairie qui fait à peu près tout, `numpy`. Elle
est très employée par les professionnels.

Notre objectif est de réaliser l'implémentation d'une classe sur les vecteurs.

**Rien n'est fourni pour la classe `Vecteur`**

Vous devez la créer entièrement.

Implémentez ces méthodes :

1. Constructeur. Un vecteur est donné ses coordonnées directement (donc 2 nombres).

    ```python
    u = Vecteur(1, 2)   # vecteur de coordonnées (1, 2)
    ```
3. Coordonnées : `coordonnees`. Retourne les coordonnées du vecteur (un tuple)
2. Norme : `norme`. Retourne la norme d'un vecteur (calculée avec `distance`)
4. Affichage dans la console : la méthode magique `__repr__`
3. Égalité : la méthode magique `__eq__` Elle permet de tester `u == v`

    Deux vecteurs sont égaux s'ils ont les mêmes coordonnées.
2. Somme de deux vecteurs : la méthode magique `__add__`

    Elle permet d'implémenter la somme : `u + v`

    La somme de deux vecteurs est un vecteur dont les coordonnées sont les
    sommes respectives. Il faut : `return Vecteur(...)`

3. Soustraction de deux vecteurs : la méthode magique `__sub__`

    Elle permet d'implémenter la somme : `u - v`

    La soustraction de deux vecteurs est un vecteur dont les coordonnées sont les
    soustractions respectives. Il faut : `return Vecteur(...)`

4. Déterminant de deux vecteurs du plan : la méthode `det`

    Le déterminant de deux vecteurs est calculé par le produit en croix :

    ```
    deteterminant de u(x, y) et v(x', y') = x * y' - x' * y
    ```
5. Colinéarité : la méthode `colineaire`

    Elle retourne `True` si et seulement si les vecteurs sont colinéaires.

    (cad si leur déterminant est nul)

6. Produit scalaire : la méthode magique `__mul__`

    Calcule le produit scalaire de deux vecteurs

    ```
    produit scalaire de u(x, y) et v(x', y') = u*v = x * x' - y * y'
    ```

### Exemples de la classe Vecteur

```python
>>> u = Vecteur(1, 2)
>>> u.coordonnees()
(1, 2)
>>> u.norme()
2.23606797749979
>>> u
Vecteur de coordonnées (1, 2)
>>> v = Vecteur(2, 4)
>>> u == v
False
>>> u1 = Vecteur(1, 2)
>>> u == u1
True
>>> w = u + v
>>> w
Vecteur de coordonnées (3, 6)
>>> w1 = u - v
>>> w1
Vecteur de coordonnées (-1, -2)
>>> ps = u * v
>>> ps
10
>>> u.det(v)
0
>>> u.colineaire(v)
True
>>>
```


## Conclusion

Vous avez implémenté une vaste librairie d'objets géométriques du plan.
Tout n'y est pas et certaines méthodes méritent une amélioration.

Néanmoins, vous devriez maintenant savoir écrire des classes et des méthodes !


Si êtes curieux, vous pouvez consulter la correction. J'y implémente aussi
une méthode de classe pour créer les vecteurs à partir de deux points.

Une autre version est proposée, utilisant l'héritage.

Par ailleurs, dans `pygame` on trouve régulièrement ces objets géométriques.

Pygame les crée de la même manière que nous...

__title__ = "Tests du module `tennis.py` Tennis"
__author__ = 'qkzk'
__date__ = '2020/04/22'
__doc__ = '''
titre:    {0}
auteur:   {1}
date:     {2}

Ici sont testées toutes les fonctions implémentées dans le module `tennis.py`

Chaque fonction de test est indépendante, si on suit l'énoncé, elles doivent
toutes se valider une par une.
'''.format(__title__, __author__, __date__)


from tennis_eleve import *


def tester_tlm():
    '''
    Teste toutes les fonctions du programme
    '''
    tester_a_faire_1()
    tester_a_faire_2_3()
    tester_a_faire_4()
    tester_a_faire_5()
    tester_a_faire_6()
    tester_a_faire_7()
    tester_a_faire_8()
    tester_a_faire_9()
    print("tests validés, TP terminé !")


def tester_a_faire_1():
    '''a faire 1'''
    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
    ]
    assert utilisateur(planning, 30) == 'Robert'
    assert utilisateur(planning, 100) is None
    print("A faire 1: ok")


def tester_a_faire_2_3():
    '''
    a faire 2: règle 3,
    à faire 3
    '''
    planning = [{'nom': 'Robert', 'de': 0, 'à': 60}]
    inscrire(planning, 'Robert', 42)
    assert planning == [{'nom': 'Robert', 'de': 0, 'à': 60}]
    print("A faire 2 et 3: ok")


def tester_a_faire_4():
    ''' à faire 4 : libre'''
    planning = [{'nom': 'Robert', 'de': 0, 'à': 60}]
    assert libre(planning, 61)
    assert not libre(planning, 45)
    print("A faire 4: ok")


def tester_a_faire_5():
    '''a faire 5 : déjà inscrit'''
    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
    ]
    assert deja_inscrit(planning, 45, 'Francis')
    assert not deja_inscrit(planning, 140, 'Francis')
    print("A faire 5: ok")


def tester_a_faire_6():
    '''à faire 6: formater inscription'''
    assert formater_inscription('Robert', 30) == {'nom': 'Robert',
                                                  'de': 30, 'à': 90}
    print("A faire 6: ok")


def tester_a_faire_7():
    '''a faire 7 : règle 1 et 2'''
    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
    ]

    inscrire(planning, 'Louise', 130)
    assert planning == [{'nom': 'Robert', 'de': 0, 'à': 60},
                        {'nom': 'Francis', 'de': 60, 'à': 120},
                        {'nom': 'Louise', 'de': 130, 'à': 190}]
    print("A faire 7: ok")


def tester_a_faire_8():
    '''à faire 8: durée d'attente '''
    planning = [{'nom': 'Robert', 'de': 0, 'à': 60},
                {'nom': 'Francis', 'de': 60, 'à': 120},
                {'nom': 'Louise', 'de': 130, 'à': 190}]
    assert duree_attente(planning, 180) == 10
    assert duree_attente(planning, 190) == 0
    assert duree_attente([], 200) == 0

    print("A faire 8 (durée d'attente): ok")

    planning = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
    ]

    inscrire(planning, 'Louise', 110)
    assert planning == [{'nom': 'Robert', 'de': 0, 'à': 60},
                        {'nom': 'Francis', 'de': 60, 'à': 120},
                        {'nom': 'Louise', 'de': 120, 'à': 180}]
    print("A faire 8 (complet) : ok")


def tester_a_faire_9():
    ''''
    Teste le programme complet.
    Ajoute tous les utilisateurs qui se sont présentés à la réception
    durant la matinée
    Vérifie que le planning obtenu est correct
    '''
    demandes_dinscription = [
        ('Robert', 0),
        ('Robert', 40),
        ('Robert', 42),
        ('Francis', 45),
        ('Louise', 100),
        ('Robert', 145),
        ('Francis', 152),
    ]

    planning_final = [
        {'nom': 'Robert', 'de': 0, 'à': 60},
        {'nom': 'Francis', 'de': 60, 'à': 120},
        {'nom': 'Louise', 'de': 120, 'à': 180},
        {'nom': 'Robert', 'de': 180, 'à': 240},
        {'nom': 'Francis', 'de': 240, 'à': 300},
    ]

    planning = []

    for inscription in demandes_dinscription:
        inscrire(planning, *inscription)

    assert planning == planning_final

    print("A faire 9: ok")


if __name__ == '__main__':
    tester_tlm()

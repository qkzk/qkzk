résolution de labyrinthes par les je sais pas quoi

_Résolution de labyrinthes

Physarum polycephalum dans un labyrinthe.  Une équipe de chercheurs japonais et
hongrois considère que Physarum polycephalum est capable de se déplacer dans un
labyrinthe d’agar-agar en identifiant le plus court chemin possible quand deux
morceaux de nourriture sont placés à chaque entrée13. En réalité, Physarum
polycephalum parcourt tout le labyrinthe et persiste uniquement sur le chemin
le plus court.

Une étude démontre que Physarum polycephalum peut résoudre des problèmes
complexes mettant en jeu plus de sources de nourriture. Pour ce faire, les
chercheurs déposent l’organisme sur une surface où sont dispersés des points de
nourriture représentant les différentes villes de la région de Tokyo. Physarum
polycephalum crée un réseau optimisé entre les sources de nourriture, en
reliant de la manière la plus efficace les différentes stations14._


On a des lectures bizarres pendant le réveillon : https://fr.wikipedia.org/wiki/Physarum_polycephalum#Résolution_de_labyrinthes

J'ai cru comprendre que la fac de Saint-Denis (974) avait le matos permettant ce genre de calcul.

Cela peut faire l'objet de questions au grand oral non ?

Alain

# Grand oral

Toutes les ressources dont je dispose :

* _nouveau_ [Carnet de bord du grand oral](carnet_de_bord.pdf) réalisé par le CDI et des enseignants du lycée.
* _nouveau_ [Grand oral maths](Grand_Oral_Maths_Ac_Lille.pdf) réalisé par l'inspection de mathématiques il présente la grille d'évaluation
* La présentation du grand oral pour les élèves ["Quand je passe le bac"](http://quandjepasselebac.education.fr/faq-grand-oral/)
* Carte mentale ["Questions grand oral"](https://www.mindmeister.com/fr/1713604014?t=SNS98cTPtj) réalisée par un collègue et ses élèves
* Des idées de projet "présentables à l'oral"

    > Simple tableau de caractères (ou str?) : http://library.msri.org/books/Book42/files/grossman.pdf
    >
    > tableau de tableaux : https://alainbusser.github.io/primaire/html/alquerkonane.html
    >
    > Dans les deux cas, il s'agit de chercher une stratégie gagnante à un de ces jeux.
* D'autres idées de questions : ![sujets](idees_sujets_ipr_versailles.jpg)

* Autre idée de "question":

    > **Résolution de labyrinthes**
    >
    > Physarum polycephalum dans un labyrinthe.  Une équipe de chercheurs japonais et
    > hongrois considère que Physarum polycephalum est capable de se déplacer dans un
    > labyrinthe d’agar-agar en identifiant le plus court chemin possible quand deux
    > morceaux de nourriture sont placés à chaque entrée13. En réalité, Physarum
    > polycephalum parcourt tout le labyrinthe et persiste uniquement sur le chemin
    > le plus court.
    >
    > Une étude démontre que Physarum polycephalum peut résoudre des problèmes
    > complexes mettant en jeu plus de sources de nourriture. Pour ce faire, les
    > chercheurs déposent l’organisme sur une surface où sont dispersés des points de
    > nourriture représentant les différentes villes de la région de Tokyo. Physarum
    > polycephalum crée un réseau optimisé entre les sources de nourriture, en
    > reliant de la manière la plus efficace les différentes stations14.
    >
    > [Source](https://fr.wikipedia.org/wiki/Physarum_polycephalum#Résolution_de_labyrinthes)

* la [FAQ](FAQ.pdf) du grand oral - destinée aux enseignants.
* Le document [Grand_oral_Igesr_Document_integral_0.pdf](Grand_oral_Igesr_Document_integral_0.pdf)
    de l'académie de Nantes (lien eduscol). Pour NSI, il faut regarder les pages 55 à 57. Il contient des idées de questions intéressantes.

---

# Résumé des infos officielles

## Définition et objectifs

L'épreuve du « Grand oral » a été conçue pour permettre au candidat de montrer sa capacité à prendre la parole en public de façon claire et convaincante. Elle lui permettra aussi d'utiliser les connaissances liées à ses spécialités pour démontrer ses capacités argumentatives et la maturité de son projet de poursuite d'études, voire professionnel.

## L'épreuve

| Épreuve orale            |
| --------------           |
| Durée : 20 minutes       |
| Préparation : 20 minutes |
| Coefficient : 10         |

L'épreuve orale terminale est l'une des cinq épreuves terminales de l'examen du
baccalauréat. Elle est obligatoire pour tous les candidats qui présentent
l'épreuve dans les mêmes conditions.


## Évaluation de l'épreuve

L'épreuve est notée sur 20 points. Le jury valorise la solidité des
connaissances du candidat, sa capacité à argumenter et à relier les savoirs,
son esprit critique, la précision de son expression, la clarté de son propos,
son engagement dans sa parole, sa force de conviction. Il peut s'appuyer sur la
grille indicative de l'annexe 1 des notes de service 
[n° 2020-036 (NOR : MENE2002780N)](https://www.education.gouv.fr/bo/20/Special2/MENE2002780N.htm?cid_bo=149115)
et [n° 2020-037 (NOR : MENE2002781N)](https://www.education.gouv.fr/bo/20/Special2/MENE2002781N.htm?cid_bo=149116).

## Format et déroulement de l'épreuve

Le Grand oral dure 20 minutes avec 20 minutes de préparation.

Le candidat présente au jury deux questions préparées avec ses professeurs et
éventuellement avec d'autres élèves, qui portent sur ses deux spécialités, soit
prises isolément, soit abordées de manière transversale en voie générale. Pour
la voie technologique, ces questions s'appuient sur l'enseignement de
spécialité pour lequel le programme prévoit la réalisation d'une étude
approfondie.

Le jury choisit une de ces deux questions. Le candidat a ensuite 20 minutes de
préparation pour mettre en ordre ses idées et créer s'il le souhaite un support
(qui ne sera pas évalué) à donner au jury.

**L'épreuve se déroule en 3 temps.**

## Déroulé de l'épreuve

Pendant 5 minutes, le candidat présente la question choisie et y répond. Le
jury évalue son argumentation et ses qualités de présentation. L'exposé se
déroule sans note et debout, sauf aménagements pour les candidats à besoins
spécifiques.

Ensuite, pendant 10 minutes, le jury échange avec le candidat et évalue la
solidité de ses connaissance et ses compétences argumentatives. Ce temps
d'échange permet à l'élève de mettre en valeur ses connaissances, liées au
programme des spécialités suivies en classe de première et terminale.

Les 5 dernières minutes d'échanges avec le jury portent sur le projet
d'orientation du candidat. Le candidat montre que la question traitée a
participé à la maturation de son projet de poursuite d'études, et même pour son
projet professionnel.

**Le jury va porter son attention** sur la solidité des connaissances, la capacité
à argumenter et à relier les savoirs, l'expression et la clarté du propos,
l'engagement dans la parole, la force de conviction et la manière d'exprimer
une réflexion personnelle, ainsi qu'aux motivations du candidat.s
